# Aura Music (Samsung Music Aesthetic Edition)

A minimalist, aesthetic, playlist-first music player built natively for Android (Motorola compatible) with Jetpack Compose and AndroidX Media3.

---

## 🌟 Key Features

1. **Screen-Off Continuous Playback (Samsung Music Style):**
   * Uses `AuraPlaybackService` (`MediaSessionService`) with CPU `WAKE_LOCK`.
   * Music continues uninterrupted when you lock the phone or turn the screen off.
   * Full lock-screen and notification controls with album art, waveform seek bar, and playback actions.

2. **Smart Shuffle Engine:**
   * Never plays songs in static alphabetical or list order.
   * **Hot (Like):** Gives tracks a 2.5× recurrence weighting and boosts similar artists/vibes.
   * **Cool (Dislike):** Dampens track recurrence to 0.2× without deleting the song.
   * Anti-repetition window prevents recent songs from replaying too soon.

3. **Ambient Light Aura & Glassmorphism:**
   * Dynamic Gaussian blur backdrop derived from the active song's album art.
   * Soft ambient light glow bleeding behind the hero banner card.
   * Tinder-style swipe gestures to transition smoothly between songs.

4. **Navigation Layout:**
   * **Top-Left:** Shuffle toggle with active indicator dot.
   * **Top-Center:** Centered playlist title in editorial serif.
   * **Top-Right:** List of Songs button that slides up the tracklist drawer.
   * **Center:** Dedicated Play/Pause button with live playback status.

---

## 🚀 How to Run & Install on Your Motorola Phone

### Step 1: Open the Project in Android Studio
1. Launch **Android Studio**.
2. Select **Open** and browse to this folder:
   ```
   c:\Users\bhara\OneDrive\Pictures\SAMSUNG MUSIC
   ```
3. Let Gradle sync dependencies automatically.

### Step 2: Connect Your Motorola Phone via USB
1. On your phone: **Settings** > **About phone** > tap **Build number 7 times**.
2. Go to **Settings** > **System** > **Developer options** > turn on **USB Debugging**.
3. Connect your phone to your PC with a USB cable and select **"Always allow from this computer"** when prompted.

### Step 3: Run / Install
* In Android Studio, select your Motorola phone in the top device toolbar and click the green **Play (Run)** button!
* Alternatively, build the APK from the terminal:
  ```powershell
  ./gradlew assembleDebug
  adb install app/build/outputs/apk/debug/app-debug.apk
  ```
