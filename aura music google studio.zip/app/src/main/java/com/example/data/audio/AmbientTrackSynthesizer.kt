package com.example.data.audio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Synthesizes warm, meditative Rhodes & ambient pad chord-progression WAV tracks locally
 * into app storage on first launch so curated playlists play real, pleasant music offline
 * through Media3 ExoPlayer with screen-off wake-lock support.
 */
object AmbientTrackSynthesizer {

    private const val SAMPLE_RATE = 22050
    private const val CHANNELS = 1
    private const val BITS_PER_SAMPLE = 16

    data class AmbientTrackRecipe(
        val fileName: String,
        val chordsHz: List<DoubleArray>,
        val chordDurationSec: Double,
        val melodyNotesHz: DoubleArray,
        val shimmerHz: Double
    )

    private val recipes = mapOf(
        "golden_hour" to AmbientTrackRecipe(
            fileName = "golden_hour_nocturne.wav",
            // Fmaj9 -> Dm9 -> Bbmaj7 -> C9 (warm sunset lo-fi jazz)
            chordsHz = listOf(
                doubleArrayOf(174.61, 220.00, 261.63, 329.63, 392.00),
                doubleArrayOf(146.83, 220.00, 261.63, 329.63, 349.23),
                doubleArrayOf(116.54, 174.61, 220.00, 293.66, 349.23),
                doubleArrayOf(130.81, 196.00, 233.08, 293.66, 329.63)
            ),
            chordDurationSec = 4.5,
            melodyNotesHz = doubleArrayOf(523.25, 440.00, 392.00, 440.00, 587.33, 523.25, 440.00, 392.00),
            shimmerHz = 0.28
        ),
        "indigo_solitude" to AmbientTrackRecipe(
            fileName = "indigo_solitude.wav",
            // Cm9 -> Abmaj7 -> Fm9 -> G7sus4 (midnight water nocturne)
            chordsHz = listOf(
                doubleArrayOf(130.81, 155.56, 196.00, 233.08, 293.66),
                doubleArrayOf(103.83, 155.56, 196.00, 246.94, 311.13),
                doubleArrayOf(174.61, 207.65, 261.63, 311.13, 392.00),
                doubleArrayOf(196.00, 261.63, 293.66, 349.23, 392.00)
            ),
            chordDurationSec = 5.0,
            melodyNotesHz = doubleArrayOf(392.00, 466.16, 523.25, 466.16, 392.00, 349.23, 311.13, 293.66),
            shimmerHz = 0.22
        ),
        "emerald_dawn" to AmbientTrackRecipe(
            fileName = "emerald_dawn.wav",
            // Dmaj9 -> Bm7 -> Gmaj7 -> A6 (serene morning crystal ambient)
            chordsHz = listOf(
                doubleArrayOf(146.83, 185.00, 220.00, 277.18, 329.63),
                doubleArrayOf(123.47, 185.00, 220.00, 293.66, 369.99),
                doubleArrayOf(196.00, 246.94, 293.66, 369.99, 440.00),
                doubleArrayOf(110.00, 164.81, 220.00, 277.18, 329.63)
            ),
            chordDurationSec = 4.5,
            melodyNotesHz = doubleArrayOf(587.33, 554.37, 493.88, 440.00, 369.99, 440.00, 493.88, 554.37),
            shimmerHz = 0.34
        ),
        "velvet_resonance" to AmbientTrackRecipe(
            fileName = "velvet_resonance.wav",
            // Em9 -> Cmaj7 -> Am9 -> B7sus4 (warm crimson neo-soul)
            chordsHz = listOf(
                doubleArrayOf(164.81, 196.00, 246.94, 293.66, 369.99),
                doubleArrayOf(130.81, 196.00, 246.94, 329.63, 392.00),
                doubleArrayOf(110.00, 164.81, 196.00, 246.94, 329.63),
                doubleArrayOf(123.47, 185.00, 220.00, 293.66, 329.63)
            ),
            chordDurationSec = 4.2,
            melodyNotesHz = doubleArrayOf(493.88, 440.00, 392.00, 329.63, 392.00, 440.00, 493.88, 587.33),
            shimmerHz = 0.30
        ),
        "amber_afterglow" to AmbientTrackRecipe(
            fileName = "amber_afterglow.wav",
            // Gmaj9 -> Em9 -> Cmaj7 -> D9 (warm mellow glass jazz)
            chordsHz = listOf(
                doubleArrayOf(196.00, 246.94, 293.66, 369.99, 440.00),
                doubleArrayOf(164.81, 196.00, 246.94, 293.66, 369.99),
                doubleArrayOf(130.81, 196.00, 246.94, 329.63, 392.00),
                doubleArrayOf(146.83, 220.00, 261.63, 329.63, 369.99)
            ),
            chordDurationSec = 4.5,
            melodyNotesHz = doubleArrayOf(587.33, 493.88, 440.00, 392.00, 493.88, 587.33, 659.25, 587.33),
            shimmerHz = 0.26
        ),
        "midnight_prism" to AmbientTrackRecipe(
            fileName = "midnight_prism.wav",
            // Am9 -> Fmaj7 -> Dm9 -> E7sus4 (ethereal starry ambient)
            chordsHz = listOf(
                doubleArrayOf(110.00, 164.81, 196.00, 246.94, 329.63),
                doubleArrayOf(174.61, 220.00, 261.63, 329.63, 392.00),
                doubleArrayOf(146.83, 220.00, 261.63, 329.63, 349.23),
                doubleArrayOf(164.81, 220.00, 246.94, 293.66, 329.63)
            ),
            chordDurationSec = 4.8,
            melodyNotesHz = doubleArrayOf(659.25, 587.33, 523.25, 493.88, 440.00, 523.25, 493.88, 440.00),
            shimmerHz = 0.24
        )
    )

    suspend fun ensureTrackFile(context: Context, key: String): Pair<String, Long> =
        withContext(Dispatchers.IO) {
            val recipe = recipes[key] ?: recipes.getValue("golden_hour")
            val dir = File(context.filesDir, "aura_audio").apply { mkdirs() }
            val outFile = File(dir, recipe.fileName)
            val totalSeconds = recipe.chordsHz.size * recipe.chordDurationSec
            val durationMs = (totalSeconds * 1000.0).toLong()

            if (!outFile.exists() || outFile.length() < 1024L) {
                synthesizeWav(outFile, recipe)
            }
            outFile.toURI().toString() to durationMs
        }

    private fun synthesizeWav(outFile: File, recipe: AmbientTrackRecipe) {
        val totalSeconds = recipe.chordsHz.size * recipe.chordDurationSec
        val totalSamples = (totalSeconds * SAMPLE_RATE).toInt()
        val dataByteCount = totalSamples * CHANNELS * (BITS_PER_SAMPLE / 8)
        val samplesPerChord = (recipe.chordDurationSec * SAMPLE_RATE).toInt()
        val melodyStepSamples = (totalSamples / recipe.melodyNotesHz.size).coerceAtLeast(1)

        val pcmBuffer = ByteArray(dataByteCount)
        val twoPi = 2.0 * PI

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val chordIndex = (i / samplesPerChord).coerceAtMost(recipe.chordsHz.lastIndex)
            val localPos = (i % samplesPerChord).toDouble() / samplesPerChord

            // Smooth bell-pad attack and gentle cross-fade release so chords bloom softly
            val attack = (localPos / 0.14).coerceIn(0.0, 1.0)
            val release = ((1.0 - localPos) / 0.22).coerceIn(0.0, 1.0)
            val chordEnv = attack * release * (0.78 + 0.22 * exp(-localPos * 1.4))

            // Subtle breathing LFO tremolo
            val lfo = 0.88 + 0.12 * sin(twoPi * recipe.shimmerHz * t)

            val chord = recipe.chordsHz[chordIndex]
            var sample = 0.0
            for (n in chord.indices) {
                val freq = chord[n]
                // Warm Rhodes fundamental + gentle 2nd harmonic + tiny detuned chorus
                val fund = sin(twoPi * freq * t)
                val detuned = sin(twoPi * (freq * 1.0022) * t) * 0.35
                val warmHarmonic = sin(twoPi * (freq * 2.0) * t) * 0.16 * exp(-localPos * 2.2)
                sample += (fund + detuned + warmHarmonic) / chord.size
            }
            sample *= chordEnv * lfo * 0.62

            // Delicate Rhodes chime melody note softly floating above the pad
            val melIdx = (i / melodyStepSamples).coerceAtMost(recipe.melodyNotesHz.lastIndex)
            val melLocal = (i % melodyStepSamples).toDouble() / melodyStepSamples
            val melAttack = (melLocal / 0.04).coerceIn(0.0, 1.0)
            val melDecay = exp(-melLocal * 3.8)
            val melFreq = recipe.melodyNotesHz[melIdx]
            val melTone = (sin(twoPi * melFreq * t) + 0.25 * sin(twoPi * melFreq * 2.0 * t)) *
                melAttack * melDecay * 0.22
            sample += melTone

            // Soft global fade-in/out at track edges for click-free seamless looping
            val globalFade = when {
                i < SAMPLE_RATE / 4 -> i.toDouble() / (SAMPLE_RATE / 4)
                i > totalSamples - SAMPLE_RATE / 4 -> (totalSamples - i).toDouble() / (SAMPLE_RATE / 4)
                else -> 1.0
            }
            val finalSample = (sample * globalFade).coerceIn(-0.95, 0.95)
            val pcm16 = (finalSample * 32767.0).toInt().toShort()

            val byteIdx = i * 2
            pcmBuffer[byteIdx] = (pcm16.toInt() and 0xFF).toByte()
            pcmBuffer[byteIdx + 1] = ((pcm16.toInt() shr 8) and 0xFF).toByte()
        }

        BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
            writeWavHeader(bos, dataByteCount)
            bos.write(pcmBuffer)
        }
    }

    private fun writeWavHeader(out: BufferedOutputStream, dataSize: Int) {
        val totalDataLen = dataSize + 36
        val byteRate = SAMPLE_RATE * CHANNELS * (BITS_PER_SAMPLE / 8)
        val header = ByteArray(44)

        // RIFF
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        writeIntLE(header, 4, totalDataLen)
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()

        // fmt
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        writeIntLE(header, 16, 16)
        writeShortLE(header, 20, 1) // PCM
        writeShortLE(header, 22, CHANNELS)
        writeIntLE(header, 24, SAMPLE_RATE)
        writeIntLE(header, 28, byteRate)
        writeShortLE(header, 32, CHANNELS * (BITS_PER_SAMPLE / 8))
        writeShortLE(header, 34, BITS_PER_SAMPLE)

        // data
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        writeIntLE(header, 40, dataSize)

        out.write(header)
    }

    private fun writeIntLE(buf: ByteArray, offset: Int, value: Int) {
        buf[offset] = (value and 0xFF).toByte()
        buf[offset + 1] = ((value shr 8) and 0xFF).toByte()
        buf[offset + 2] = ((value shr 16) and 0xFF).toByte()
        buf[offset + 3] = ((value shr 24) and 0xFF).toByte()
    }

    private fun writeShortLE(buf: ByteArray, offset: Int, value: Int) {
        buf[offset] = (value and 0xFF).toByte()
        buf[offset + 1] = ((value shr 8) and 0xFF).toByte()
    }
}
