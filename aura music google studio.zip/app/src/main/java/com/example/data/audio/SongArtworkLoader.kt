package com.example.data.audio

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.annotation.DrawableRes
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.roundToInt

data class ExtractedArtworkResult(
    val cachedArtworkUri: String?,
    val dominantColorLong: Long,
    val secondaryColorLong: Long
)

/**
 * Loads real cover art from song files on Dispatchers.IO in priority order:
 *  1) MediaMetadataRetriever.embeddedPicture (ID3/Vorbis/MP4 embedded tag art)
 *  2) ContentResolver.loadThumbnail(songUri) on Android 10+ (MediaStore thumbnail)
 *  3) MediaStore album art for the song's album
 * Downscales art to ~512px max edge, caches JPEG on disk for Coil & MediaSession,
 * and extracts dominant/vibrant colors via AndroidX Palette API.
 */
object SongArtworkLoader {

    private const val MAIN_BANNER_MAX_PX = 512
    private val drawablePaletteCache = ConcurrentHashMap<Int, Pair<Long, Long>>()

    suspend fun extractRealArtworkAndColors(
        context: Context,
        songUri: Uri,
        trackId: Long,
        @DrawableRes fallbackDrawableRes: Int
    ): ExtractedArtworkResult = withContext(Dispatchers.IO) {
        val rawBitmap = loadEmbeddedPicture(context, songUri)
            ?: loadAndroidQThumbnail(context, songUri)
            ?: loadMediaStoreAlbumArt(context, songUri)

        if (rawBitmap != null) {
            val scaled = downscaleToMaxEdge(rawBitmap, MAIN_BANNER_MAX_PX)
            if (scaled !== rawBitmap) {
                rawBitmap.recycle()
            }
            val (domColor, secColor) = extractPaletteColors(scaled)
            val cachedFile = saveToDiskCache(context, trackId, scaled)
            scaled.recycle()

            ExtractedArtworkResult(
                cachedArtworkUri = cachedFile?.toURI()?.toString(),
                dominantColorLong = domColor,
                secondaryColorLong = secColor
            )
        } else {
            val (domColor, secColor) = extractPaletteFromDrawable(context, fallbackDrawableRes)
            ExtractedArtworkResult(
                cachedArtworkUri = null,
                dominantColorLong = domColor,
                secondaryColorLong = secColor
            )
        }
    }

    suspend fun loadNotificationArtworkBytes(
        context: Context,
        cachedArtworkUri: String?,
        audioUri: String,
        trackId: Long,
        @DrawableRes fallbackDrawableRes: Int
    ): ByteArray? = withContext(Dispatchers.IO) {
        // 1. Cached real artwork file on disk (fastest)
        val cachedBitmap = cachedArtworkUri?.let { uriStr ->
            runCatching {
                val path = Uri.parse(uriStr).path
                if (!path.isNullOrBlank()) {
                    val file = File(path)
                    if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                } else null
            }.getOrNull()
        }

        // 2. If not cached yet, try real extraction on demand
        val realBitmap = cachedBitmap ?: run {
            val uri = Uri.parse(audioUri)
            val extracted = loadEmbeddedPicture(context, uri)
                ?: loadAndroidQThumbnail(context, uri)
                ?: loadMediaStoreAlbumArt(context, uri)
            if (extracted != null) {
                val scaled = downscaleToMaxEdge(extracted, MAIN_BANNER_MAX_PX)
                if (scaled !== extracted) extracted.recycle()
                saveToDiskCache(context, trackId, scaled)
                scaled
            } else null
        }

        // 3. Fallback deterministic banner only if real art does not exist
        val finalBitmap = realBitmap ?: runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeResource(context.resources, fallbackDrawableRes, opts)
        }.getOrNull() ?: return@withContext null

        val bytes = ByteArrayOutputStream().use { out ->
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 86, out)
            out.toByteArray()
        }
        finalBitmap.recycle()
        bytes
    }

    fun extractPaletteFromDrawable(
        context: Context,
        @DrawableRes drawableRes: Int
    ): Pair<Long, Long> {
        drawablePaletteCache[drawableRes]?.let { return it }
        val bitmap = runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeResource(context.resources, drawableRes, opts)
        }.getOrNull()

        val colors = if (bitmap != null) {
            val extracted = extractPaletteColors(bitmap)
            bitmap.recycle()
            extracted
        } else {
            0xFFF59E0BL to 0xFF1E1B4BL
        }
        drawablePaletteCache[drawableRes] = colors
        return colors
    }

    private fun loadEmbeddedPicture(context: Context, songUri: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, songUri)
            val bytes = retriever.embeddedPicture ?: return null
            if (bytes.isEmpty()) return null
            decodeSampledBitmapFromBytes(bytes, MAIN_BANNER_MAX_PX)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun loadAndroidQThumbnail(context: Context, songUri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        if (songUri.scheme != "content") return null
        return runCatching {
            context.contentResolver.loadThumbnail(
                songUri,
                Size(MAIN_BANNER_MAX_PX, MAIN_BANNER_MAX_PX),
                null
            )
        }.getOrNull()
    }

    private fun loadMediaStoreAlbumArt(context: Context, songUri: Uri): Bitmap? {
        if (songUri.scheme != "content") return null
        return runCatching {
            var albumId: Long? = null
            // Attempt direct ALBUM_ID projection on songUri
            context.contentResolver.query(
                songUri,
                arrayOf(MediaStore.Audio.Media.ALBUM_ID),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val colIdx = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                    if (colIdx >= 0 && !cursor.isNull(colIdx)) {
                        albumId = cursor.getLong(colIdx)
                    }
                }
            }

            // If SAF document URI wraps a numeric audio media ID (e.g. "audio:12345"), try MediaStore lookup
            if (albumId == null) {
                val docId = songUri.lastPathSegment
                val numericId = docId?.substringAfterLast(':')?.toLongOrNull()
                if (numericId != null) {
                    val mediaUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        numericId
                    )
                    context.contentResolver.query(
                        mediaUri,
                        arrayOf(MediaStore.Audio.Media.ALBUM_ID),
                        null,
                        null,
                        null
                    )?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val colIdx = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                            if (colIdx >= 0 && !cursor.isNull(colIdx)) {
                                albumId = cursor.getLong(colIdx)
                            }
                        }
                    }
                }
            }

            val resolvedAlbumId = albumId ?: return@runCatching null

            // Android 10+: loadThumbnail on album URI
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val albumUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                    resolvedAlbumId
                )
                runCatching {
                    context.contentResolver.loadThumbnail(
                        albumUri,
                        Size(MAIN_BANNER_MAX_PX, MAIN_BANNER_MAX_PX),
                        null
                    )
                }.getOrNull()?.let { return@runCatching it }
            }

            // Legacy / universal MediaStore album art content URI
            val legacyArtUri = ContentUris.withAppendedId(
                Uri.parse("content://media/external/audio/albumart"),
                resolvedAlbumId
            )
            context.contentResolver.openInputStream(legacyArtUri)?.use { stream ->
                val bytes = stream.readBytes()
                if (bytes.isNotEmpty()) decodeSampledBitmapFromBytes(bytes, MAIN_BANNER_MAX_PX) else null
            }
        }.getOrNull()
    }

    private fun extractPaletteColors(bitmap: Bitmap): Pair<Long, Long> {
        val palette = Palette.from(bitmap).maximumColorCount(16).generate()
        val primaryRgb = palette.vibrantSwatch?.rgb
            ?: palette.lightVibrantSwatch?.rgb
            ?: palette.dominantSwatch?.rgb
            ?: palette.mutedSwatch?.rgb
            ?: 0xFFF59E0B.toInt()

        val secondaryRgb = palette.darkVibrantSwatch?.rgb
            ?: palette.darkMutedSwatch?.rgb
            ?: palette.mutedSwatch?.rgb
            ?: palette.dominantSwatch?.rgb
            ?: 0xFF1E1B4B.toInt()

        val domLong = (0xFF000000L or (primaryRgb.toLong() and 0x00FFFFFFL))
        val secLong = (0xFF000000L or (secondaryRgb.toLong() and 0x00FFFFFFL))
        return domLong to secLong
    }

    private fun saveToDiskCache(context: Context, trackId: Long, bitmap: Bitmap): File? {
        return runCatching {
            val artDir = File(context.filesDir, "aura_art").apply { mkdirs() }
            val outFile = File(artDir, "cover_${trackId}.jpg")
            FileOutputStream(outFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 88, fos)
            }
            outFile
        }.getOrNull()
    }

    private fun decodeSampledBitmapFromBytes(bytes: ByteArray, reqMaxPx: Int): Bitmap? {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
        val maxDim = max(boundsOpts.outWidth, boundsOpts.outHeight)
        var inSample = 1
        while (maxDim / (inSample * 2) >= reqMaxPx) {
            inSample *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = inSample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
    }

    private fun downscaleToMaxEdge(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val longest = max(w, h)
        if (longest <= maxEdge || w <= 0 || h <= 0) return bitmap
        val scale = maxEdge.toFloat() / longest.toFloat()
        val newW = (w * scale).roundToInt().coerceAtLeast(1)
        val newH = (h * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }
}
