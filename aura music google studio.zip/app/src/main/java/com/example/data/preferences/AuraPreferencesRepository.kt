package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.auraDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "aura_music_preferences"
)

class AuraPreferencesRepository(private val context: Context) {

    private object Keys {
        val ACTIVE_PLAYLIST_ID = longPreferencesKey("active_playlist_id")
        val SMART_SHUFFLE_ENABLED = booleanPreferencesKey("smart_shuffle_enabled")
        val LOFI_ENABLED = booleanPreferencesKey("lofi_enabled")
        val EIGHT_D_ENABLED = booleanPreferencesKey("eight_d_enabled")
        val HAS_SHOWN_8D_HINT = booleanPreferencesKey("has_shown_8d_hint")
    }

    val activePlaylistIdFlow: Flow<Long?> = context.auraDataStore.data.map { prefs ->
        prefs[Keys.ACTIVE_PLAYLIST_ID]
    }

    val smartShuffleEnabledFlow: Flow<Boolean> = context.auraDataStore.data.map { prefs ->
        prefs[Keys.SMART_SHUFFLE_ENABLED] ?: true
    }

    val lofiEnabledFlow: Flow<Boolean> = context.auraDataStore.data.map { prefs ->
        prefs[Keys.LOFI_ENABLED] ?: false
    }

    val eightDEnabledFlow: Flow<Boolean> = context.auraDataStore.data.map { prefs ->
        prefs[Keys.EIGHT_D_ENABLED] ?: false
    }

    val hasShownEightDHintFlow: Flow<Boolean> = context.auraDataStore.data.map { prefs ->
        prefs[Keys.HAS_SHOWN_8D_HINT] ?: false
    }

    suspend fun setActivePlaylistId(playlistId: Long) {
        context.auraDataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PLAYLIST_ID] = playlistId
        }
    }

    suspend fun setSmartShuffleEnabled(enabled: Boolean) {
        context.auraDataStore.edit { prefs ->
            prefs[Keys.SMART_SHUFFLE_ENABLED] = enabled
        }
    }

    suspend fun setLofiEnabled(enabled: Boolean) {
        context.auraDataStore.edit { prefs ->
            prefs[Keys.LOFI_ENABLED] = enabled
        }
    }

    suspend fun setEightDEnabled(enabled: Boolean) {
        context.auraDataStore.edit { prefs ->
            prefs[Keys.EIGHT_D_ENABLED] = enabled
        }
    }

    suspend fun markEightDHintShown() {
        context.auraDataStore.edit { prefs ->
            prefs[Keys.HAS_SHOWN_8D_HINT] = true
        }
    }
}
