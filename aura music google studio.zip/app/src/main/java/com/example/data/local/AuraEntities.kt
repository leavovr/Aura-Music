package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.Playlist
import com.example.data.model.SongStats
import com.example.data.model.Track
import com.example.data.model.TrackPreference

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val artist: String,
    val album: String = "",
    val vibe: String,
    val year: Int = 0,
    val durationMs: Long,
    val artworkKey: String,
    val artworkUri: String? = null,
    val audioUri: String,
    val dominantColorLong: Long,
    val secondaryColorLong: Long,
    val preference: String = TrackPreference.NEUTRAL.name,
    val isLocalImport: Boolean = false
) {
    fun toDomain(stats: SongStats? = null): Track {
        val resolvedPref = when {
            stats?.isHot == true -> TrackPreference.HOT
            stats?.isCool == true -> TrackPreference.COOL
            stats != null -> TrackPreference.NEUTRAL
            else -> runCatching { TrackPreference.valueOf(preference) }.getOrDefault(TrackPreference.NEUTRAL)
        }
        return Track(
            id = id,
            title = title,
            artist = artist,
            album = album,
            vibe = vibe,
            year = year,
            durationMs = durationMs,
            artworkKey = artworkKey,
            artworkUri = artworkUri,
            audioUri = audioUri,
            dominantColorLong = dominantColorLong,
            secondaryColorLong = secondaryColorLong,
            preference = resolvedPref,
            isLocalImport = isLocalImport
        )
    }
}

@Entity(
    tableName = "song_stats",
    foreignKeys = [
        ForeignKey(
            entity = TrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["songId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SongStatsEntity(
    @PrimaryKey val songId: Long,
    val isHot: Boolean = false,
    val hotScore: Float = 0f,
    val isCool: Boolean = false,
    val coolScore: Float = 0f,
    val playCount: Int = 0,
    val completedCount: Int = 0,
    val skipCount: Int = 0,
    val lastPlayedAt: Long = 0L
) {
    fun toDomain(): SongStats = SongStats(
        songId = songId,
        isHot = isHot,
        hotScore = hotScore,
        isCool = isCool,
        coolScore = coolScore,
        playCount = playCount,
        completedCount = completedCount,
        skipCount = skipCount,
        lastPlayedAt = lastPlayedAt
    )
}

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): Playlist = Playlist(
        id = id,
        name = name,
        createdAt = createdAt
    )
}

@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "trackId"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["trackId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId"), Index("trackId")]
)
data class PlaylistTrackCrossRef(
    val playlistId: Long,
    val trackId: Long,
    val sortOrder: Int = 0
)
