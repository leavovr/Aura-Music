package com.example.data.model

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.example.R

enum class TrackPreference {
    NEUTRAL,
    HOT,
    COOL
}

@Immutable
data class SongStats(
    val songId: Long,
    val isHot: Boolean = false,
    val hotScore: Float = 0f,
    val isCool: Boolean = false,
    val coolScore: Float = 0f,
    val playCount: Int = 0,
    val completedCount: Int = 0,
    val skipCount: Int = 0,
    val lastPlayedAt: Long = 0L
)

@Immutable
data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String = "",
    val vibe: String,
    val year: Int = 0,
    val durationMs: Long,
    val artworkKey: String,
    val artworkUri: String? = null,
    val audioUri: String,
    val dominantColorLong: Long,
    val secondaryColorLong: Long,
    val preference: TrackPreference = TrackPreference.NEUTRAL,
    val isLocalImport: Boolean = false
) {
    val dominantColor: Color get() = Color(dominantColorLong)
    val secondaryColor: Color get() = Color(secondaryColorLong)

    /**
     * Deterministic fallback among the 3 generated banners based on song id hash % 3,
     * used only when real embedded/MediaStore cover art is unavailable.
     */
    @DrawableRes
    fun deterministicFallbackDrawableRes(): Int {
        val bucket = (id.hashCode() and 0x7FFFFFFF) % 3
        return when (bucket) {
            0 -> R.drawable.img_art_golden_hour_1795374607072
            1 -> R.drawable.img_art_indigo_solitude_1795374592920
            else -> R.drawable.img_art_emerald_dawn_1795374592446
        }
    }
}

@Immutable
data class Playlist(
    val id: Long,
    val name: String,
    val createdAt: Long
)

@Immutable
data class PlaylistWithTracks(
    val playlist: Playlist,
    val tracks: List<Track>
)

sealed interface PlaybackSource {
    data class UserPlaylist(val playlist: Playlist) : PlaybackSource
    data object LikedSongs : PlaybackSource
}
