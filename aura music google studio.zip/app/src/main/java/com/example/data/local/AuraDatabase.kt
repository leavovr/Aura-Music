package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TrackEntity::class,
        SongStatsEntity::class,
        PlaylistEntity::class,
        PlaylistTrackCrossRef::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AuraDatabase : RoomDatabase() {
    abstract fun auraDao(): AuraDao

    companion object {
        @Volatile
        private var INSTANCE: AuraDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracks ADD COLUMN album TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE tracks ADD COLUMN year INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `song_stats` (
                        `songId` INTEGER NOT NULL,
                        `isHot` INTEGER NOT NULL,
                        `hotScore` REAL NOT NULL,
                        `isCool` INTEGER NOT NULL,
                        `coolScore` REAL NOT NULL,
                        `playCount` INTEGER NOT NULL,
                        `completedCount` INTEGER NOT NULL,
                        `skipCount` INTEGER NOT NULL,
                        `lastPlayedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`songId`),
                        FOREIGN KEY(`songId`) REFERENCES `tracks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                // Backfill existing Hot/Cool ratings into global song_stats table
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO song_stats (
                        songId, isHot, hotScore, isCool, coolScore,
                        playCount, completedCount, skipCount, lastPlayedAt
                    )
                    SELECT
                        id,
                        CASE WHEN preference = 'HOT' THEN 1 ELSE 0 END,
                        CASE WHEN preference = 'HOT' THEN 1.0 ELSE 0.0 END,
                        CASE WHEN preference = 'COOL' THEN 1 ELSE 0 END,
                        CASE WHEN preference = 'COOL' THEN 1.0 ELSE 0.0 END,
                        0, 0, 0, 0
                    FROM tracks
                    WHERE preference IN ('HOT', 'COOL')
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): AuraDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AuraDatabase::class.java,
                    "aura_music.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
