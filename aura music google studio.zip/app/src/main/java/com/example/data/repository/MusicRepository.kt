package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.R
import com.example.data.audio.AmbientTrackSynthesizer
import com.example.data.audio.SongArtworkLoader
import com.example.data.local.AuraDao
import com.example.data.local.PlaylistEntity
import com.example.data.local.SongStatsEntity
import com.example.data.local.TrackEntity
import com.example.data.model.PlaylistWithTracks
import com.example.data.model.SongStats
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class MusicRepository(
    private val context: Context,
    private val dao: AuraDao
) {
    val songStatsMapFlow: Flow<Map<Long, SongStats>> = dao.observeAllSongStats().map { list ->
        list.associate { it.songId to it.toDomain() }
    }

    val allTracksFlow: Flow<List<Track>> = combine(
        dao.observeAllTracks(),
        songStatsMapFlow
    ) { tracks, statsMap ->
        tracks.map { it.toDomain(statsMap[it.id]) }
    }

    val likedTracksFlow: Flow<List<Track>> = allTracksFlow.map { tracks ->
        tracks
            .filter { it.preference == TrackPreference.HOT }
            .distinctBy { it.id }
    }

    val playlistsWithTracksFlow: Flow<List<PlaylistWithTracks>> = combine(
        dao.observeAllPlaylists(),
        allTracksFlow,
        dao.observeAllPlaylistTrackRefs()
    ) { playlists, tracks, refs ->
        val trackMap = tracks.associateBy { it.id }
        val refsByPlaylist = refs.groupBy { it.playlistId }
        playlists.map { playlistEntity ->
            val playlistTracks = refsByPlaylist[playlistEntity.id]
                .orEmpty()
                .sortedBy { it.sortOrder }
                .mapNotNull { trackMap[it.trackId] }
            PlaylistWithTracks(
                playlist = playlistEntity.toDomain(),
                tracks = playlistTracks
            )
        }
    }

    suspend fun ensureSeededAndAudioReady() = withContext(Dispatchers.IO) {
        val existingCount = dao.getTrackCount()
        if (existingCount == 0) {
            val seedSpecs = listOf(
                SeedSpec(
                    title = "Golden Hour Nocturne",
                    artist = "Julian S. & The Glass Trio",
                    album = "Amber Studies",
                    vibe = "Ambient Jazz",
                    year = 2024,
                    synthKey = "golden_hour"
                ),
                SeedSpec(
                    title = "Indigo Solitude",
                    artist = "Elysian Ensemble",
                    album = "Nocturnes in Blue",
                    vibe = "Nocturne Piano",
                    year = 2023,
                    synthKey = "indigo_solitude"
                ),
                SeedSpec(
                    title = "Emerald Dawn",
                    artist = "Soren K.",
                    album = "Prismatic Calm",
                    vibe = "Ethereal Ambient",
                    year = 2024,
                    synthKey = "emerald_dawn"
                ),
                SeedSpec(
                    title = "Velvet Resonance",
                    artist = "Mira & Sol",
                    album = "After Midnight",
                    vibe = "Neo-Soul Lo-Fi",
                    year = 2025,
                    synthKey = "velvet_resonance"
                ),
                SeedSpec(
                    title = "Amber Afterglow",
                    artist = "Julian S. & The Glass Trio",
                    album = "Amber Studies",
                    vibe = "Ambient Jazz",
                    year = 2024,
                    synthKey = "amber_afterglow"
                ),
                SeedSpec(
                    title = "Midnight Prism",
                    artist = "Elysian Ensemble",
                    album = "Nocturnes in Blue",
                    vibe = "Ethereal Ambient",
                    year = 2023,
                    synthKey = "midnight_prism"
                )
            )

            val trackEntities = seedSpecs.map { spec ->
                val (uri, durationMs) = AmbientTrackSynthesizer.ensureTrackFile(context, spec.synthKey)
                TrackEntity(
                    title = spec.title,
                    artist = spec.artist,
                    album = spec.album,
                    vibe = spec.vibe,
                    year = spec.year,
                    durationMs = durationMs,
                    artworkKey = spec.synthKey,
                    artworkUri = null,
                    audioUri = uri,
                    dominantColorLong = 0xFFF59E0BL,
                    secondaryColorLong = 0xFF1E1B4BL,
                    preference = TrackPreference.NEUTRAL.name,
                    isLocalImport = false
                )
            }
            val insertedIds = dao.insertTracks(trackEntities)

            insertedIds.forEach { trackId ->
                val fallbackRes = deterministicFallbackRes(trackId)
                val (dom, sec) = SongArtworkLoader.extractPaletteFromDrawable(context, fallbackRes)
                dao.updateTrackArtworkAndColors(
                    trackId = trackId,
                    artworkUri = null,
                    dominantColor = dom,
                    secondaryColor = sec
                )
            }

            if (dao.getPlaylistCount() == 0 && insertedIds.isNotEmpty()) {
                val starterId = dao.insertPlaylist(
                    PlaylistEntity(
                        name = "My Playlist",
                        createdAt = System.currentTimeMillis()
                    )
                )
                dao.replacePlaylistTracks(starterId, insertedIds)
            }
        } else {
            listOf(
                "golden_hour", "indigo_solitude", "emerald_dawn",
                "velvet_resonance", "amber_afterglow", "midnight_prism"
            ).forEach { key ->
                AmbientTrackSynthesizer.ensureTrackFile(context, key)
            }
            cleanupLegacyAutoCategories()
            refreshExistingTracksMetadataAndArt()
        }
    }

    private suspend fun cleanupLegacyAutoCategories() {
        val playlists = dao.getAllPlaylistsOnce()
        if (playlists.size <= 1) return

        val seenNames = mutableSetOf<String>()
        playlists.forEach { playlist ->
            val lower = playlist.name.trim().lowercase()
            if (lower == "midnight glass" && playlists.size > 1) {
                dao.deletePlaylist(playlist.id)
            } else if (!seenNames.add(lower)) {
                dao.deletePlaylist(playlist.id)
            }
        }
    }

    private suspend fun refreshExistingTracksMetadataAndArt() {
        val unknownArtist = context.getString(R.string.label_unknown_artist)
        val tracks = dao.getAllTracksOnce()
        tracks.forEach { entity ->
            if (entity.artist == "Local Library") {
                dao.updateTrackArtist(entity.id, unknownArtist)
            }
            val domain = entity.toDomain()
            val fallbackRes = domain.deterministicFallbackDrawableRes()
            if (entity.isLocalImport) {
                val extracted = SongArtworkLoader.extractRealArtworkAndColors(
                    context = context,
                    songUri = Uri.parse(entity.audioUri),
                    trackId = entity.id,
                    fallbackDrawableRes = fallbackRes
                )
                if (extracted.cachedArtworkUri != entity.artworkUri ||
                    extracted.dominantColorLong != entity.dominantColorLong
                ) {
                    dao.updateTrackArtworkAndColors(
                        trackId = entity.id,
                        artworkUri = extracted.cachedArtworkUri,
                        dominantColor = extracted.dominantColorLong,
                        secondaryColor = extracted.secondaryColorLong
                    )
                }
            } else {
                val (dom, sec) = SongArtworkLoader.extractPaletteFromDrawable(context, fallbackRes)
                if (dom != entity.dominantColorLong || sec != entity.secondaryColorLong) {
                    dao.updateTrackArtworkAndColors(
                        trackId = entity.id,
                        artworkUri = null,
                        dominantColor = dom,
                        secondaryColor = sec
                    )
                }
            }
        }
    }

    suspend fun updateTrackPreference(trackId: Long, preference: TrackPreference) =
        withContext(Dispatchers.IO) {
            dao.updateTrackPreference(trackId, preference.name)
            val existing = dao.getSongStatsOnce(trackId) ?: SongStatsEntity(songId = trackId)
            val updated = when (preference) {
                TrackPreference.HOT -> existing.copy(
                    isHot = true,
                    hotScore = (existing.hotScore + 1f).coerceAtMost(5f),
                    isCool = false,
                    coolScore = 0f
                )
                TrackPreference.COOL -> existing.copy(
                    isHot = false,
                    hotScore = 0f,
                    isCool = true,
                    coolScore = (existing.coolScore + 1f).coerceAtMost(5f)
                )
                TrackPreference.NEUTRAL -> existing.copy(
                    isHot = false,
                    isCool = false
                )
            }
            dao.upsertSongStats(updated)
        }

    suspend fun recordPlayStart(trackId: Long, nowMs: Long = System.currentTimeMillis()) =
        withContext(Dispatchers.IO) {
            val existing = dao.getSongStatsOnce(trackId) ?: SongStatsEntity(songId = trackId)
            dao.upsertSongStats(
                existing.copy(
                    playCount = existing.playCount + 1,
                    lastPlayedAt = nowMs
                )
            )
        }

    suspend fun recordCompletion(trackId: Long) = withContext(Dispatchers.IO) {
        val existing = dao.getSongStatsOnce(trackId) ?: SongStatsEntity(songId = trackId)
        dao.upsertSongStats(
            existing.copy(
                playCount = maxOf(existing.playCount, existing.completedCount + 1),
                completedCount = existing.completedCount + 1
            )
        )
    }

    suspend fun recordEarlySkip(trackId: Long) = withContext(Dispatchers.IO) {
        val existing = dao.getSongStatsOnce(trackId) ?: SongStatsEntity(songId = trackId)
        dao.upsertSongStats(
            existing.copy(
                playCount = maxOf(existing.playCount, existing.skipCount + 1),
                skipCount = existing.skipCount + 1
            )
        )
    }

    suspend fun savePlaylist(
        existingPlaylistId: Long?,
        name: String,
        trackIds: List<Long>
    ): Long {
        val cleanName = name.trim().ifEmpty { "My Playlist" }
        val playlistId = if (existingPlaylistId != null && existingPlaylistId > 0L) {
            dao.updatePlaylistName(existingPlaylistId, cleanName)
            existingPlaylistId
        } else {
            dao.insertPlaylist(
                PlaylistEntity(
                    name = cleanName,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
        dao.replacePlaylistTracks(playlistId, trackIds)
        return playlistId
    }

    suspend fun importLocalAudioTracks(uris: List<Uri>): List<Long> = withContext(Dispatchers.IO) {
        val importedIds = mutableListOf<Long>()
        val unknownArtist = context.getString(R.string.label_unknown_artist)

        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }

            val retriever = MediaMetadataRetriever()
            var tagTitle: String? = null
            var tagArtist: String? = null
            var tagAlbum: String? = null
            var tagGenre: String? = null
            var tagYear = 0
            var durationMs = 180_000L

            try {
                retriever.setDataSource(context, uri)
                tagTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                tagArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                tagAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                tagGenre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
                tagYear = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
                    ?.take(4)
                    ?.toIntOrNull()
                    ?: 0
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.takeIf { it > 0L }
                    ?: 180_000L
            } catch (_: Exception) {
                // Fall back cleanly to filename metadata
            } finally {
                runCatching { retriever.release() }
            }

            val rawDisplayName = queryDisplayName(uri)
                ?.substringBeforeLast('.')
                ?.replace('_', ' ')
                ?.trim()

            var parsedTitle = tagTitle?.trim()?.takeIf { it.isNotBlank() }
            var parsedArtist = tagArtist?.trim()?.takeIf { it.isNotBlank() }

            if (parsedTitle == null && rawDisplayName != null && rawDisplayName.contains(" - ")) {
                val parts = rawDisplayName.split(" - ", limit = 2)
                if (parsedArtist == null && parts[0].isNotBlank()) {
                    parsedArtist = parts[0].trim()
                }
                parsedTitle = parts.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() } ?: rawDisplayName
            }

            val finalTitle = parsedTitle ?: rawDisplayName ?: "Untitled Track"
            val finalArtist = parsedArtist ?: unknownArtist
            val finalAlbum = tagAlbum?.trim().orEmpty()
            val finalVibe = tagGenre?.trim()?.takeIf { it.isNotBlank() } ?: "Audio"

            val insertedId = dao.insertTrack(
                TrackEntity(
                    title = finalTitle,
                    artist = finalArtist,
                    album = finalAlbum,
                    vibe = finalVibe,
                    year = tagYear,
                    durationMs = durationMs,
                    artworkKey = "local",
                    artworkUri = null,
                    audioUri = uri.toString(),
                    dominantColorLong = 0xFFF59E0BL,
                    secondaryColorLong = 0xFF1E1B4BL,
                    preference = TrackPreference.NEUTRAL.name,
                    isLocalImport = true
                )
            )

            val fallbackRes = deterministicFallbackRes(insertedId)
            val extracted = SongArtworkLoader.extractRealArtworkAndColors(
                context = context,
                songUri = uri,
                trackId = insertedId,
                fallbackDrawableRes = fallbackRes
            )
            dao.updateTrackArtworkAndColors(
                trackId = insertedId,
                artworkUri = extracted.cachedArtworkUri,
                dominantColor = extracted.dominantColorLong,
                secondaryColor = extracted.secondaryColorLong
            )

            importedIds += insertedId
        }
        importedIds
    }

    private fun deterministicFallbackRes(trackId: Long): Int {
        val bucket = (trackId.hashCode() and 0x7FFFFFFF) % 3
        return when (bucket) {
            0 -> R.drawable.img_art_golden_hour_1795374607072
            1 -> R.drawable.img_art_indigo_solitude_1795374592920
            else -> R.drawable.img_art_emerald_dawn_1795374592446
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        }.getOrNull()
    }

    private data class SeedSpec(
        val title: String,
        val artist: String,
        val album: String,
        val vibe: String,
        val year: Int,
        val synthKey: String
    )
}
