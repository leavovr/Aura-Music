package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AuraDao {

    @Query("SELECT * FROM tracks ORDER BY id ASC")
    fun observeAllTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks ORDER BY id ASC")
    suspend fun getAllTracksOnce(): List<TrackEntity>

    @Query("SELECT * FROM song_stats")
    fun observeAllSongStats(): Flow<List<SongStatsEntity>>

    @Query("SELECT * FROM song_stats WHERE songId = :songId LIMIT 1")
    suspend fun getSongStatsOnce(songId: Long): SongStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSongStats(stats: SongStatsEntity)

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observeAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylistsOnce(): List<PlaylistEntity>

    @Query("SELECT * FROM playlist_tracks ORDER BY sortOrder ASC")
    fun observeAllPlaylistTrackRefs(): Flow<List<PlaylistTrackCrossRef>>

    @Query("SELECT COUNT(*) FROM tracks")
    suspend fun getTrackCount(): Int

    @Query("SELECT COUNT(*) FROM playlists")
    suspend fun getPlaylistCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: TrackEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<TrackEntity>): List<Long>

    @Query("UPDATE tracks SET preference = :preference WHERE id = :trackId")
    suspend fun updateTrackPreference(trackId: Long, preference: String)

    @Query("UPDATE tracks SET audioUri = :audioUri WHERE id = :trackId")
    suspend fun updateTrackAudioUri(trackId: Long, audioUri: String)

    @Query(
        "UPDATE tracks SET artworkUri = :artworkUri, dominantColorLong = :dominantColor, secondaryColorLong = :secondaryColor WHERE id = :trackId"
    )
    suspend fun updateTrackArtworkAndColors(
        trackId: Long,
        artworkUri: String?,
        dominantColor: Long,
        secondaryColor: Long
    )

    @Query("UPDATE tracks SET artist = :artist WHERE id = :trackId")
    suspend fun updateTrackArtist(trackId: Long, artist: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :playlistId")
    suspend fun updatePlaylistName(playlistId: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun clearPlaylistTracks(playlistId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistTrackRefs(refs: List<PlaylistTrackCrossRef>)

    @Transaction
    suspend fun replacePlaylistTracks(playlistId: Long, trackIds: List<Long>) {
        clearPlaylistTracks(playlistId)
        val refs = trackIds.distinct().mapIndexed { index, trackId ->
            PlaylistTrackCrossRef(playlistId = playlistId, trackId = trackId, sortOrder = index)
        }
        insertPlaylistTrackRefs(refs)
    }
}
