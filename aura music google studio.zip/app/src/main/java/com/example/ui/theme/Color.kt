package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian Luxury Surfaces
val AuraObsidian = Color(0xFF08090C)
val AuraObsidianSurface = Color(0xFF12131A)
val AuraObsidianElevated = Color(0xFF191B24)

// Glassmorphism Translucent Layers
val GlassFillSubtle = Color(0x12FFFFFF)     // ~7% white
val GlassFillButton = Color(0x18FFFFFF)     // ~9.5% white
val GlassFillElevated = Color(0x26FFFFFF)   // ~15% white
val GlassBorderSubtle = Color(0x22FFFFFF)   // ~13% white
val GlassBorderStrong = Color(0x40FFFFFF)   // ~25% white

// Typography On-Dark Hierarchy
val AuraTextPrimary = Color(0xFFF8FAFC)
val AuraTextSecondary = Color(0x99FFFFFF)   // 60% white
val AuraTextMuted = Color(0x66FFFFFF)       // 40% white

// Hot (Like) Warm Ember Palette
val HotAmber = Color(0xFFF59E0B)
val HotCoral = Color(0xFFEF4444)
val HotGlowWash = Color(0x66EA580C)

// Cool (Dislike) Frost Palette
val CoolSky = Color(0xFF38BDF8)
val CoolDeep = Color(0xFF0284C7)
val CoolGlowWash = Color(0x660284C7)

// Active / Lossless Accent
val AuraEmerald = Color(0xFF34D399)

// Curated Album Art Dominant Accents
val ArtAmberDominant = Color(0xFFF59E0B)
val ArtAmberSecondary = Color(0xFF78350F)
val ArtIndigoDominant = Color(0xFF3B82F6)
val ArtIndigoSecondary = Color(0xFF1E3A8A)
val ArtEmeraldDominant = Color(0xFF10B981)
val ArtEmeraldSecondary = Color(0xFF064E3B)
val ArtCrimsonDominant = Color(0xFFE11D48)
val ArtCrimsonSecondary = Color(0xFF881337)
val ArtGoldDominant = Color(0xFFD97706)
val ArtGoldSecondary = Color(0xFF451A03)
val ArtVioletDominant = Color(0xFF6366F1)
val ArtVioletSecondary = Color(0xFF312E81)
