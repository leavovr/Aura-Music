package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Track
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.CoolDeep
import com.example.ui.theme.CoolSky
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.GlassFillButton
import com.example.ui.theme.GlassFillSubtle
import com.example.ui.theme.HotAmber
import com.example.ui.theme.HotCoral
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tinder-style swipeable album banner carousel with velocity-based fling,
 * spring center settle, and GPU-accelerated parallax peeking cards.
 */
@Composable
fun SwipeableAlbumCarousel(
    currentTrack: Track,
    previousTrack: Track?,
    nextTrack: Track?,
    trackNumberLabel: String,
    onSwipeNext: () -> Unit,
    onSwipePrevious: () -> Unit,
    modifier: Modifier = Modifier
) {
    val reduceMotion = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val dragOffsetX = remember { Animatable(0f) }
    val incomingScale = remember { Animatable(1f) }
    val incomingAlpha = remember { Animatable(1f) }

    // Smooth spring entrance whenever the center track changes
    LaunchedEffect(currentTrack.id) {
        dragOffsetX.snapTo(0f)
        if (reduceMotion) {
            incomingScale.snapTo(1f)
            incomingAlpha.snapTo(0.45f)
            incomingAlpha.animateTo(1f, tween(180))
        } else {
            incomingScale.snapTo(0.90f)
            incomingAlpha.snapTo(0.70f)
            launch {
                incomingScale.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(
                        dampingRatio = 0.76f,
                        stiffness = Spring.StiffnessMediumLow
                    )
                )
            }
            launch {
                incomingAlpha.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMedium
                    )
                )
            }
        }
    }

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        val heroWidth = (maxWidth * 0.70f).coerceIn(220.dp, 310.dp)
        val heroHeight = (heroWidth * 1.16f).coerceIn(250.dp, 355.dp)
        val peekWidth = heroWidth * 0.64f
        val peekHeight = heroHeight * 0.68f

        val swipeThresholdPx = with(density) { 98.dp.toPx() }
        val flingVelocityThresholdPx = with(density) { 680.dp.toPx() }
        val flyOutDistancePx = with(density) { (maxWidth * 1.05f).toPx() }
        val basePeekOffsetPx = with(density) { ((maxWidth / 2) - (peekWidth * 0.14f)).toPx() }
        val parallaxShiftPx = with(density) { 54.dp.toPx() }

        val progress = (dragOffsetX.value / swipeThresholdPx).coerceIn(-1.4f, 1.4f)
        val leftDragProgress = (-progress).coerceIn(0f, 1f)
        val rightDragProgress = progress.coerceIn(0f, 1f)

        // Left peeking banner (previous track) with subtle GPU parallax
        if (previousTrack != null) {
            val prevScale = 0.86f + (0.14f * rightDragProgress) - (0.04f * leftDragProgress)
            val prevAlpha = (0.44f + (0.46f * rightDragProgress) - (0.12f * leftDragProgress)).coerceIn(0.25f, 0.92f)
            val prevTx = -basePeekOffsetPx + (progress * parallaxShiftPx)

            PeekingAlbumBannerCard(
                track = previousTrack,
                contentDescription = stringResource(R.string.cd_prev_album_art),
                modifier = Modifier
                    .width(peekWidth)
                    .height(peekHeight)
                    .graphicsLayer {
                        translationX = prevTx
                        scaleX = prevScale
                        scaleY = prevScale
                        alpha = prevAlpha
                    }
                    .blur((2.5f * (1f - rightDragProgress)).coerceAtLeast(0f).dp)
                    .pressScaleClickable(pressedScale = 0.96f, onClick = onSwipePrevious)
            )
        }

        // Right peeking banner (upcoming track) with subtle GPU parallax
        if (nextTrack != null) {
            val nextScale = 0.86f + (0.14f * leftDragProgress) - (0.04f * rightDragProgress)
            val nextAlpha = (0.44f + (0.46f * leftDragProgress) - (0.12f * rightDragProgress)).coerceIn(0.25f, 0.92f)
            val nextTx = basePeekOffsetPx + (progress * parallaxShiftPx)

            PeekingAlbumBannerCard(
                track = nextTrack,
                contentDescription = stringResource(R.string.cd_next_album_art),
                modifier = Modifier
                    .width(peekWidth)
                    .height(peekHeight)
                    .graphicsLayer {
                        translationX = nextTx
                        scaleX = nextScale
                        scaleY = nextScale
                        alpha = nextAlpha
                    }
                    .blur((2.5f * (1f - leftDragProgress)).coerceAtLeast(0f).dp)
                    .pressScaleClickable(pressedScale = 0.96f, onClick = onSwipeNext)
            )
        }

        // Center swipeable hero banner
        val rotationDeg = if (reduceMotion) 0f else (progress * 11.5f).coerceIn(-16f, 16f)
        val centerScale = ((1f - (abs(progress) * 0.045f)).coerceAtLeast(0.92f)) * incomingScale.value
        val centerAlpha = ((1f - (abs(progress) * 0.22f)).coerceIn(0.62f, 1f)) * incomingAlpha.value

        Box(
            modifier = Modifier
                .width(heroWidth)
                .height(heroHeight)
                .graphicsLayer {
                    translationX = dragOffsetX.value
                    rotationZ = rotationDeg
                    scaleX = centerScale
                    scaleY = centerScale
                    alpha = centerAlpha
                }
                .pointerInput(currentTrack.id, nextTrack?.id, previousTrack?.id) {
                    val velocityTracker = VelocityTracker()
                    detectHorizontalDragGestures(
                        onDragStart = {
                            velocityTracker.resetTracking()
                        },
                        onDragEnd = {
                            val velocityX = velocityTracker.calculateVelocity().x
                            scope.launch {
                                val currentOffset = dragOffsetX.value
                                val flingNext = nextTrack != null && (
                                    currentOffset <= -swipeThresholdPx ||
                                        (velocityX <= -flingVelocityThresholdPx && currentOffset < -18f)
                                    )
                                val flingPrev = previousTrack != null && (
                                    currentOffset >= swipeThresholdPx ||
                                        (velocityX >= flingVelocityThresholdPx && currentOffset > 18f)
                                    )
                                when {
                                    flingNext -> {
                                        if (!reduceMotion) {
                                            dragOffsetX.animateTo(
                                                targetValue = -flyOutDistancePx,
                                                initialVelocity = velocityX.coerceAtMost(-600f),
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                                    stiffness = Spring.StiffnessMediumLow
                                                )
                                            )
                                        }
                                        onSwipeNext()
                                        dragOffsetX.snapTo(0f)
                                    }
                                    flingPrev -> {
                                        if (!reduceMotion) {
                                            dragOffsetX.animateTo(
                                                targetValue = flyOutDistancePx,
                                                initialVelocity = velocityX.coerceAtLeast(600f),
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                                    stiffness = Spring.StiffnessMediumLow
                                                )
                                            )
                                        }
                                        onSwipePrevious()
                                        dragOffsetX.snapTo(0f)
                                    }
                                    else -> {
                                        dragOffsetX.animateTo(
                                            targetValue = 0f,
                                            animationSpec = if (reduceMotion) {
                                                snap()
                                            } else {
                                                spring(
                                                    dampingRatio = 0.72f,
                                                    stiffness = Spring.StiffnessMedium
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        },
                        onDragCancel = {
                            scope.launch {
                                dragOffsetX.animateTo(
                                    targetValue = 0f,
                                    animationSpec = if (reduceMotion) {
                                        snap()
                                    } else {
                                        spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMedium)
                                    }
                                )
                            }
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            velocityTracker.addPosition(change.uptimeMillis, change.position)
                            scope.launch {
                                dragOffsetX.snapTo(dragOffsetX.value + dragAmount)
                            }
                        }
                    )
                }
                .testTag("hero_album_card")
        ) {
            HeroAlbumBannerCard(
                track = currentTrack,
                trackNumberLabel = trackNumberLabel,
                modifier = Modifier.fillMaxSize()
            )

            val showNextTag = leftDragProgress > 0.25f
            val showPrevTag = rightDragProgress > 0.25f
            if (showNextTag || showPrevTag) {
                Box(
                    modifier = Modifier
                        .align(if (showNextTag) Alignment.TopEnd else Alignment.TopStart)
                        .padding(16.dp)
                        .graphicsLayer {
                            rotationZ = if (reduceMotion) 0f else if (showNextTag) 10f else -10f
                            alpha = maxOf(leftDragProgress, rightDragProgress).coerceIn(0f, 1f)
                        }
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.56f))
                        .border(1.dp, HotAmber.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 11.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = stringResource(
                            if (showNextTag) R.string.label_next_song else R.string.label_prev_song
                        ),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = HotAmber
                    )
                }
            }
        }
    }
}

/**
 * Minimal thin progress scrubber whose thumb grows smoothly with spring physics when touched,
 * paired with a light haptic click as scrubbing begins.
 */
@Composable
fun MinimalProgressScrubber(
    positionMs: Long,
    durationMs: Long,
    accentColor: Color,
    onSeekTo: (Long) -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val haptics = LocalHapticFeedback.current
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }

    val liveFraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val displayedFraction = if (isScrubbing) scrubFraction else liveFraction
    val displayedMs = if (isScrubbing) (scrubFraction * durationMs).toLong() else positionMs

    val thumbScale by animateFloatAsState(
        targetValue = if (isScrubbing) 1.55f else 1.0f,
        animationSpec = if (reduceMotion) {
            snap()
        } else {
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            )
        },
        label = "scrubber_thumb_scale"
    )
    val trackHeightScale by animateFloatAsState(
        targetValue = if (isScrubbing) 1.45f else 1.0f,
        animationSpec = if (reduceMotion) {
            snap()
        } else {
            spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium)
        },
        label = "scrubber_track_scale"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .pointerInput(durationMs) {
                    detectTapGestures { offset ->
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        val frac = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onSeekTo((frac * durationMs).toLong())
                    }
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            isScrubbing = true
                            scrubFraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            onSeekTo((scrubFraction * durationMs).toLong())
                            isScrubbing = false
                        },
                        onDragCancel = { isScrubbing = false },
                        onHorizontalDrag = { change, _ ->
                            scrubFraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        }
                    )
                }
                .testTag("progress_scrubber"),
            contentAlignment = Alignment.CenterStart
        ) {
            val widthPx = with(LocalDensity.current) { maxWidth.toPx() }
            val thumbSizeDp = 9.dp
            val thumbSizePx = with(LocalDensity.current) { thumbSizeDp.toPx() }

            // Thin glass track
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .graphicsLayer { scaleY = trackHeightScale }
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(displayedFraction.coerceIn(0.001f, 1f))
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.92f),
                                    accentColor.copy(alpha = 0.95f)
                                )
                            )
                        )
                )
            }

            // Subtle thumb that springs larger while touched
            Box(
                modifier = Modifier
                    .size(thumbSizeDp)
                    .graphicsLayer {
                        translationX = ((widthPx - thumbSizePx) * displayedFraction).coerceIn(0f, (widthPx - thumbSizePx).coerceAtLeast(0f))
                        scaleX = thumbScale
                        scaleY = thumbScale
                        alpha = if (isScrubbing) 1f else 0.88f
                    }
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.dp, accentColor.copy(alpha = 0.7f), CircleShape)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatDurationMs(displayedMs),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
                color = AuraTextMuted
            )
            Text(
                text = formatDurationMs(durationMs),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
                color = AuraTextMuted
            )
        }
    }
}

/**
 * Harmonious 5-button glass control row with 60 fps spring micro-interactions:
 *   [Lo-fi]   [Hot + 7-particle burst]   [Morphing Play/Pause + breathing glow]   [Cool + crack/drop]   [8D + rotating orbit]
 */
@Composable
fun NowPlayingControlsRow(
    isPlaying: Boolean,
    isHot: Boolean,
    isCool: Boolean,
    isLofiEnabled: Boolean,
    isEightDEnabled: Boolean,
    effectAccentColor: Color,
    onLofiClick: () -> Unit,
    onHotClick: () -> Unit,
    onHotActivatedEffect: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onCoolClick: () -> Unit,
    onCoolActivatedEffect: () -> Unit,
    onEightDClick: () -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val lofiCd = stringResource(R.string.cd_lofi_button)
    val hotCd = stringResource(R.string.cd_hot_button)
    val playPauseCd = stringResource(R.string.cd_play_pause)
    val coolCd = stringResource(R.string.cd_cool_button)
    val eightDCd = stringResource(R.string.cd_8d_button)

    // Hot spring bounce + 7-particle burst progress
    val hotBounceScale = remember { Animatable(1f) }
    val hotParticles = remember { Animatable(0f) }

    // Cool shake + fracture crack-drop progress
    val coolShakeX = remember { Animatable(0f) }
    val coolCrack = remember { Animatable(0f) }

    val hotRestScale by animateFloatAsState(
        targetValue = if (isHot) 1.06f else 1.0f,
        animationSpec = if (reduceMotion) snap() else spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "hot_rest_scale"
    )
    val coolRestScale by animateFloatAsState(
        targetValue = if (isCool) 1.05f else 1.0f,
        animationSpec = if (reduceMotion) snap() else spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cool_rest_scale"
    )
    val lofiGlow by animateFloatAsState(
        targetValue = if (isLofiEnabled) 1f else 0f,
        animationSpec = if (reduceMotion) snap() else spring(
            dampingRatio = 0.78f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "lofi_glow"
    )
    val eightDGlow by animateFloatAsState(
        targetValue = if (isEightDEnabled) 1f else 0f,
        animationSpec = if (reduceMotion) snap() else spring(
            dampingRatio = 0.78f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "eight_d_glow"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "controls_ambient")
    val playBreath by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "play_glow_breath"
    )
    val eightDOrbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "eight_d_orbit"
    )

    Row(
        modifier = Modifier
            .widthIn(max = 440.dp)
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. FAR LEFT: LO-FI EFFECT TOGGLE
        AudioEffectGlassToggle(
            label = stringResource(R.string.label_lofi),
            contentDescription = lofiCd,
            isActive = isLofiEnabled,
            glowFraction = lofiGlow,
            accentColor = effectAccentColor,
            onClick = onLofiClick,
            testTagName = "lofi_toggle_button"
        ) { iconTint ->
            AuraLofiIcon(tint = iconTint, size = 18.dp)
        }

        // 2. HOT (LIKE) GLASS BUTTON WITH SPRING BOUNCE + 7-PARTICLE BURST
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier.size(64.dp),
                contentAlignment = Alignment.Center
            ) {
                // Lightweight 7-particle warm burst ring
                val burst = hotParticles.value
                if (burst in 0.01f..0.99f && !reduceMotion) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cx = size.width * 0.5f
                        val cy = size.height * 0.5f
                        val particleCount = 7
                        val alpha = (1f - burst).coerceIn(0f, 1f)
                        val baseR = size.minDimension * 0.34f
                        val travel = size.minDimension * 0.34f * burst
                        for (i in 0 until particleCount) {
                            val angle = (i.toDouble() * 2.0 * PI / particleCount) - (PI / 2.0)
                            val px = cx + (baseR + travel) * cos(angle).toFloat()
                            val py = cy + (baseR + travel) * sin(angle).toFloat()
                            val radius = (3.2.dp.toPx() * (1f - burst * 0.55f)).coerceAtLeast(1.2f)
                            val color = if (i % 2 == 0) HotAmber else HotCoral
                            drawCircle(
                                color = color.copy(alpha = alpha * 0.9f),
                                radius = radius,
                                center = Offset(px, py)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .graphicsLayer {
                            val combined = hotRestScale * hotBounceScale.value
                            scaleX = combined
                            scaleY = combined
                        }
                        .drawBehind {
                            if (isHot) {
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            HotCoral.copy(alpha = 0.45f),
                                            HotAmber.copy(alpha = 0.20f),
                                            Color.Transparent
                                        )
                                    ),
                                    radius = size.minDimension * 0.95f
                                )
                            }
                        }
                        .clip(CircleShape)
                        .background(if (isHot) HotAmber.copy(alpha = 0.20f) else GlassFillButton)
                        .border(
                            width = if (isHot) 1.25.dp else 1.dp,
                            color = if (isHot) HotAmber.copy(alpha = 0.85f) else GlassBorderSubtle,
                            shape = CircleShape
                        )
                        .pressScaleClickable {
                            val becomingHot = !isHot
                            onHotClick()
                            if (becomingHot) {
                                onHotActivatedEffect()
                                if (!reduceMotion) {
                                    scope.launch {
                                        hotBounceScale.snapTo(1.26f)
                                        hotBounceScale.animateTo(
                                            targetValue = 1f,
                                            animationSpec = spring(
                                                dampingRatio = 0.48f,
                                                stiffness = Spring.StiffnessMediumLow
                                            )
                                        )
                                    }
                                    scope.launch {
                                        hotParticles.snapTo(0.02f)
                                        hotParticles.animateTo(
                                            targetValue = 1f,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioNoBouncy,
                                                stiffness = 190f
                                            )
                                        )
                                        hotParticles.snapTo(0f)
                                    }
                                }
                            }
                        }
                        .semantics { contentDescription = hotCd }
                        .testTag("hot_button"),
                    contentAlignment = Alignment.Center
                ) {
                    AuraHotHeartIcon(
                        tint = if (isHot) HotAmber else Color.White.copy(alpha = 0.80f),
                        isActive = isHot,
                        size = 22.dp
                    )
                }
            }

            Text(
                text = stringResource(R.string.label_hot),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isHot) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isHot) HotAmber else AuraTextMuted
            )
        }

        // 3. CENTER: LARGE GLASS PLAY / PAUSE WITH MORPHING ICON + BREATHING GLOW
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .drawBehind {
                        val breathScale = if (isPlaying && !reduceMotion) playBreath else 0.94f
                        val glowAlpha = if (isPlaying) 0.28f else 0.12f
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = glowAlpha),
                                    effectAccentColor.copy(alpha = if (isPlaying) 0.14f else 0.04f),
                                    Color.Transparent
                                )
                            ),
                            radius = size.minDimension * 0.86f * breathScale
                        )
                    }
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.20f),
                                Color.White.copy(alpha = 0.09f)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        color = GlassBorderStrong,
                        shape = CircleShape
                    )
                    .pressScaleClickable(onClick = onPlayPauseClick)
                    .semantics { contentDescription = playPauseCd }
                    .testTag("play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                AuraMorphingPlayPauseIcon(
                    isPlaying = isPlaying,
                    tint = Color.White,
                    size = 28.dp
                )
            }

            Text(
                text = stringResource(if (isPlaying) R.string.label_playing else R.string.label_paused),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
                color = AuraTextMuted
            )
        }

        // 4. COOL (DISLIKE) GLASS BUTTON WITH SHAKE + CRACK & DROP ANIMATION
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier.size(64.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .graphicsLayer {
                            translationX = coolShakeX.value
                            scaleX = coolRestScale
                            scaleY = coolRestScale
                        }
                        .drawBehind {
                            if (isCool || coolCrack.value > 0.02f) {
                                val alphaFactor = if (isCool) 1f else coolCrack.value
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            CoolSky.copy(alpha = 0.45f * alphaFactor),
                                            CoolDeep.copy(alpha = 0.22f * alphaFactor),
                                            Color.Transparent
                                        )
                                    ),
                                    radius = size.minDimension * 0.95f
                                )
                            }
                        }
                        .clip(CircleShape)
                        .background(if (isCool) CoolSky.copy(alpha = 0.20f) else GlassFillButton)
                        .border(
                            width = if (isCool) 1.25.dp else 1.dp,
                            color = if (isCool) CoolSky.copy(alpha = 0.85f) else GlassBorderSubtle,
                            shape = CircleShape
                        )
                        .pressScaleClickable {
                            val becomingCool = !isCool
                            onCoolClick()
                            if (becomingCool) {
                                onCoolActivatedEffect()
                                if (!reduceMotion) {
                                    scope.launch {
                                        // Crisp horizontal micro-shake
                                        coolShakeX.animateTo(-7f, spring(stiffness = Spring.StiffnessHigh))
                                        coolShakeX.animateTo(6f, spring(stiffness = Spring.StiffnessHigh))
                                        coolShakeX.animateTo(-3f, spring(stiffness = Spring.StiffnessHigh))
                                        coolShakeX.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium))
                                    }
                                    scope.launch {
                                        // Crack apart, drop slightly, then settle back
                                        coolCrack.snapTo(0f)
                                        coolCrack.animateTo(
                                            targetValue = 1f,
                                            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
                                        )
                                        coolCrack.animateTo(
                                            targetValue = 0f,
                                            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessLow)
                                        )
                                    }
                                }
                            }
                        }
                        .semantics { contentDescription = coolCd }
                        .testTag("cool_button"),
                    contentAlignment = Alignment.Center
                ) {
                    AuraCoolBrokenHeartIcon(
                        tint = if (isCool || coolCrack.value > 0.05f) CoolSky else Color.White.copy(alpha = 0.80f),
                        isActive = isCool,
                        crackProgress = coolCrack.value,
                        size = 22.dp
                    )
                }
            }

            Text(
                text = stringResource(R.string.label_cool),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isCool) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isCool) CoolSky else AuraTextMuted
            )
        }

        // 5. FAR RIGHT: 8D SPATIAL EFFECT TOGGLE WITH CONTINUOUS SLOW ORBIT ROTATION
        AudioEffectGlassToggle(
            label = stringResource(R.string.label_8d),
            contentDescription = eightDCd,
            isActive = isEightDEnabled,
            glowFraction = eightDGlow,
            accentColor = effectAccentColor,
            onClick = onEightDClick,
            testTagName = "eight_d_toggle_button"
        ) { iconTint ->
            val activeOrbit = if (isEightDEnabled && !reduceMotion) eightDOrbitAngle else 0f
            AuraEightDIcon(
                tint = iconTint,
                orbitAngleDegrees = activeOrbit,
                modifier = Modifier.graphicsLayer {
                    if (isEightDEnabled && !reduceMotion) {
                        rotationZ = activeOrbit * 0.25f
                    }
                },
                size = 18.dp
            )
        }
    }
}

@Composable
private fun AudioEffectGlassToggle(
    label: String,
    contentDescription: String,
    isActive: Boolean,
    glowFraction: Float,
    accentColor: Color,
    onClick: () -> Unit,
    testTagName: String,
    iconContent: @Composable (Color) -> Unit
) {
    val scale = 1f + (0.06f * glowFraction)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // 48dp accessible touch hitbox enclosing a refined 42dp frosted glass circle
        Box(
            modifier = Modifier
                .size(48.dp)
                .pressScaleClickable(onClick = onClick)
                .semantics { this.contentDescription = contentDescription }
                .testTag(testTagName),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .drawBehind {
                        if (glowFraction > 0.01f) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        accentColor.copy(alpha = 0.50f * glowFraction),
                                        accentColor.copy(alpha = 0.18f * glowFraction),
                                        Color.Transparent
                                    )
                                ),
                                radius = size.minDimension * 0.98f
                            )
                        }
                    }
                    .clip(CircleShape)
                    .background(
                        if (glowFraction > 0.01f) {
                            accentColor.copy(alpha = 0.22f * glowFraction)
                        } else {
                            GlassFillSubtle
                        }
                    )
                    .border(
                        width = if (isActive) 1.15.dp else 0.9.dp,
                        color = if (isActive) accentColor.copy(alpha = 0.85f) else GlassBorderSubtle,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                iconContent(
                    if (isActive) accentColor else Color.White.copy(alpha = 0.54f)
                )
            }
        }

        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 0.5.sp,
            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isActive) accentColor else AuraTextMuted
        )
    }
}
