package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import com.example.ui.components.AuraHotHeartIcon
import com.example.ui.components.AuraShuffleIcon
import com.example.ui.components.AuraSongsListIcon
import com.example.ui.components.AuraTrackArtworkImage
import com.example.ui.components.LikedSongsDrawerOverlay
import com.example.ui.components.LikedUndoSnackbar
import com.example.ui.components.LocalReduceMotion
import com.example.ui.components.MinimalProgressScrubber
import com.example.ui.components.NowPlayingControlsRow
import com.example.ui.components.SongsListDrawerOverlay
import com.example.ui.components.SwipeableAlbumCarousel
import com.example.ui.components.pressScaleClickable
import com.example.ui.theme.AuraObsidian
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.CoolDeep
import com.example.ui.theme.CoolGlowWash
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.GlassFillSubtle
import com.example.ui.theme.HotAmber
import com.example.ui.theme.HotCoral
import com.example.ui.theme.HotGlowWash
import com.example.ui.viewmodel.AuraUiState
import kotlinx.coroutines.launch

@Composable
fun NowPlayingScreen(
    uiState: AuraUiState,
    onTogglePlayPause: () -> Unit,
    onToggleLofi: () -> Unit,
    onToggleEightD: () -> Unit,
    onSwipeNext: () -> Unit,
    onSwipePrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleHot: () -> Unit,
    onToggleCool: () -> Unit,
    onToggleShuffle: () -> Unit,
    onSelectTrack: (Long) -> Unit,
    onSwitchPlaylist: (Long) -> Unit,
    onNavigateToCreatePlaylist: (Long?) -> Unit,
    onPlayLiked: () -> Unit,
    onShuffleLiked: () -> Unit,
    onSelectLikedTrack: (Long) -> Unit,
    onRemoveFromLiked: (Track) -> Unit,
    onUndoRemoveLiked: () -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current

    var showSongsDrawer by remember { mutableStateOf(false) }
    var showLikedDrawer by remember { mutableStateOf(false) }
    val anySheetOpen = showSongsDrawer || showLikedDrawer

    val currentTrack = uiState.currentTrack
    val isHot = currentTrack?.preference == TrackPreference.HOT
    val isCool = currentTrack?.preference == TrackPreference.COOL

    // Transient one-shot ambient glow pulse on Hot tap & cool-blue wash on Cool tap
    val hotBgPulse = remember { Animatable(0f) }
    val coolBgWashPulse = remember { Animatable(0f) }

    // Smooth ~500 ms cross-fade for Palette-extracted dominant colors
    val artworkAccentColor by animateColorAsState(
        targetValue = currentTrack?.dominantColor ?: HotAmber,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "artwork_accent"
    )

    val targetAmbientColor = when {
        isHot -> HotCoral
        isCool -> CoolDeep
        currentTrack != null -> currentTrack.dominantColor
        else -> HotAmber
    }
    val targetSecondaryColor = currentTrack?.secondaryColor ?: Color(0xFF1E1B4B)

    val animatedAmbientColor by animateColorAsState(
        targetValue = targetAmbientColor,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "ambient_color"
    )
    val animatedSecondaryColor by animateColorAsState(
        targetValue = targetSecondaryColor,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "secondary_color"
    )

    val washColor by animateColorAsState(
        targetValue = when {
            isHot -> HotGlowWash
            isCool -> CoolGlowWash
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 500),
        label = "preference_wash"
    )

    // Backdrop depth: softly scale down and blur Now Playing when a bottom sheet opens
    val backdropScale by animateFloatAsState(
        targetValue = if (anySheetOpen && !reduceMotion) 0.94f else 1f,
        animationSpec = if (reduceMotion) {
            snap()
        } else {
            spring(dampingRatio = 0.86f, stiffness = Spring.StiffnessMediumLow)
        },
        label = "backdrop_scale"
    )
    val backdropBlur by animateDpAsState(
        targetValue = if (anySheetOpen && !reduceMotion) 10.dp else 0.dp,
        animationSpec = if (reduceMotion) {
            snap()
        } else {
            spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow)
        },
        label = "backdrop_blur"
    )

    val infiniteAura = rememberInfiniteTransition(label = "aura_breathe")
    val auraBreath by infiniteAura.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_breath_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraObsidian)
    ) {
        // =========================================================================
        // DEPTH LAYER: BACKGROUND + NOW PLAYING (softly scales & blurs under sheets)
        // =========================================================================
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = backdropScale
                    scaleY = backdropScale
                }
                .then(if (backdropBlur > 0.2.dp) Modifier.blur(backdropBlur) else Modifier)
        ) {
            // LAYER 1: FULL-SCREEN BLURRED REAL ALBUM ARTWORK (~500ms crossfade) + AMBIENT GLOW
            Crossfade(
                targetState = currentTrack,
                animationSpec = tween(durationMillis = 500),
                label = "bg_art_crossfade",
                modifier = Modifier.fillMaxSize()
            ) { track ->
                if (track != null) {
                    AuraTrackArtworkImage(
                        track = track,
                        contentDescription = null,
                        targetSizePx = 256,
                        modifier = Modifier
                            .fillMaxSize()
                            .scale(1.22f)
                            .blur(radius = 52.dp, edgeTreatment = BlurredEdgeTreatment.Unbounded)
                            .alpha(0.55f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xCC08090C),
                                    animatedSecondaryColor.copy(alpha = 0.44f),
                                    Color(0xDF08090C)
                                )
                            )
                        )

                        val glowScale = if (uiState.isPlaying && !reduceMotion) auraBreath else 0.95f
                        val hotPulseBoost = hotBgPulse.value
                        val glowRadius = size.minDimension * (0.84f * glowScale + 0.18f * hotPulseBoost)
                        val baseAlpha = if (isHot || isCool) 0.48f else 0.38f
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    animatedAmbientColor.copy(alpha = (baseAlpha + 0.22f * hotPulseBoost).coerceAtMost(0.75f)),
                                    animatedAmbientColor.copy(alpha = 0.14f + 0.10f * hotPulseBoost),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.5f, size.height * 0.46f),
                                radius = glowRadius
                            ),
                            center = Offset(size.width * 0.5f, size.height * 0.46f),
                            radius = glowRadius
                        )

                        if (washColor.alpha > 0.01f) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        washColor,
                                        washColor.copy(alpha = washColor.alpha * 0.3f),
                                        Color.Transparent
                                    ),
                                    center = Offset(size.width * 0.5f, size.height * 0.50f),
                                    radius = size.maxDimension * 0.72f
                                ),
                                center = Offset(size.width * 0.5f, size.height * 0.50f),
                                radius = size.maxDimension * 0.72f
                            )
                        }

                        // Soft transient cool-blue wash when tapping Cool before soft-skip
                        val coolTransient = coolBgWashPulse.value
                        if (coolTransient > 0.01f) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        CoolDeep.copy(alpha = 0.36f * coolTransient),
                                        CoolGlowWash.copy(alpha = 0.24f * coolTransient),
                                        Color.Transparent
                                    ),
                                    center = Offset(size.width * 0.5f, size.height * 0.52f),
                                    radius = size.maxDimension * 0.76f
                                ),
                                center = Offset(size.width * 0.5f, size.height * 0.52f),
                                radius = size.maxDimension * 0.76f
                            )
                        }
                    }
            )

            // LAYER 2: MAIN NOW PLAYING CONTENT
            if (uiState.isLoading && currentTrack == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = HotAmber,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(32.dp)
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // 1. TOP BAR: SHUFFLE (LEFT) • HEADER TITLE (CENTER) • LIKED + SONGS LIST (RIGHT)
                    NowPlayingTopBar(
                        headerTitle = uiState.headerTitle,
                        isPlayingLiked = uiState.isPlayingLiked,
                        isSmartShuffleEnabled = uiState.isSmartShuffleEnabled,
                        accentColor = artworkAccentColor,
                        onShuffleClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleShuffle()
                        },
                        onHeaderTitleClick = {
                            if (uiState.isPlayingLiked) {
                                showLikedDrawer = true
                            } else {
                                showSongsDrawer = true
                            }
                        },
                        onLikedClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showLikedDrawer = true
                        },
                        onSongsListClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showSongsDrawer = true
                        }
                    )

                    // 2. CENTER STAGE: PEEKING BANNERS + VELOCITY-FLING HERO CARD
                    if (currentTrack != null) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            SwipeableAlbumCarousel(
                                currentTrack = currentTrack,
                                previousTrack = uiState.previousTrack,
                                nextTrack = uiState.nextTrack,
                                trackNumberLabel = "Track #%02d".format(uiState.currentIndex + 1),
                                onSwipeNext = {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onSwipeNext()
                                },
                                onSwipePrevious = {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onSwipePrevious()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f, fill = false)
                            )

                            Spacer(modifier = Modifier.height(22.dp))

                            Column(
                                modifier = Modifier
                                    .widthIn(max = 360.dp)
                                    .fillMaxWidth()
                                    .padding(horizontal = 34.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AnimatedContent(
                                    targetState = currentTrack.id to currentTrack.title,
                                    transitionSpec = {
                                        if (reduceMotion) {
                                            fadeIn(tween(180)) togetherWith fadeOut(tween(140))
                                        } else {
                                            (fadeIn(tween(280)) + slideInVertically(
                                                animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
                                            ) { 14 }).togetherWith(fadeOut(tween(180)))
                                        }
                                    },
                                    label = "song_title_anim"
                                ) { (_, title) ->
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = AuraTextPrimary,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.testTag("now_playing_song_title")
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                AnimatedContent(
                                    targetState = currentTrack.id to currentTrack.artist,
                                    transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(160)) },
                                    label = "song_artist_anim"
                                ) { (_, artist) ->
                                    Text(
                                        text = artist,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = AuraTextSecondary,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                MinimalProgressScrubber(
                                    positionMs = uiState.positionMs,
                                    durationMs = uiState.effectiveDurationMs,
                                    accentColor = animatedAmbientColor,
                                    onSeekTo = onSeekTo
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. BOTTOM CONTROLS: [Lo-fi]  [Hot]  [Play/Pause]  [Cool]  [8D]
                    NowPlayingControlsRow(
                        isPlaying = uiState.isPlaying,
                        isHot = isHot,
                        isCool = isCool,
                        isLofiEnabled = uiState.isLofiEnabled,
                        isEightDEnabled = uiState.isEightDEnabled,
                        effectAccentColor = artworkAccentColor,
                        onLofiClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleLofi()
                        },
                        onHotClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleHot()
                        },
                        onHotActivatedEffect = {
                            if (!reduceMotion) {
                                scope.launch {
                                    hotBgPulse.snapTo(0f)
                                    hotBgPulse.animateTo(
                                        targetValue = 1f,
                                        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
                                    )
                                    hotBgPulse.animateTo(
                                        targetValue = 0f,
                                        animationSpec = spring(dampingRatio = 0.90f, stiffness = Spring.StiffnessVeryLow)
                                    )
                                }
                            }
                        },
                        onPlayPauseClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onTogglePlayPause()
                        },
                        onCoolClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleCool()
                        },
                        onCoolActivatedEffect = {
                            scope.launch {
                                coolBgWashPulse.snapTo(0f)
                                coolBgWashPulse.animateTo(
                                    targetValue = 1f,
                                    animationSpec = if (reduceMotion) tween(160) else spring(
                                        dampingRatio = 0.82f,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                                coolBgWashPulse.animateTo(
                                    targetValue = 0f,
                                    animationSpec = if (reduceMotion) tween(260) else spring(
                                        dampingRatio = 0.92f,
                                        stiffness = Spring.StiffnessVeryLow
                                    )
                                )
                            }
                        },
                        onEightDClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleEightD()
                        }
                    )
                }
            }
        }

        // Subtle Floating Glass Toast Pill
        AnimatedVisibility(
            visible = uiState.toastMessage != null,
            enter = fadeIn(tween(200)) + slideInVertically(
                animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMedium)
            ) { -24 },
            exit = fadeOut(tween(180)) + slideOutVertically(tween(180)) { -24 },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 74.dp)
        ) {
            uiState.toastMessage?.let { message ->
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xD9151722))
                        .border(0.9.dp, GlassBorderStrong, CircleShape)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.labelMedium,
                        color = AuraTextPrimary
                    )
                }
            }
        }

        // Fallback Undo snackbar if user closed the Liked sheet while Undo was still active
        AnimatedVisibility(
            visible = !showLikedDrawer && uiState.undoLikedRemoval != null,
            enter = fadeIn(tween(180)) + slideInVertically { it / 2 },
            exit = fadeOut(tween(150)) + slideOutVertically { it / 2 },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 18.dp)
        ) {
            uiState.undoLikedRemoval?.let { pending ->
                LikedUndoSnackbar(
                    trackTitle = pending.track.title,
                    accentColor = artworkAccentColor,
                    onUndo = onUndoRemoveLiked
                )
            }
        }

        // =========================================================================
        // LAYER 3: MINIMAL "LIST OF SONGS" FROSTED SHEET
        // =========================================================================
        SongsListDrawerOverlay(
            visible = showSongsDrawer,
            activePlaylist = uiState.activePlaylist,
            allPlaylists = uiState.allPlaylists,
            playlistTracks = uiState.activePlaylistTracks,
            currentTrackId = currentTrack?.id,
            isPlayingLiked = uiState.isPlayingLiked,
            accentColor = artworkAccentColor,
            isPlaying = uiState.isPlaying,
            onDismiss = { showSongsDrawer = false },
            onSelectTrack = onSelectTrack,
            onSwitchPlaylist = onSwitchPlaylist,
            onCreateNewPlaylist = {
                showSongsDrawer = false
                onNavigateToCreatePlaylist(null)
            },
            onEditCurrentPlaylist = {
                showSongsDrawer = false
                onNavigateToCreatePlaylist(uiState.activePlaylist?.id)
            }
        )

        // =========================================================================
        // LAYER 4: MINIMAL "LIKED" SONGS FROSTED SHEET
        // =========================================================================
        LikedSongsDrawerOverlay(
            visible = showLikedDrawer,
            likedTracks = uiState.likedTracks,
            currentTrackId = currentTrack?.id,
            isPlayingLiked = uiState.isPlayingLiked,
            isPlaying = uiState.isPlaying,
            accentColor = artworkAccentColor,
            undoRemoval = uiState.undoLikedRemoval,
            onDismiss = { showLikedDrawer = false },
            onPlayLiked = onPlayLiked,
            onShuffleLiked = onShuffleLiked,
            onSelectTrack = onSelectLikedTrack,
            onRemoveFromLiked = onRemoveFromLiked,
            onUndoRemove = onUndoRemoveLiked
        )
    }
}

@Composable
private fun NowPlayingTopBar(
    headerTitle: String,
    isPlayingLiked: Boolean,
    isSmartShuffleEnabled: Boolean,
    accentColor: Color,
    onShuffleClick: () -> Unit,
    onHeaderTitleClick: () -> Unit,
    onLikedClick: () -> Unit,
    onSongsListClick: () -> Unit
) {
    val shuffleCd = stringResource(R.string.cd_shuffle)
    val likedCd = stringResource(R.string.cd_liked_songs)
    val songsListCd = stringResource(R.string.cd_songs_list)

    Row(
        modifier = Modifier
            .widthIn(max = 560.dp)
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // TOP-LEFT: Dedicated Shuffle Toggle Button (48dp touch target)
        Box(
            modifier = Modifier
                .size(48.dp)
                .pressScaleClickable(onClick = onShuffleClick)
                .semantics { contentDescription = shuffleCd }
                .testTag("shuffle_button"),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(GlassFillSubtle)
                    .border(
                        width = 0.9.dp,
                        color = if (isSmartShuffleEnabled) accentColor.copy(alpha = 0.45f) else GlassBorderSubtle,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                AuraShuffleIcon(
                    tint = if (isSmartShuffleEnabled) accentColor else Color.White.copy(alpha = 0.48f),
                    size = 17.dp
                )
                if (isSmartShuffleEnabled) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 5.dp)
                            .size(4.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                }
            }
        }

        // TOP-CENTER: Playlist Name (or "Liked" when Liked queue is playing)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .pressScaleClickable(pressedScale = 0.96f, onClick = onHeaderTitleClick)
                .padding(vertical = 4.dp)
                .testTag("playlist_title_button"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.label_playlist).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = AuraTextMuted
            )
            Spacer(modifier = Modifier.height(1.dp))
            AnimatedContent(
                targetState = headerTitle,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                label = "header_title_anim"
            ) { title ->
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(fontStyle = FontStyle.Italic),
                    color = AuraTextPrimary.copy(alpha = 0.96f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("now_playing_header_title")
                )
            }
        }

        // TOP-RIGHT: Minimal Heart (Liked) icon right next to Songs List icon
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .pressScaleClickable(onClick = onLikedClick)
                    .semantics { contentDescription = likedCd }
                    .testTag("liked_songs_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isPlayingLiked) HotAmber.copy(alpha = 0.16f) else GlassFillSubtle)
                        .border(
                            width = 0.9.dp,
                            color = if (isPlayingLiked) HotAmber.copy(alpha = 0.55f) else GlassBorderSubtle,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    AuraHotHeartIcon(
                        tint = if (isPlayingLiked) HotAmber else Color.White.copy(alpha = 0.82f),
                        isActive = isPlayingLiked,
                        size = 17.dp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .pressScaleClickable(onClick = onSongsListClick)
                    .semantics { contentDescription = songsListCd }
                    .testTag("songs_list_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(GlassFillSubtle)
                        .border(0.9.dp, GlassBorderSubtle, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    AuraSongsListIcon(
                        tint = Color.White.copy(alpha = 0.84f),
                        size = 17.dp
                    )
                }
            }
        }
    }
}
