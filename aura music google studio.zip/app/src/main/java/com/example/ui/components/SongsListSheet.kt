package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Playlist
import com.example.data.model.PlaylistWithTracks
import com.example.data.model.Track
import com.example.ui.theme.AuraObsidianElevated
import com.example.ui.theme.AuraObsidianSurface
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Minimalist dark glass "List of Songs" sheet:
 * - Drag handle + swipe-down gesture to close with natural upward rubber-band overscroll
 * - Clean header: playlist name (with subtle text switcher only if user created >1 playlist),
 *   song count, and borderless icon-only + / edit actions with spring press-scale
 * - Plain borderless song rows with 30 ms staggered entrance, real 96px Coil thumbnails,
 *   real artist tags, and subtle accent title + animated mini equalizer for the active track
 */
@Composable
fun SongsListDrawerOverlay(
    visible: Boolean,
    activePlaylist: Playlist?,
    allPlaylists: List<PlaylistWithTracks>,
    playlistTracks: List<Track>,
    currentTrackId: Long?,
    isPlayingLiked: Boolean,
    accentColor: Color,
    isPlaying: Boolean,
    onDismiss: () -> Unit,
    onSelectTrack: (Long) -> Unit,
    onSwitchPlaylist: (Long) -> Unit,
    onCreateNewPlaylist: () -> Unit,
    onEditCurrentPlaylist: () -> Unit
) {
    if (visible) {
        BackHandler(onBack = onDismiss)
    }

    val reduceMotion = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val dismissThresholdPx = with(density) { 110.dp.toPx() }
    val dragOffsetY = remember { Animatable(0f) }
    var showPlaylistMenu by remember { mutableStateOf(false) }

    val createCd = stringResource(R.string.cd_create_playlist)
    val editCd = stringResource(R.string.cd_edit_playlist)

    LaunchedEffect(visible) {
        if (visible) {
            dragOffsetY.snapTo(0f)
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(if (reduceMotion) 140 else 220)),
        exit = fadeOut(tween(if (reduceMotion) 120 else 180))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = if (reduceMotion) {
                    fadeIn(tween(150))
                } else {
                    slideInVertically(
                        initialOffsetY = { it / 2 },
                        animationSpec = spring(
                            dampingRatio = 0.86f,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ) + fadeIn(tween(200))
                },
                exit = if (reduceMotion) {
                    fadeOut(tween(120))
                } else {
                    slideOutVertically(
                        targetOffsetY = { it / 2 },
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        )
                    ) + fadeOut(tween(170))
                }
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .fillMaxHeight(0.82f)
                        .graphicsLayer {
                            val raw = dragOffsetY.value
                            translationY = if (raw < 0f) {
                                -sqrt(abs(raw)) * 3.8f
                            } else {
                                raw
                            }
                        }
                        .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .background(AuraObsidianSurface.copy(alpha = 0.94f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                        .navigationBarsPadding()
                ) {
                    // Swipe-down drag region (handle + header) with natural overscroll
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .pointerInput(Unit) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        scope.launch {
                                            if (dragOffsetY.value > dismissThresholdPx) {
                                                onDismiss()
                                            } else {
                                                dragOffsetY.animateTo(
                                                    targetValue = 0f,
                                                    animationSpec = spring(
                                                        dampingRatio = 0.78f,
                                                        stiffness = Spring.StiffnessMedium
                                                    )
                                                )
                                            }
                                        }
                                    },
                                    onDragCancel = {
                                        scope.launch {
                                            dragOffsetY.animateTo(
                                                targetValue = 0f,
                                                animationSpec = spring(
                                                    dampingRatio = 0.82f,
                                                    stiffness = Spring.StiffnessMedium
                                                )
                                            )
                                        }
                                    },
                                    onVerticalDrag = { _, dragAmount ->
                                        scope.launch {
                                            val next = (dragOffsetY.value + dragAmount).coerceAtLeast(-220f)
                                            dragOffsetY.snapTo(next)
                                        }
                                    }
                                )
                            }
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(38.dp)
                                .height(3.5.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f))
                                .align(Alignment.CenterHorizontally)
                                .clickable(onClick = onDismiss)
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Minimal Header: Playlist name + song count | borderless + & edit icons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                Column(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .then(
                                            if (allPlaylists.size > 1) {
                                                Modifier.clickable { showPlaylistMenu = true }
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = activePlaylist?.name ?: "My Playlist",
                                            style = MaterialTheme.typography.headlineSmall,
                                            color = AuraTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (allPlaylists.size > 1) {
                                            Icon(
                                                imageVector = Icons.Outlined.KeyboardArrowDown,
                                                contentDescription = stringResource(R.string.cd_switch_playlist),
                                                tint = AuraTextSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    val count = playlistTracks.size
                                    Text(
                                        text = if (count == 1) {
                                            stringResource(R.string.label_song_count_one)
                                        } else {
                                            stringResource(R.string.label_song_count_many, count)
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AuraTextMuted
                                    )
                                }

                                if (allPlaylists.size > 1) {
                                    DropdownMenu(
                                        expanded = showPlaylistMenu,
                                        onDismissRequest = { showPlaylistMenu = false },
                                        modifier = Modifier.background(AuraObsidianElevated)
                                    ) {
                                        allPlaylists.forEach { item ->
                                            val selected = !isPlayingLiked && item.playlist.id == activePlaylist?.id
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = item.playlist.name,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        color = if (selected) accentColor else AuraTextPrimary
                                                    )
                                                },
                                                onClick = {
                                                    showPlaylistMenu = false
                                                    onSwitchPlaylist(item.playlist.id)
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Borderless icon-only actions (+ create, pencil edit) with 0.94 press-scale
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .pressScaleClickable(onClick = onCreateNewPlaylist)
                                        .semantics { contentDescription = createCd }
                                        .testTag("create_playlist_icon_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Add,
                                        contentDescription = null,
                                        tint = AuraTextPrimary.copy(alpha = 0.85f),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                if (activePlaylist != null) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .pressScaleClickable(onClick = onEditCurrentPlaylist)
                                            .semantics { contentDescription = editCd }
                                            .testTag("edit_playlist_icon_button"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Edit,
                                            contentDescription = null,
                                            tint = AuraTextSecondary,
                                            modifier = Modifier.size(19.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(
                        color = Color.White.copy(alpha = 0.06f),
                        thickness = 0.6.dp,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        itemsIndexed(playlistTracks, key = { _, track -> track.id }) { index, track ->
                            val isCurrent = !isPlayingLiked && track.id == currentTrackId
                            StaggeredSheetRow(
                                index = index,
                                visible = visible
                            ) {
                                MinimalSongRow(
                                    track = track,
                                    isCurrent = isCurrent,
                                    isPlaying = isCurrent && isPlaying,
                                    accentColor = accentColor,
                                    onClick = {
                                        onSelectTrack(track.id)
                                        onDismiss()
                                    }
                                )
                                if (index < playlistTracks.lastIndex) {
                                    HorizontalDivider(
                                        color = Color.White.copy(alpha = 0.05f),
                                        thickness = 0.5.dp,
                                        modifier = Modifier.padding(start = 56.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MinimalSongRow(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AuraTrackArtworkImage(
            track = track,
            contentDescription = null,
            targetSizePx = 96,
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(10.dp))
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                if (isCurrent) {
                    AuraMiniEqualizer(
                        tint = accentColor,
                        isPlaying = isPlaying,
                        size = 13.dp
                    )
                }
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isCurrent) accentColor else AuraTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = track.artist,
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = formatDurationMs(track.durationMs),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = AuraTextMuted
        )
    }
}

fun formatDurationMs(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
