package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Track
import com.example.ui.theme.AuraObsidianSurface
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.GlassFillSubtle
import com.example.ui.theme.HotAmber
import com.example.ui.viewmodel.UndoLikedRemoval
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Minimal dark-glass "Liked" sheet showing every Hot song across all playlists and local library:
 * - Play (starts influenced shuffle of Liked) & Shuffle icon (reshuffles Liked)
 * - Tapping any song starts playing it with Liked as the active queue
 * - Minimal heart icon per row to remove from Liked with floating Undo snackbar
 * - 30 ms staggered row fade/slide entrance & natural rubber-band drag overscroll
 */
@Composable
fun LikedSongsDrawerOverlay(
    visible: Boolean,
    likedTracks: List<Track>,
    currentTrackId: Long?,
    isPlayingLiked: Boolean,
    isPlaying: Boolean,
    accentColor: Color,
    undoRemoval: UndoLikedRemoval?,
    onDismiss: () -> Unit,
    onPlayLiked: () -> Unit,
    onShuffleLiked: () -> Unit,
    onSelectTrack: (Long) -> Unit,
    onRemoveFromLiked: (Track) -> Unit,
    onUndoRemove: () -> Unit
) {
    if (visible) {
        BackHandler(onBack = onDismiss)
    }

    val reduceMotion = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current
    val dismissThresholdPx = with(density) { 110.dp.toPx() }
    val dragOffsetY = remember { Animatable(0f) }

    LaunchedEffect(visible) {
        if (visible) {
            dragOffsetY.snapTo(0f)
        }
    }

    val playCd = stringResource(R.string.action_play)
    val shuffleCd = stringResource(R.string.action_shuffle)

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(if (reduceMotion) 140 else 220)),
        exit = fadeOut(tween(if (reduceMotion) 120 else 180))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = if (reduceMotion) {
                    fadeIn(tween(150))
                } else {
                    slideInVertically(
                        initialOffsetY = { it / 2 },
                        animationSpec = spring(
                            dampingRatio = 0.86f,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ) + fadeIn(tween(200))
                },
                exit = if (reduceMotion) {
                    fadeOut(tween(120))
                } else {
                    slideOutVertically(
                        targetOffsetY = { it / 2 },
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        )
                    ) + fadeOut(tween(170))
                }
            ) {
                Box(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .fillMaxHeight(0.82f)
                        .graphicsLayer {
                            // Natural upward rubber-banding overscroll resistance
                            val raw = dragOffsetY.value
                            translationY = if (raw < 0f) {
                                -sqrt(abs(raw)) * 3.8f
                            } else {
                                raw
                            }
                        }
                        .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .background(AuraObsidianSurface.copy(alpha = 0.94f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                        .navigationBarsPadding()
                        .testTag("liked_songs_sheet")
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Swipe-down drag region (handle + header)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .pointerInput(Unit) {
                                    detectVerticalDragGestures(
                                        onDragEnd = {
                                            scope.launch {
                                                if (dragOffsetY.value > dismissThresholdPx) {
                                                    onDismiss()
                                                } else {
                                                    dragOffsetY.animateTo(
                                                        targetValue = 0f,
                                                        animationSpec = spring(
                                                            dampingRatio = 0.78f,
                                                            stiffness = Spring.StiffnessMedium
                                                        )
                                                    )
                                                }
                                            }
                                        },
                                        onDragCancel = {
                                            scope.launch {
                                                dragOffsetY.animateTo(
                                                    targetValue = 0f,
                                                    animationSpec = spring(
                                                        dampingRatio = 0.82f,
                                                        stiffness = Spring.StiffnessMedium
                                                    )
                                                )
                                            }
                                        },
                                        onVerticalDrag = { _, dragAmount ->
                                            scope.launch {
                                                val next = (dragOffsetY.value + dragAmount).coerceAtLeast(-220f)
                                                dragOffsetY.snapTo(next)
                                            }
                                        }
                                    )
                                }
                                .padding(horizontal = 24.dp, vertical = 14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(38.dp)
                                    .height(3.5.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.22f))
                                    .align(Alignment.CenterHorizontally)
                                    .clickable(onClick = onDismiss)
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            // Header: "Liked" + song count | Play & Shuffle controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.title_liked),
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = AuraTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    val count = likedTracks.size
                                    Text(
                                        text = if (count == 1) {
                                            stringResource(R.string.label_song_count_one)
                                        } else {
                                            stringResource(R.string.label_song_count_many, count)
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AuraTextMuted
                                    )
                                }

                                if (likedTracks.isNotEmpty()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        // Minimal Play pill
                                        Row(
                                            modifier = Modifier
                                                .height(40.dp)
                                                .clip(CircleShape)
                                                .background(GlassFillSubtle)
                                                .border(0.85.dp, accentColor.copy(alpha = 0.45f), CircleShape)
                                                .pressScaleClickable {
                                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    onPlayLiked()
                                                    onDismiss()
                                                }
                                                .padding(horizontal = 16.dp)
                                                .semantics { contentDescription = playCd }
                                                .testTag("liked_play_button"),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            AuraPlayIcon(tint = accentColor, size = 14.dp)
                                            Text(
                                                text = stringResource(R.string.action_play),
                                                style = MaterialTheme.typography.labelLarge,
                                                color = AuraTextPrimary
                                            )
                                        }

                                        // Minimal Shuffle icon button (48dp touch target)
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .pressScaleClickable {
                                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    onShuffleLiked()
                                                }
                                                .semantics { contentDescription = shuffleCd }
                                                .testTag("liked_shuffle_button"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AuraShuffleIcon(
                                                tint = AuraTextPrimary.copy(alpha = 0.85f),
                                                size = 18.dp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        HorizontalDivider(
                            color = Color.White.copy(alpha = 0.06f),
                            thickness = 0.6.dp,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        if (likedTracks.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .padding(horizontal = 36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    AuraHotHeartIcon(
                                        tint = AuraTextMuted.copy(alpha = 0.45f),
                                        isActive = false,
                                        size = 32.dp
                                    )
                                    Text(
                                        text = stringResource(R.string.empty_liked_title),
                                        style = MaterialTheme.typography.titleLarge,
                                        color = AuraTextPrimary.copy(alpha = 0.88f),
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = stringResource(R.string.empty_liked_subtitle),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AuraTextMuted,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentPadding = PaddingValues(
                                    start = 24.dp,
                                    end = 16.dp,
                                    top = 10.dp,
                                    bottom = if (undoRemoval != null) 78.dp else 18.dp
                                )
                            ) {
                                itemsIndexed(likedTracks, key = { _, track -> track.id }) { index, track ->
                                    val isCurrent = isPlayingLiked && track.id == currentTrackId
                                    StaggeredSheetRow(
                                        index = index,
                                        visible = visible
                                    ) {
                                        LikedSongRow(
                                            track = track,
                                            isCurrent = isCurrent,
                                            isPlaying = isCurrent && isPlaying,
                                            accentColor = accentColor,
                                            onClick = {
                                                onSelectTrack(track.id)
                                                onDismiss()
                                            },
                                            onUnlike = {
                                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                onRemoveFromLiked(track)
                                            }
                                        )
                                        if (index < likedTracks.lastIndex) {
                                            HorizontalDivider(
                                                color = Color.White.copy(alpha = 0.05f),
                                                thickness = 0.5.dp,
                                                modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Minimal Floating Undo Snackbar inside the sheet
                    AnimatedVisibility(
                        visible = undoRemoval != null,
                        enter = fadeIn(tween(180)) + slideInVertically(
                            initialOffsetY = { it / 2 },
                            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMedium)
                        ),
                        exit = fadeOut(tween(150)) + slideOutVertically(targetOffsetY = { it / 2 }),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        undoRemoval?.let { pending ->
                            LikedUndoSnackbar(
                                trackTitle = pending.track.title,
                                accentColor = accentColor,
                                onUndo = {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onUndoRemove()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LikedUndoSnackbar(
    trackTitle: String,
    accentColor: Color,
    onUndo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xE8161924))
            .border(0.9.dp, GlassBorderStrong, RoundedCornerShape(18.dp))
            .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.msg_removed_from_liked, trackTitle),
            style = MaterialTheme.typography.bodySmall,
            color = AuraTextPrimary.copy(alpha = 0.92f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .pressScaleClickable(onClick = onUndo)
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("liked_undo_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stringResource(R.string.action_undo),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = accentColor
            )
        }
    }
}

@Composable
private fun LikedSongRow(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    onUnlike: () -> Unit
) {
    val unlikeCd = stringResource(R.string.cd_unlike_track)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AuraTrackArtworkImage(
            track = track,
            contentDescription = null,
            targetSizePx = 96,
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(10.dp))
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                if (isCurrent) {
                    AuraMiniEqualizer(
                        tint = accentColor,
                        isPlaying = isPlaying,
                        size = 13.dp
                    )
                }
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isCurrent) accentColor else AuraTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = track.artist,
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Text(
            text = formatDurationMs(track.durationMs),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = AuraTextMuted
        )

        Spacer(modifier = Modifier.width(4.dp))

        // Minimal 48dp touch-target Heart remove button
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .pressScaleClickable(onClick = onUnlike)
                .semantics { contentDescription = unlikeCd }
                .testTag("unlike_track_${track.id}"),
            contentAlignment = Alignment.Center
        ) {
            AuraHotHeartIcon(
                tint = HotAmber.copy(alpha = 0.90f),
                isActive = true,
                size = 18.dp
            )
        }
    }
}

/**
 * Reusable 30 ms staggered fade + subtle vertical slide entrance for sheet rows.
 * Capped at the first 10 visible items so fast scrolling stays completely silky at 60 fps.
 * Under system Reduce Motion, falls back to a clean instant fade with zero movement.
 */
@Composable
fun StaggeredSheetRow(
    index: Int,
    visible: Boolean,
    content: @Composable () -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val shouldStagger = index < 10 && !reduceMotion
    val progress = remember(visible) { Animatable(if (shouldStagger) 0f else 1f) }
    val slidePx = with(LocalDensity.current) { 14.dp.toPx() }

    LaunchedEffect(visible, shouldStagger) {
        if (visible && shouldStagger) {
            delay(index * 30L)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = 0.86f,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        } else {
            progress.snapTo(1f)
        }
    }

    Column(
        modifier = Modifier.graphicsLayer {
            val p = progress.value
            alpha = p.coerceIn(0f, 1f)
            translationY = if (reduceMotion) 0f else (1f - p) * slidePx
        }
    ) {
        content()
    }
}
