package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Bespoke minimalist icons tailored to Aura Music's refined aesthetic:
 * slender uniform strokes, soft rounded corners, fluid morphing, and balanced geometry.
 */

@Composable
fun AuraShuffleIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 18.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = Stroke(
            width = w * 0.095f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )

        drawLine(
            color = tint,
            start = Offset(w * 0.16f, h * 0.80f),
            end = Offset(w * 0.84f, h * 0.18f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        val topArrow = Path().apply {
            moveTo(w * 0.62f, h * 0.18f)
            lineTo(w * 0.84f, h * 0.18f)
            lineTo(w * 0.84f, h * 0.40f)
        }
        drawPath(topArrow, color = tint, style = stroke)

        drawLine(
            color = tint,
            start = Offset(w * 0.16f, h * 0.22f),
            end = Offset(w * 0.39f, h * 0.43f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.61f, h * 0.61f),
            end = Offset(w * 0.84f, h * 0.82f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        val bottomArrow = Path().apply {
            moveTo(w * 0.62f, h * 0.82f)
            lineTo(w * 0.84f, h * 0.82f)
            lineTo(w * 0.84f, h * 0.60f)
        }
        drawPath(bottomArrow, color = tint, style = stroke)
    }
}

@Composable
fun AuraSongsListIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 18.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeWidth = w * 0.095f

        drawLine(
            color = tint,
            start = Offset(w * 0.14f, h * 0.25f),
            end = Offset(w * 0.86f, h * 0.25f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.14f, h * 0.48f),
            end = Offset(w * 0.58f, h * 0.48f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.14f, h * 0.71f),
            end = Offset(w * 0.48f, h * 0.71f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.80f, h * 0.48f),
            end = Offset(w * 0.80f, h * 0.78f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        drawCircle(
            color = tint,
            radius = w * 0.105f,
            center = Offset(w * 0.71f, h * 0.78f),
            style = Stroke(width = strokeWidth * 0.9f)
        )
    }
}

/**
 * Fluidly morphs between the Play triangle (progress = 0) and Pause bars (progress = 1)
 * using two interpolated quad paths with rounded strokes and spring dynamics.
 */
@Composable
fun AuraMorphingPlayPauseIcon(
    isPlaying: Boolean,
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp
) {
    val reduceMotion = LocalReduceMotion.current
    val morph by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0f,
        animationSpec = if (reduceMotion) {
            snap()
        } else {
            spring(
                dampingRatio = 0.78f,
                stiffness = Spring.StiffnessMedium
            )
        },
        label = "play_pause_morph"
    )

    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val t = morph.coerceIn(0f, 1f)
        val roundStroke = Stroke(
            width = w * 0.09f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )

        // Subtle rotation during morph for tactile polish
        val rotDeg = lerp(0f, 90f, t) - 90f * t
        withTransform({
            rotate(degrees = rotDeg, pivot = Offset(w * 0.5f, h * 0.5f))
        }) {
            // Left half: left trapezoid of Play triangle -> left Pause bar
            val leftPath = Path().apply {
                moveTo(w * lerp(0.30f, 0.26f, t), h * lerp(0.21f, 0.22f, t))
                lineTo(w * lerp(0.55f, 0.42f, t), h * lerp(0.355f, 0.22f, t))
                lineTo(w * lerp(0.55f, 0.42f, t), h * lerp(0.645f, 0.78f, t))
                lineTo(w * lerp(0.30f, 0.26f, t), h * lerp(0.79f, 0.78f, t))
                close()
            }

            // Right half: right apex of Play triangle -> right Pause bar
            val rightPath = Path().apply {
                moveTo(w * lerp(0.54f, 0.58f, t), h * lerp(0.35f, 0.22f, t))
                lineTo(w * lerp(0.79f, 0.74f, t), h * lerp(0.50f, 0.22f, t))
                lineTo(w * lerp(0.79f, 0.74f, t), h * lerp(0.50f, 0.78f, t))
                lineTo(w * lerp(0.54f, 0.58f, t), h * lerp(0.65f, 0.78f, t))
                close()
            }

            drawPath(path = leftPath, color = tint, style = Fill)
            drawPath(path = leftPath, color = tint, style = roundStroke)
            drawPath(path = rightPath, color = tint, style = Fill)
            drawPath(path = rightPath, color = tint, style = roundStroke)
        }
    }
}

@Composable
fun AuraPlayIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 30.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.30f, h * 0.20f)
            lineTo(w * 0.80f, h * 0.50f)
            lineTo(w * 0.30f, h * 0.80f)
            close()
        }
        drawPath(path = path, color = tint, style = Fill)
        drawPath(
            path = path,
            color = tint,
            style = Stroke(
                width = w * 0.12f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

@Composable
fun AuraPauseIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 30.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val barWidth = w * 0.19f
        val barHeight = h * 0.62f
        val top = (h - barHeight) / 2f
        val radius = CornerRadius(barWidth / 2f, barWidth / 2f)

        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.25f, top),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(w * 0.56f, top),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
    }
}

@Composable
fun AuraHotHeartIcon(
    tint: Color,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 23.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val heartPath = buildHeartPath(w, h)

        if (isActive) {
            drawPath(path = heartPath, color = tint, style = Fill)
        }
        drawPath(
            path = heartPath,
            color = tint,
            style = Stroke(
                width = w * 0.085f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

/**
 * Broken heart icon with animated fracture split & drop support:
 * when [crackProgress] animates 0 -> 1 -> 0 on Cool tap, the left and right halves
 * subtly split apart, tilt, drop a few pixels, and fade slightly before settling.
 */
@Composable
fun AuraCoolBrokenHeartIcon(
    tint: Color,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    crackProgress: Float = 0f,
    size: Dp = 23.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val heartPath = buildHeartPath(w, h)
        val stroke = Stroke(
            width = w * 0.085f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val crackPath = Path().apply {
            moveTo(w * 0.51f, h * 0.25f)
            lineTo(w * 0.42f, h * 0.49f)
            lineTo(w * 0.58f, h * 0.51f)
            lineTo(w * 0.47f, h * 0.77f)
        }
        val crackStroke = Stroke(
            width = w * 0.082f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )

        val split = crackProgress.coerceIn(0f, 1f)
        val effectiveAlpha = (1f - split * 0.34f).coerceIn(0.4f, 1f)
        val tinted = tint.copy(alpha = tint.alpha * effectiveAlpha)

        if (split < 0.01f) {
            if (isActive) {
                drawPath(path = heartPath, color = tinted.copy(alpha = tinted.alpha * 0.28f), style = Fill)
            }
            drawPath(path = heartPath, color = tinted, style = stroke)
            drawPath(path = crackPath, color = tinted, style = crackStroke)
        } else {
            val dx = w * 0.095f * split
            val dy = h * 0.14f * split
            val rot = 9f * split

            // Left fractured half
            withTransform({
                translate(left = -dx, top = dy)
                rotate(degrees = -rot, pivot = Offset(w * 0.42f, h * 0.55f))
                clipRect(left = -w * 0.2f, top = -h * 0.2f, right = w * 0.51f, bottom = h * 1.2f)
            }) {
                if (isActive) {
                    drawPath(path = heartPath, color = tinted.copy(alpha = tinted.alpha * 0.28f), style = Fill)
                }
                drawPath(path = heartPath, color = tinted, style = stroke)
                drawPath(path = crackPath, color = tinted, style = crackStroke)
            }

            // Right fractured half
            withTransform({
                translate(left = dx, top = dy * 1.15f)
                rotate(degrees = rot, pivot = Offset(w * 0.58f, h * 0.55f))
                clipRect(left = w * 0.49f, top = -h * 0.2f, right = w * 1.2f, bottom = h * 1.2f)
            }) {
                if (isActive) {
                    drawPath(path = heartPath, color = tinted.copy(alpha = tinted.alpha * 0.28f), style = Fill)
                }
                drawPath(path = heartPath, color = tinted, style = stroke)
                drawPath(path = crackPath, color = tinted, style = crackStroke)
            }
        }
    }
}

/**
 * Minimalist vinyl-groove icon for the Lo-fi toggle button.
 */
@Composable
fun AuraLofiIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 18.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val center = Offset(w * 0.5f, h * 0.5f)
        val strokeW = w * 0.095f

        drawCircle(
            color = tint,
            radius = w * 0.39f,
            center = center,
            style = Stroke(width = strokeW)
        )
        drawCircle(
            color = tint.copy(alpha = 0.55f),
            radius = w * 0.23f,
            center = center,
            style = Stroke(width = strokeW * 0.75f)
        )
        drawCircle(
            color = tint,
            radius = w * 0.085f,
            center = center
        )
    }
}

/**
 * Minimalist 360-degree orbital spatial ring icon for the 8D toggle button.
 * When [orbitAngleDegrees] advances continuously, the spatial dot smoothly orbits the head-stage.
 */
@Composable
fun AuraEightDIcon(
    tint: Color,
    modifier: Modifier = Modifier,
    orbitAngleDegrees: Float = 0f,
    size: Dp = 18.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeW = w * 0.092f

        // Orbit ellipse representing head-circling 8D soundstage
        drawOval(
            color = tint.copy(alpha = 0.85f),
            topLeft = Offset(w * 0.10f, h * 0.30f),
            size = Size(w * 0.80f, h * 0.40f),
            style = Stroke(width = strokeW)
        )
        // Center listener node
        drawCircle(
            color = tint,
            radius = w * 0.105f,
            center = Offset(w * 0.50f, h * 0.50f)
        )
        // Orbiting spatial source dot following the elliptical 360° path
        val rad = (orbitAngleDegrees.toDouble() * PI / 180.0)
        val dotX = (w * 0.50f) + (w * 0.40f) * cos(rad).toFloat()
        val dotY = (h * 0.50f) + (h * 0.20f) * sin(rad).toFloat()
        drawCircle(
            color = tint,
            radius = w * 0.095f,
            center = Offset(dotX, dotY)
        )
    }
}

/**
 * Subtle 3-bar mini equalizer shown next to the currently playing track in the song list and Liked sheet.
 */
@Composable
fun AuraMiniEqualizer(
    tint: Color,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 14.dp
) {
    val reduceMotion = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "mini_eq")
    val b1 by transition.animateFloat(
        initialValue = 0.30f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(480, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eq_1"
    )
    val b2 by transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 0.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(620, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eq_2"
    )
    val b3 by transition.animateFloat(
        initialValue = 0.42f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(540, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eq_3"
    )

    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val barW = w * 0.20f
        val heights = if (isPlaying && !reduceMotion) {
            floatArrayOf(b1, b2, b3)
        } else {
            floatArrayOf(0.45f, 0.72f, 0.38f)
        }
        val xs = floatArrayOf(w * 0.12f, w * 0.40f, w * 0.68f)

        for (i in 0..2) {
            val bh = h * heights[i]
            drawRoundRect(
                color = tint,
                topLeft = Offset(xs[i], h - bh),
                size = Size(barW, bh),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f)
            )
        }
    }
}

private fun lerp(start: Float, stop: Float, fraction: Float): Float =
    start + (stop - start) * fraction

private fun buildHeartPath(w: Float, h: Float): Path {
    return Path().apply {
        moveTo(w * 0.50f, h * 0.85f)
        cubicTo(
            w * 0.16f, h * 0.64f,
            w * 0.10f, h * 0.42f,
            w * 0.14f, h * 0.30f
        )
        cubicTo(
            w * 0.18f, h * 0.16f,
            w * 0.37f, h * 0.14f,
            w * 0.50f, h * 0.29f
        )
        cubicTo(
            w * 0.63f, h * 0.14f,
            w * 0.82f, h * 0.16f,
            w * 0.86f, h * 0.30f
        )
        cubicTo(
            w * 0.90f, h * 0.42f,
            w * 0.84f, h * 0.64f,
            w * 0.50f, h * 0.85f
        )
        close()
    }
}
