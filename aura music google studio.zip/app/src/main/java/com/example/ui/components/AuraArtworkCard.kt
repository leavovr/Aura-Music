package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.CoolSky
import com.example.ui.theme.HotAmber

/**
 * Loads each song's real cover art via Coil with memory + disk caching and explicit
 * downscaling (512px for main banner, 96px for list thumbnails). Falls back deterministically
 * (hash % 3) to one of the 3 generated banners only when real cover art is unavailable.
 */
@Composable
fun AuraTrackArtworkImage(
    track: Track,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    targetSizePx: Int = 512
) {
    val context = LocalContext.current
    val fallbackRes = remember(track.id) { track.deterministicFallbackDrawableRes() }
    val imageData: Any = remember(track.id, track.artworkUri) {
        track.artworkUri?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) } ?: fallbackRes
    }

    val request = remember(imageData, targetSizePx) {
        ImageRequest.Builder(context)
            .data(imageData)
            .fallback(fallbackRes)
            .error(fallbackRes)
            .size(targetSizePx)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .crossfade(false)
            .build()
    }

    Box(
        modifier = modifier.background(
            brush = Brush.linearGradient(
                colors = listOf(
                    track.secondaryColor,
                    track.dominantColor.copy(alpha = 0.80f),
                    Color(0xFF0E0F14)
                )
            )
        )
    ) {
        AsyncImage(
            model = request,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun HeroAlbumBannerCard(
    track: Track,
    trackNumberLabel: String,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 30.dp
) {
    val shape = RoundedCornerShape(cornerRadius)
    val glowColor = when (track.preference) {
        TrackPreference.HOT -> HotAmber
        TrackPreference.COOL -> CoolSky
        TrackPreference.NEUTRAL -> track.dominantColor
    }

    Box(
        modifier = modifier
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            glowColor.copy(alpha = 0.34f),
                            glowColor.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height * 0.52f),
                        radius = size.maxDimension * 0.88f
                    ),
                    radius = size.maxDimension * 0.88f
                )
            }
            .clip(shape)
            .border(
                width = 1.25.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.32f),
                        Color.White.copy(alpha = 0.10f),
                        Color.White.copy(alpha = 0.05f)
                    )
                ),
                shape = shape
            )
    ) {
        AuraTrackArtworkImage(
            track = track,
            contentDescription = stringResource(R.string.cd_album_art),
            targetSizePx = 512,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.28f),
                            Color.Transparent,
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.46f)
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.34f))
                    .border(0.75.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = stringResource(R.string.label_hires_badge),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    letterSpacing = 0.9.sp,
                    color = Color.White.copy(alpha = 0.86f)
                )
            }

            if (track.preference != TrackPreference.NEUTRAL) {
                val isHot = track.preference == TrackPreference.HOT
                val pillColor = if (isHot) HotAmber else CoolSky
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(pillColor.copy(alpha = 0.20f))
                        .border(0.85.dp, pillColor.copy(alpha = 0.55f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = stringResource(if (isHot) R.string.label_hot_track else R.string.label_cool_track),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = pillColor
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = trackNumberLabel,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                letterSpacing = 1.sp,
                color = Color.White.copy(alpha = 0.72f)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(AuraEmerald)
                )
                Text(
                    text = stringResource(R.string.label_lossless),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    letterSpacing = 0.6.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.White.copy(alpha = 0.78f)
                )
            }
        }
    }
}

@Composable
fun PeekingAlbumBannerCard(
    track: Track,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .border(0.8.dp, Color.White.copy(alpha = 0.16f), shape)
    ) {
        AuraTrackArtworkImage(
            track = track,
            contentDescription = contentDescription,
            targetSizePx = 320,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.15f),
                            Color.Black.copy(alpha = 0.65f)
                        )
                    )
                )
        )
        Text(
            text = track.title,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.78f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
        )
    }
}
