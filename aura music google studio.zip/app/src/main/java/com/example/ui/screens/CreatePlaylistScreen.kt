package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AudioFile
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PlaylistWithTracks
import com.example.data.model.Track
import com.example.ui.components.AuraTrackArtworkImage
import com.example.ui.components.formatDurationMs
import com.example.ui.components.pressScaleClickable
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraObsidian
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.GlassBorderStrong
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.GlassFillButton
import com.example.ui.theme.GlassFillElevated
import com.example.ui.theme.GlassFillSubtle
import com.example.ui.theme.HotAmber

@Composable
fun CreatePlaylistScreen(
    editingPlaylist: PlaylistWithTracks?,
    allTracks: List<Track>,
    onBack: () -> Unit,
    onImportAudioUris: (List<Uri>, (List<Long>) -> Unit) -> Unit,
    onSavePlaylist: (existingId: Long?, name: String, trackIds: List<Long>) -> Unit
) {
    var playlistName by remember(editingPlaylist?.playlist?.id) {
        mutableStateOf(editingPlaylist?.playlist?.name ?: "")
    }
    var searchQuery by remember { mutableStateOf("") }
    var validationMessage by remember { mutableStateOf<String?>(null) }

    val selectedTrackIds = remember(editingPlaylist?.playlist?.id) {
        mutableStateListOf<Long>().apply {
            if (editingPlaylist != null) {
                addAll(editingPlaylist.tracks.map { it.id })
            } else {
                addAll(allTracks.take(3).map { it.id })
            }
        }
    }

    LaunchedEffect(allTracks.size, editingPlaylist?.playlist?.id) {
        if (editingPlaylist == null && selectedTrackIds.isEmpty() && allTracks.isNotEmpty()) {
            selectedTrackIds.addAll(allTracks.take(3).map { it.id })
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onImportAudioUris(uris) { newlyAddedIds ->
                newlyAddedIds.forEach { id ->
                    if (id !in selectedTrackIds) {
                        selectedTrackIds.add(0, id)
                    }
                }
                validationMessage = null
            }
        }
    }

    val trackById = remember(allTracks) { allTracks.associateBy { it.id } }
    val includedTracks = selectedTrackIds.mapNotNull { trackById[it] }
    val totalDurationMin = (includedTracks.sumOf { it.durationMs } / 60_000L).coerceAtLeast(1L)

    val filteredAvailableTracks = remember(allTracks, selectedTrackIds.toList(), searchQuery) {
        val q = searchQuery.trim().lowercase()
        allTracks.filter { track ->
            track.id !in selectedTrackIds && (
                q.isEmpty() ||
                    track.title.lowercase().contains(q) ||
                    track.artist.lowercase().contains(q) ||
                    track.vibe.lowercase().contains(q)
                )
        }
    }

    val backCd = stringResource(R.string.cd_back)
    val needOneTrackMsg = stringResource(R.string.msg_need_one_track)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraObsidian)
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF141620),
                            Color(0xFF0C0D12),
                            Color(0xFF07080B)
                        )
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x334338CA),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.9f, size.height * 0.14f),
                        radius = size.minDimension * 0.72f
                    ),
                    center = Offset(size.width * 0.9f, size.height * 0.14f),
                    radius = size.minDimension * 0.72f
                )
            },
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(GlassFillSubtle)
                        .border(0.9.dp, GlassBorderSubtle, CircleShape)
                        .pressScaleClickable(onClick = onBack)
                        .semantics { contentDescription = backCd }
                        .testTag("create_back_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = null,
                        tint = AuraTextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Text(
                    text = stringResource(
                        if (editingPlaylist != null) R.string.action_edit_playlist else R.string.action_create_playlist
                    ),
                    style = MaterialTheme.typography.headlineSmall,
                    color = AuraTextPrimary
                )

                Spacer(modifier = Modifier.size(48.dp))
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = stringResource(R.string.label_playlist_name).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = AuraTextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(GlassFillSubtle)
                    .border(1.dp, GlassBorderSubtle, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                if (playlistName.isEmpty()) {
                    Text(
                        text = stringResource(R.string.hint_playlist_name),
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White.copy(alpha = 0.28f)
                    )
                }
                BasicTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleLarge.copy(color = AuraTextPrimary),
                    cursorBrush = SolidColor(HotAmber),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("playlist_name_input")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GlassFillSubtle)
                        .border(0.9.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = null,
                        tint = AuraTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = stringResource(R.string.hint_search_tracks),
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.34f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = AuraTextPrimary),
                            cursorBrush = SolidColor(HotAmber),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("track_search_input")
                        )
                    }
                    if (searchQuery.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = stringResource(R.string.cd_close),
                            tint = AuraTextMuted,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { searchQuery = "" }
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GlassFillButton)
                        .border(0.9.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                        .pressScaleClickable { audioPickerLauncher.launch(arrayOf("audio/*")) }
                        .padding(horizontal = 12.dp)
                        .testTag("import_audio_button"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AudioFile,
                        contentDescription = null,
                        tint = HotAmber,
                        modifier = Modifier.size(17.dp)
                    )
                    Text(
                        text = stringResource(R.string.action_import_audio),
                        style = MaterialTheme.typography.labelMedium,
                        color = AuraTextPrimary,
                        maxLines = 1
                    )
                }
            }

            if (validationMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = validationMessage!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = HotAmber
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                item(key = "header_included") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.label_included_tracks, includedTracks.size).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = AuraTextMuted
                        )
                        if (includedTracks.isNotEmpty()) {
                            Text(
                                text = "$totalDurationMin min total",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = AuraTextMuted
                            )
                        }
                    }
                }

                items(includedTracks, key = { "inc_${it.id}" }) { track ->
                    CreatePlaylistTrackRow(
                        track = track,
                        isIncluded = true,
                        onToggle = {
                            selectedTrackIds.remove(track.id)
                        }
                    )
                }

                if (filteredAvailableTracks.isNotEmpty()) {
                    item(key = "header_available") {
                        Text(
                            text = stringResource(R.string.label_add_tracks).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = AuraTextMuted,
                            modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)
                        )
                    }

                    items(filteredAvailableTracks, key = { "avail_${it.id}" }) { track ->
                        CreatePlaylistTrackRow(
                            track = track,
                            isIncluded = false,
                            onToggle = {
                                selectedTrackIds.add(track.id)
                                validationMessage = null
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(GlassFillElevated)
                    .border(1.dp, GlassBorderStrong, RoundedCornerShape(20.dp))
                    .pressScaleClickable {
                        if (selectedTrackIds.isEmpty()) {
                            validationMessage = needOneTrackMsg
                        } else {
                            onSavePlaylist(
                                editingPlaylist?.playlist?.id,
                                playlistName.ifBlank { "My Playlist" },
                                selectedTrackIds.toList()
                            )
                        }
                    }
                    .testTag("save_playlist_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Check,
                        contentDescription = null,
                        tint = AuraEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = stringResource(R.string.action_save_launch),
                        style = MaterialTheme.typography.labelLarge,
                        color = AuraTextPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun CreatePlaylistTrackRow(
    track: Track,
    isIncluded: Boolean,
    onToggle: () -> Unit
) {
    val toggleCd = stringResource(if (isIncluded) R.string.cd_remove_track else R.string.cd_add_track)
    val shape = RoundedCornerShape(18.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (isIncluded) GlassFillButton else GlassFillSubtle)
            .border(
                width = 0.85.dp,
                color = if (isIncluded) GlassBorderStrong.copy(alpha = 0.25f) else GlassBorderSubtle,
                shape = shape
            )
            .clickable(onClick = onToggle)
            .padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AuraTrackArtworkImage(
            track = track,
            contentDescription = null,
            targetSizePx = 96,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.titleMedium,
                color = AuraTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${track.artist} • ${formatDurationMs(track.durationMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isIncluded) Color.White.copy(alpha = 0.08f) else HotAmber.copy(alpha = 0.16f))
                .semantics { contentDescription = toggleCd },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isIncluded) Icons.Outlined.Close else Icons.Outlined.Add,
                contentDescription = null,
                tint = if (isIncluded) AuraTextSecondary else HotAmber,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
