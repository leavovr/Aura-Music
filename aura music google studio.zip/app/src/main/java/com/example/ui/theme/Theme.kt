package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AuraDarkColorScheme = darkColorScheme(
    primary = HotAmber,
    onPrimary = AuraObsidian,
    primaryContainer = Color(0xFF3A2408),
    onPrimaryContainer = Color(0xFFFDE68A),
    secondary = CoolSky,
    onSecondary = AuraObsidian,
    secondaryContainer = Color(0xFF0C2B3D),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = AuraEmerald,
    onTertiary = AuraObsidian,
    background = AuraObsidian,
    onBackground = AuraTextPrimary,
    surface = AuraObsidianSurface,
    onSurface = AuraTextPrimary,
    surfaceVariant = AuraObsidianElevated,
    onSurfaceVariant = AuraTextSecondary,
    outline = GlassBorderSubtle,
    outlineVariant = GlassBorderStrong
)

private val AuraShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun AuraMusicTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AuraDarkColorScheme,
        typography = AuraTypography,
        shapes = AuraShapes,
        content = content
    )
}
