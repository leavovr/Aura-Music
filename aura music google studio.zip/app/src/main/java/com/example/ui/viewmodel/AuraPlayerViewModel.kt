package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuraDatabase
import com.example.data.model.Playlist
import com.example.data.model.PlaylistWithTracks
import com.example.data.model.SongStats
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import com.example.data.preferences.AuraPreferencesRepository
import com.example.data.repository.MusicRepository
import com.example.domain.SmartShuffleEngine
import com.example.service.AuraMediaControllerBridge
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class UndoLikedRemoval(
    val track: Track
)

@Immutable
data class AuraUiState(
    val isLoading: Boolean = true,
    val activePlaylist: Playlist? = null,
    val isPlayingLiked: Boolean = false,
    val allPlaylists: List<PlaylistWithTracks> = emptyList(),
    val allTracks: List<Track> = emptyList(),
    val likedTracks: List<Track> = emptyList(),
    val sessionQueue: List<Track> = emptyList(),
    val currentIndex: Int = 0,
    val isPlaying: Boolean = false,
    val isSmartShuffleEnabled: Boolean = true,
    val isLofiEnabled: Boolean = false,
    val isEightDEnabled: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val toastMessage: String? = null,
    val undoLikedRemoval: UndoLikedRemoval? = null
) {
    val headerTitle: String
        get() = if (isPlayingLiked) "Liked" else (activePlaylist?.name ?: "My Playlist")

    val currentTrack: Track?
        get() = sessionQueue.getOrNull(currentIndex)

    val previousTrack: Track?
        get() = when {
            sessionQueue.size <= 1 -> null
            currentIndex - 1 >= 0 -> sessionQueue[currentIndex - 1]
            else -> sessionQueue.last()
        }

    val nextTrack: Track?
        get() = when {
            sessionQueue.size <= 1 -> null
            else -> sessionQueue[(currentIndex + 1) % sessionQueue.size]
        }

    val effectiveDurationMs: Long
        get() = if (durationMs > 0L) durationMs else (currentTrack?.durationMs ?: 18_000L)

    val activePlaylistTracks: List<Track>
        get() = allPlaylists.firstOrNull { it.playlist.id == activePlaylist?.id }?.tracks ?: sessionQueue
}

class AuraPlayerViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val EARLY_SKIP_THRESHOLD_MS = 10_000L
        private const val BATCH_SIZE = SmartShuffleEngine.DEFAULT_BATCH_SIZE
        private const val BATCH_TOP_UP_BUFFER = 4
    }

    private val database = AuraDatabase.getInstance(application)
    private val repository = MusicRepository(application, database.auraDao())
    private val preferences = AuraPreferencesRepository(application)
    private val mediaBridge = AuraMediaControllerBridge(application, viewModelScope)

    private val _uiState = MutableStateFlow(AuraUiState())
    val uiState: StateFlow<AuraUiState> = _uiState.asStateFlow()

    private val recentTrackIds = ArrayDeque<Long>()
    private val recentArtists = ArrayDeque<String>()
    private var latestStatsMap: Map<Long, SongStats> = emptyMap()
    private var loadedPlaylistId: Long? = null
    private var loadedPlaylistTrackSignature: List<Long> = emptyList()
    private var lastRecordedPlayTrackId: Long? = null
    private var toastJob: Job? = null
    private var undoJob: Job? = null

    init {
        mediaBridge.connect()

        viewModelScope.launch {
            repository.ensureSeededAndAudioReady()
        }

        // Observe persisted Lo-fi & 8D states
        viewModelScope.launch {
            combine(
                preferences.lofiEnabledFlow,
                preferences.eightDEnabledFlow
            ) { lofi, eightD -> lofi to eightD }
                .collect { (lofi, eightD) ->
                    _uiState.update { it.copy(isLofiEnabled = lofi, isEightDEnabled = eightD) }
                }
        }

        // Observe global song stats
        viewModelScope.launch {
            repository.songStatsMapFlow.collect { map ->
                latestStatsMap = map
            }
        }

        // Observe playlists, tracks, liked tracks, and shuffle mode
        viewModelScope.launch {
            combine(
                repository.playlistsWithTracksFlow,
                repository.allTracksFlow,
                repository.likedTracksFlow,
                preferences.activePlaylistIdFlow,
                preferences.smartShuffleEnabledFlow
            ) { playlists, allTracks, likedTracks, savedPlaylistId, smartShuffle ->
                CombinedData(playlists, allTracks, likedTracks, savedPlaylistId, smartShuffle)
            }.collect { data ->
                val chosenPlaylist = data.playlists.firstOrNull { it.playlist.id == data.savedPlaylistId }
                    ?: data.playlists.firstOrNull()
                val trackLookup = data.allTracks.associateBy { it.id }

                _uiState.update { current ->
                    if (current.isPlayingLiked) {
                        val refreshedQueue = current.sessionQueue.mapNotNull { trackLookup[it.id] }
                        current.copy(
                            isLoading = false,
                            activePlaylist = chosenPlaylist?.playlist ?: current.activePlaylist,
                            allPlaylists = data.playlists,
                            allTracks = data.allTracks,
                            likedTracks = data.likedTracks,
                            sessionQueue = if (refreshedQueue.isNotEmpty()) refreshedQueue else current.sessionQueue,
                            currentIndex = current.currentIndex.coerceIn(0, (refreshedQueue.size - 1).coerceAtLeast(0)),
                            isSmartShuffleEnabled = data.smartShuffle
                        )
                    } else if (chosenPlaylist == null) {
                        current.copy(
                            isLoading = data.allTracks.isEmpty(),
                            allPlaylists = data.playlists,
                            allTracks = data.allTracks,
                            likedTracks = data.likedTracks,
                            isSmartShuffleEnabled = data.smartShuffle
                        )
                    } else {
                        val playlistChanged = chosenPlaylist.playlist.id != loadedPlaylistId ||
                            chosenPlaylist.tracks.map { it.id }.toSet() != loadedPlaylistTrackSignature.toSet()

                        if (playlistChanged || current.sessionQueue.isEmpty()) {
                            loadedPlaylistId = chosenPlaylist.playlist.id
                            loadedPlaylistTrackSignature = chosenPlaylist.tracks.map { it.id }

                            val initialQueue = if (data.smartShuffle) {
                                SmartShuffleEngine.generateSessionQueue(
                                    tracks = chosenPlaylist.tracks,
                                    statsBySongId = latestStatsMap,
                                    anchorTrackId = null,
                                    recentTrackIds = recentTrackIds.toList(),
                                    recentArtists = recentArtists.toList(),
                                    batchSize = BATCH_SIZE
                                )
                            } else {
                                chosenPlaylist.tracks
                            }

                            mediaBridge.loadQueue(
                                queueTitle = chosenPlaylist.playlist.name,
                                tracks = initialQueue,
                                startIndex = 0,
                                autoPlay = current.isPlaying
                            )

                            current.copy(
                                isLoading = false,
                                activePlaylist = chosenPlaylist.playlist,
                                allPlaylists = data.playlists,
                                allTracks = data.allTracks,
                                likedTracks = data.likedTracks,
                                sessionQueue = initialQueue,
                                currentIndex = 0,
                                isSmartShuffleEnabled = data.smartShuffle
                            )
                        } else {
                            val refreshedQueue = current.sessionQueue.mapNotNull { trackLookup[it.id] }
                            current.copy(
                                isLoading = false,
                                activePlaylist = chosenPlaylist.playlist,
                                allPlaylists = data.playlists,
                                allTracks = data.allTracks,
                                likedTracks = data.likedTracks,
                                sessionQueue = if (refreshedQueue.isNotEmpty()) refreshedQueue else current.sessionQueue,
                                currentIndex = current.currentIndex.coerceIn(0, (refreshedQueue.size - 1).coerceAtLeast(0)),
                                isSmartShuffleEnabled = data.smartShuffle
                            )
                        }
                    }
                }
            }
        }

        // Observe Media3 playback snapshot
        viewModelScope.launch {
            mediaBridge.snapshot.collect { snap ->
                val prevState = _uiState.value
                val matchedIndex = when {
                    snap.currentMediaIndex in prevState.sessionQueue.indices &&
                        prevState.sessionQueue[snap.currentMediaIndex].id.toString() == snap.currentMediaId -> {
                        snap.currentMediaIndex
                    }
                    else -> {
                        snap.currentMediaId?.toLongOrNull()?.let { mediaId ->
                            prevState.sessionQueue.indexOfFirst { it.id == mediaId }.takeIf { it >= 0 }
                        } ?: prevState.currentIndex
                    }
                }

                val activeTrack = prevState.sessionQueue.getOrNull(matchedIndex)
                if (snap.isPlaying && activeTrack != null && activeTrack.id != lastRecordedPlayTrackId) {
                    lastRecordedPlayTrackId = activeTrack.id
                    recordHistoryEntry(activeTrack)
                    repository.recordPlayStart(activeTrack.id)
                }

                _uiState.update { state ->
                    state.copy(
                        isPlaying = snap.isPlaying,
                        currentIndex = matchedIndex,
                        positionMs = snap.positionMs,
                        durationMs = if (snap.durationMs > 0L) snap.durationMs else state.durationMs
                    )
                }

                maybeTopUpNextBatch()
            }
        }

        // Observe Media3 track transitions for natural completion tracking
        viewModelScope.launch {
            mediaBridge.transitions.collect { event ->
                if (event.isAutoCompletion && event.previousMediaId != null) {
                    repository.recordCompletion(event.previousMediaId)
                }
            }
        }
    }

    fun togglePlayPause() {
        val state = _uiState.value
        val current = state.currentTrack
        if (!state.isPlaying && current != null && current.id != lastRecordedPlayTrackId) {
            lastRecordedPlayTrackId = current.id
            recordHistoryEntry(current)
            viewModelScope.launch { repository.recordPlayStart(current.id) }
        }
        mediaBridge.togglePlayPause()
    }

    fun toggleLofi() {
        val nextEnabled = !_uiState.value.isLofiEnabled
        _uiState.update { it.copy(isLofiEnabled = nextEnabled) }
        mediaBridge.setLofiEnabled(nextEnabled)
        viewModelScope.launch { preferences.setLofiEnabled(nextEnabled) }
    }

    fun toggleEightD(firstUseHintMessage: String) {
        val nextEnabled = !_uiState.value.isEightDEnabled
        _uiState.update { it.copy(isEightDEnabled = nextEnabled) }
        mediaBridge.setEightDEnabled(nextEnabled)
        viewModelScope.launch {
            preferences.setEightDEnabled(nextEnabled)
            if (nextEnabled) {
                val alreadyShown = preferences.hasShownEightDHintFlow.first()
                if (!alreadyShown) {
                    preferences.markEightDHintShown()
                    showToast(firstUseHintMessage)
                }
            }
        }
    }

    fun swipeNext() {
        val state = _uiState.value
        if (state.sessionQueue.size <= 1) return
        val departing = state.currentTrack
        if (departing != null) {
            evaluateDepartureStats(departing, state.positionMs, state.effectiveDurationMs, state.isPlaying)
            recordHistoryEntry(departing)
        }
        val nextIdx = (state.currentIndex + 1) % state.sessionQueue.size
        _uiState.update { it.copy(currentIndex = nextIdx, positionMs = 0L) }
        mediaBridge.seekToNext(autoPlay = true)
        maybeTopUpNextBatch()
    }

    fun swipePrevious() {
        val state = _uiState.value
        if (state.sessionQueue.size <= 1) return
        val prevIdx = if (state.currentIndex - 1 < 0) state.sessionQueue.lastIndex else state.currentIndex - 1
        _uiState.update { it.copy(currentIndex = prevIdx, positionMs = 0L) }
        mediaBridge.seekToPrevious(autoPlay = true)
    }

    fun selectTrackFromQueue(trackId: Long) {
        val state = _uiState.value
        val playlistTracks = state.activePlaylistTracks
        val playlistName = state.activePlaylist?.name ?: "My Playlist"

        if (!state.isPlayingLiked) {
            val idx = state.sessionQueue.indexOfFirst { it.id == trackId }
            if (idx >= 0) {
                state.currentTrack?.let { departing ->
                    if (departing.id != trackId) {
                        evaluateDepartureStats(departing, state.positionMs, state.effectiveDurationMs, state.isPlaying)
                    }
                }
                state.sessionQueue.getOrNull(idx)?.let { recordHistoryEntry(it) }
                _uiState.update { it.copy(currentIndex = idx, positionMs = 0L) }
                mediaBridge.seekToQueueIndex(idx, autoPlay = true)
                maybeTopUpNextBatch()
                return
            }
        }

        // Either switching back from Liked mode or selecting a track outside the current 10-track batch
        val chosen = playlistTracks.firstOrNull { it.id == trackId } ?: return
        state.currentTrack?.let { departing ->
            if (departing.id != trackId) {
                evaluateDepartureStats(departing, state.positionMs, state.effectiveDurationMs, state.isPlaying)
            }
        }
        val newQueue = if (state.isSmartShuffleEnabled) {
            SmartShuffleEngine.generateSessionQueue(
                tracks = playlistTracks,
                statsBySongId = latestStatsMap,
                anchorTrackId = chosen.id,
                recentTrackIds = recentTrackIds.toList(),
                recentArtists = recentArtists.toList(),
                batchSize = BATCH_SIZE
            )
        } else {
            val idx = playlistTracks.indexOfFirst { it.id == chosen.id }.coerceAtLeast(0)
            playlistTracks.drop(idx) + playlistTracks.take(idx)
        }
        recordHistoryEntry(chosen)
        _uiState.update {
            it.copy(
                isPlayingLiked = false,
                sessionQueue = newQueue,
                currentIndex = 0,
                positionMs = 0L
            )
        }
        mediaBridge.loadQueue(
            queueTitle = playlistName,
            tracks = newQueue,
            startIndex = 0,
            autoPlay = true
        )
    }

    fun seekTo(positionMs: Long) {
        _uiState.update { it.copy(positionMs = positionMs) }
        mediaBridge.seekToPosition(positionMs)
    }

    /**
     * Toggles Hot globally for the active song and immediately re-weights upcoming tracks
     * in the queue without restarting playback.
     */
    fun toggleHot() {
        val current = _uiState.value.currentTrack ?: return
        val nextPref = if (current.preference == TrackPreference.HOT) {
            TrackPreference.NEUTRAL
        } else {
            TrackPreference.HOT
        }
        viewModelScope.launch {
            repository.updateTrackPreference(current.id, nextPref)
            reweightUpcomingQueueInPlace(updatedTrackId = current.id, newPreference = nextPref)
        }
    }

    /**
     * Toggles Cool globally for the active song. When turning Cool ON:
     * lowers weight, re-weights upcoming songs immediately, records early skip if < 10s,
     * and softly fades out & skips to the next song.
     */
    fun toggleCool() {
        val state = _uiState.value
        val current = state.currentTrack ?: return
        val turningCoolOn = current.preference != TrackPreference.COOL
        val nextPref = if (turningCoolOn) TrackPreference.COOL else TrackPreference.NEUTRAL

        viewModelScope.launch {
            repository.updateTrackPreference(current.id, nextPref)
            if (turningCoolOn && state.positionMs < EARLY_SKIP_THRESHOLD_MS) {
                repository.recordEarlySkip(current.id)
            }
            reweightUpcomingQueueInPlace(updatedTrackId = current.id, newPreference = nextPref)

            if (turningCoolOn && _uiState.value.sessionQueue.size > 1) {
                recordHistoryEntry(current)
                mediaBridge.softSkipNext()
            }
        }
    }

    /**
     * Live queue update: replaces only the unplayed tracks ahead of the current song
     * using updated global stats so Hot/Cool changes take effect on the very next tracks
     * with zero interruption or restart.
     */
    private fun reweightUpcomingQueueInPlace(updatedTrackId: Long, newPreference: TrackPreference) {
        val state = _uiState.value
        if (!state.isSmartShuffleEnabled) return
        val currentTrack = state.currentTrack ?: return
        val fullPool = activeSourcePool(state).map {
            if (it.id == updatedTrackId) it.copy(preference = newPreference) else it
        }
        if (fullPool.size <= 1) return

        val updatedStats = latestStatsMap.toMutableMap()
        val prevStat = updatedStats[updatedTrackId] ?: SongStats(songId = updatedTrackId)
        updatedStats[updatedTrackId] = when (newPreference) {
            TrackPreference.HOT -> prevStat.copy(isHot = true, hotScore = prevStat.hotScore + 1f, isCool = false)
            TrackPreference.COOL -> prevStat.copy(isHot = false, isCool = true, coolScore = prevStat.coolScore + 1f)
            TrackPreference.NEUTRAL -> prevStat.copy(isHot = false, isCool = false)
        }
        latestStatsMap = updatedStats

        val updatedAnchor = if (currentTrack.id == updatedTrackId) {
            currentTrack.copy(preference = newPreference)
        } else currentTrack

        val upcomingBatch = SmartShuffleEngine.generateNextBatch(
            pool = fullPool,
            statsBySongId = updatedStats,
            recentTrackIds = (recentTrackIds.toList() + updatedAnchor.id).distinct(),
            recentArtists = recentArtists.toList() + updatedAnchor.artist.trim().lowercase(),
            lastTrack = updatedAnchor,
            excludeIds = setOf(updatedAnchor.id),
            batchSize = BATCH_SIZE
        )

        val playedPrefix = state.sessionQueue.take(state.currentIndex).map {
            if (it.id == updatedTrackId) it.copy(preference = newPreference) else it
        }
        val rebuiltQueue = playedPrefix + listOf(updatedAnchor) + upcomingBatch

        _uiState.update { it.copy(sessionQueue = rebuiltQueue) }
        mediaBridge.replaceUpcomingKeepingCurrent(
            queueTitle = state.headerTitle,
            upcomingTracks = upcomingBatch
        )
    }

    /**
     * Appends the next influenced batch of ~10 tracks whenever the listener approaches
     * the end of the currently generated batch.
     */
    private fun maybeTopUpNextBatch() {
        val state = _uiState.value
        if (!state.isSmartShuffleEnabled) return
        val fullPool = activeSourcePool(state)
        if (fullPool.size <= BATCH_SIZE) return

        val remainingAhead = state.sessionQueue.size - 1 - state.currentIndex
        if (remainingAhead >= BATCH_TOP_UP_BUFFER) return

        val upcomingIds = state.sessionQueue
            .drop(state.currentIndex)
            .map { it.id }
            .toSet()

        val lastQueued = state.sessionQueue.lastOrNull()
        val tailArtists = state.sessionQueue.takeLast(3).map { it.artist.trim().lowercase() }
        val nextBatch = SmartShuffleEngine.generateNextBatch(
            pool = fullPool,
            statsBySongId = latestStatsMap,
            recentTrackIds = (recentTrackIds.toList() + state.sessionQueue.takeLast(20).map { it.id }),
            recentArtists = tailArtists,
            lastTrack = lastQueued,
            excludeIds = upcomingIds,
            batchSize = BATCH_SIZE
        )

        if (nextBatch.isNotEmpty()) {
            _uiState.update { it.copy(sessionQueue = it.sessionQueue + nextBatch) }
            mediaBridge.appendUpcomingBatch(state.headerTitle, nextBatch)
        }
    }

    // =========================================================================
    // LIKED SONGS QUEUE ACTIONS (Part 2)
    // =========================================================================

    fun playLikedQueue(reshuffleMessage: String? = null) {
        val state = _uiState.value
        val liked = state.likedTracks
        if (liked.isEmpty()) return

        val newQueue = SmartShuffleEngine.generateSessionQueue(
            tracks = liked,
            statsBySongId = latestStatsMap,
            anchorTrackId = null,
            recentTrackIds = recentTrackIds.toList(),
            recentArtists = recentArtists.toList(),
            batchSize = BATCH_SIZE
        )

        _uiState.update {
            it.copy(
                isPlayingLiked = true,
                isSmartShuffleEnabled = true,
                sessionQueue = newQueue,
                currentIndex = 0,
                positionMs = 0L
            )
        }
        mediaBridge.loadQueue(
            queueTitle = "Liked",
            tracks = newQueue,
            startIndex = 0,
            autoPlay = true
        )
        reshuffleMessage?.let { showToast(it) }
    }

    fun selectTrackFromLiked(trackId: Long) {
        val state = _uiState.value
        val liked = state.likedTracks
        if (liked.isEmpty()) return

        val tappedTrack = liked.firstOrNull { it.id == trackId } ?: return
        val newQueue = if (state.isSmartShuffleEnabled) {
            SmartShuffleEngine.generateSessionQueue(
                tracks = liked,
                statsBySongId = latestStatsMap,
                anchorTrackId = tappedTrack.id,
                recentTrackIds = recentTrackIds.toList(),
                recentArtists = recentArtists.toList(),
                batchSize = BATCH_SIZE
            )
        } else {
            val idx = liked.indexOfFirst { it.id == trackId }.coerceAtLeast(0)
            liked.drop(idx) + liked.take(idx)
        }

        recordHistoryEntry(tappedTrack)
        _uiState.update {
            it.copy(
                isPlayingLiked = true,
                sessionQueue = newQueue,
                currentIndex = 0,
                positionMs = 0L
            )
        }
        mediaBridge.loadQueue(
            queueTitle = "Liked",
            tracks = newQueue,
            startIndex = 0,
            autoPlay = true
        )
    }

    fun removeFromLiked(track: Track) {
        viewModelScope.launch {
            repository.updateTrackPreference(track.id, TrackPreference.NEUTRAL)
            reweightUpcomingQueueInPlace(updatedTrackId = track.id, newPreference = TrackPreference.NEUTRAL)

            undoJob?.cancel()
            _uiState.update { it.copy(undoLikedRemoval = UndoLikedRemoval(track)) }
            undoJob = viewModelScope.launch {
                delay(4200L)
                _uiState.update { state ->
                    if (state.undoLikedRemoval?.track?.id == track.id) {
                        state.copy(undoLikedRemoval = null)
                    } else state
                }
            }
        }
    }

    fun undoRemoveFromLiked() {
        val pending = _uiState.value.undoLikedRemoval ?: return
        undoJob?.cancel()
        _uiState.update { it.copy(undoLikedRemoval = null) }
        viewModelScope.launch {
            repository.updateTrackPreference(pending.track.id, TrackPreference.HOT)
            reweightUpcomingQueueInPlace(updatedTrackId = pending.track.id, newPreference = TrackPreference.HOT)
        }
    }

    fun dismissUndoLiked() {
        undoJob?.cancel()
        _uiState.update { it.copy(undoLikedRemoval = null) }
    }

    // =========================================================================
    // PLAYLIST & SHUFFLE CONTROLS
    // =========================================================================

    fun toggleSmartShuffle(reshuffleMessage: String, sequentialMessage: String) {
        val state = _uiState.value
        val nextEnabled = !state.isSmartShuffleEnabled
        val fullPool = activeSourcePool(state)

        viewModelScope.launch {
            preferences.setSmartShuffleEnabled(nextEnabled)
            if (fullPool.isNotEmpty()) {
                val anchor = state.currentTrack
                if (nextEnabled) {
                    val upcoming = SmartShuffleEngine.generateNextBatch(
                        pool = fullPool,
                        statsBySongId = latestStatsMap,
                        recentTrackIds = (recentTrackIds.toList() + listOfNotNull(anchor?.id)).distinct(),
                        recentArtists = recentArtists.toList(),
                        lastTrack = anchor,
                        excludeIds = setOfNotNull(anchor?.id),
                        batchSize = BATCH_SIZE
                    )
                    val newQueue = if (anchor != null) listOf(anchor) + upcoming else upcoming
                    _uiState.update {
                        it.copy(
                            isSmartShuffleEnabled = true,
                            sessionQueue = newQueue,
                            currentIndex = 0
                        )
                    }
                    if (anchor != null) {
                        mediaBridge.replaceUpcomingKeepingCurrent(state.headerTitle, upcoming)
                    } else {
                        mediaBridge.loadQueue(state.headerTitle, newQueue, 0, state.isPlaying)
                    }
                } else {
                    val newIndex = fullPool.indexOfFirst { it.id == anchor?.id }.coerceAtLeast(0)
                    _uiState.update {
                        it.copy(
                            isSmartShuffleEnabled = false,
                            sessionQueue = fullPool,
                            currentIndex = newIndex
                        )
                    }
                    mediaBridge.loadQueue(
                        queueTitle = state.headerTitle,
                        tracks = fullPool,
                        startIndex = newIndex,
                        autoPlay = state.isPlaying
                    )
                }
            }
            showToast(if (nextEnabled) reshuffleMessage else sequentialMessage)
        }
    }

    fun switchPlaylist(playlistId: Long) {
        val state = _uiState.value
        val targetPlaylist = state.allPlaylists.firstOrNull { it.playlist.id == playlistId }
        if (state.isPlayingLiked && targetPlaylist != null) {
            // Return from Liked queue back to normal playlist
            loadedPlaylistId = null
            _uiState.update { it.copy(isPlayingLiked = false) }
        }
        viewModelScope.launch {
            preferences.setActivePlaylistId(playlistId)
        }
    }

    fun returnToActivePlaylist() {
        val state = _uiState.value
        if (!state.isPlayingLiked) return
        val activeId = state.activePlaylist?.id ?: state.allPlaylists.firstOrNull()?.playlist?.id ?: return
        switchPlaylist(activeId)
    }

    fun saveAndLaunchPlaylist(
        existingPlaylistId: Long?,
        name: String,
        trackIds: List<Long>,
        savedMessage: String,
        onComplete: () -> Unit
    ) {
        if (trackIds.isEmpty()) return
        viewModelScope.launch {
            val savedId = repository.savePlaylist(existingPlaylistId, name, trackIds)
            loadedPlaylistId = null
            _uiState.update { it.copy(isPlayingLiked = false) }
            preferences.setActivePlaylistId(savedId)
            showToast(savedMessage)
            onComplete()
        }
    }

    fun importLocalAudio(uris: List<Uri>, onImported: (List<Long>) -> Unit) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val ids = repository.importLocalAudioTracks(uris)
            onImported(ids)
        }
    }

    private fun activeSourcePool(state: AuraUiState): List<Track> {
        return if (state.isPlayingLiked) {
            state.likedTracks
        } else {
            state.allPlaylists.firstOrNull { it.playlist.id == state.activePlaylist?.id }?.tracks
                ?: state.sessionQueue
        }
    }

    private fun evaluateDepartureStats(
        track: Track,
        positionMs: Long,
        durationMs: Long,
        wasPlaying: Boolean
    ) {
        if (!wasPlaying && positionMs <= 0L) return
        viewModelScope.launch {
            when {
                positionMs in 1L until EARLY_SKIP_THRESHOLD_MS -> repository.recordEarlySkip(track.id)
                durationMs > 0L && positionMs >= (durationMs * 0.85f).toLong() -> repository.recordCompletion(track.id)
            }
        }
    }

    private fun recordHistoryEntry(track: Track) {
        recentTrackIds.remove(track.id)
        recentTrackIds.addLast(track.id)
        while (recentTrackIds.size > 24) {
            recentTrackIds.removeFirst()
        }
        recentArtists.addLast(track.artist.trim().lowercase())
        while (recentArtists.size > 4) {
            recentArtists.removeFirst()
        }
    }

    private fun showToast(message: String) {
        toastJob?.cancel()
        toastJob = viewModelScope.launch {
            _uiState.update { it.copy(toastMessage = message) }
            delay(2600L)
            _uiState.update { state ->
                if (state.toastMessage == message) state.copy(toastMessage = null) else state
            }
        }
    }

    override fun onCleared() {
        mediaBridge.release()
        super.onCleared()
    }

    private data class CombinedData(
        val playlists: List<PlaylistWithTracks>,
        val allTracks: List<Track>,
        val likedTracks: List<Track>,
        val savedPlaylistId: Long?,
        val smartShuffle: Boolean
    )
}
