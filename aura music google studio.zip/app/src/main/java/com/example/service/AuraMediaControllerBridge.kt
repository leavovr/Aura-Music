package com.example.service

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.audio.SongArtworkLoader
import com.example.data.model.Track
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class PlaybackSnapshot(
    val isConnected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentMediaId: String? = null,
    val currentMediaIndex: Int = 0,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

data class MediaTransitionEvent(
    val previousMediaId: Long?,
    val newMediaId: Long?,
    val isAutoCompletion: Boolean
)

class AuraMediaControllerBridge(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var progressJob: Job? = null
    private var pendingQueue: PendingQueueLoad? = null
    private var pendingLofi: Boolean? = null
    private var pendingEightD: Boolean? = null
    private var lastReportedMediaId: Long? = null

    private val _snapshot = MutableStateFlow(PlaybackSnapshot())
    val snapshot: StateFlow<PlaybackSnapshot> = _snapshot.asStateFlow()

    private val _transitions = MutableSharedFlow<MediaTransitionEvent>(extraBufferCapacity = 16)
    val transitions: SharedFlow<MediaTransitionEvent> = _transitions.asSharedFlow()

    private val artworkBytesCache = ConcurrentHashMap<String, ByteArray>()

    private data class PendingQueueLoad(
        val queueTitle: String,
        val tracks: List<Track>,
        val startIndex: Int,
        val autoPlay: Boolean
    )

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            publishState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            publishState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val prevId = lastReportedMediaId
            val newId = mediaItem?.mediaId?.toLongOrNull()
            lastReportedMediaId = newId
            val isAuto = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
            _transitions.tryEmit(
                MediaTransitionEvent(
                    previousMediaId = prevId,
                    newMediaId = newId,
                    isAutoCompletion = isAuto
                )
            )
            publishState()
        }
    }

    fun connect() {
        if (controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, AuraPlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                runCatching { future.get() }.onSuccess { mediaController ->
                    controller = mediaController
                    mediaController.addListener(playerListener)
                    lastReportedMediaId = mediaController.currentMediaItem?.mediaId?.toLongOrNull()
                    startProgressTicker()
                    publishState()

                    pendingLofi?.let { enabled ->
                        pendingLofi = null
                        setLofiEnabled(enabled)
                    }
                    pendingEightD?.let { enabled ->
                        pendingEightD = null
                        setEightDEnabled(enabled)
                    }
                    pendingQueue?.let { load ->
                        pendingQueue = null
                        loadQueue(load.queueTitle, load.tracks, load.startIndex, load.autoPlay)
                    }
                }
            },
            ContextCompat.getMainExecutor(context)
        )
    }

    fun setLofiEnabled(enabled: Boolean) {
        val ctrl = controller
        if (ctrl == null) {
            pendingLofi = enabled
            return
        }
        val args = Bundle().apply { putBoolean(AuraPlaybackService.EXTRA_ENABLED, enabled) }
        ctrl.sendCustomCommand(AuraPlaybackService.COMMAND_SET_LOFI, args)
    }

    fun setEightDEnabled(enabled: Boolean) {
        val ctrl = controller
        if (ctrl == null) {
            pendingEightD = enabled
            return
        }
        val args = Bundle().apply { putBoolean(AuraPlaybackService.EXTRA_ENABLED, enabled) }
        ctrl.sendCustomCommand(AuraPlaybackService.COMMAND_SET_8D, args)
    }

    fun softSkipNext() {
        val ctrl = controller ?: return
        ctrl.sendCustomCommand(AuraPlaybackService.COMMAND_SOFT_SKIP_NEXT, Bundle.EMPTY)
    }

    fun loadQueue(
        queueTitle: String,
        tracks: List<Track>,
        startIndex: Int = 0,
        autoPlay: Boolean = false
    ) {
        val ctrl = controller
        if (ctrl == null) {
            pendingQueue = PendingQueueLoad(queueTitle, tracks, startIndex, autoPlay)
            return
        }
        if (tracks.isEmpty()) return

        scope.launch {
            val mediaItems = withContext(Dispatchers.IO) {
                tracks.map { track -> buildMediaItem(queueTitle, track) }
            }
            val safeIndex = startIndex.coerceIn(0, mediaItems.lastIndex)
            ctrl.setMediaItems(mediaItems, safeIndex, 0L)
            ctrl.repeatMode = Player.REPEAT_MODE_ALL
            ctrl.prepare()
            if (autoPlay) {
                ctrl.play()
            }
            lastReportedMediaId = tracks[safeIndex].id
            publishState()
        }
    }

    /**
     * Replaces only the upcoming (not yet played) items after the currently playing track
     * so live Hot/Cool re-weighting applies seamlessly with zero playback restart.
     */
    fun replaceUpcomingKeepingCurrent(
        queueTitle: String,
        upcomingTracks: List<Track>
    ) {
        val ctrl = controller ?: return
        scope.launch {
            val currentIdx = ctrl.currentMediaItemIndex
            val totalCount = ctrl.mediaItemCount
            if (currentIdx !in 0 until totalCount) return@launch

            val upcomingItems = withContext(Dispatchers.IO) {
                upcomingTracks.map { buildMediaItem(queueTitle, it) }
            }
            if (currentIdx + 1 < totalCount) {
                ctrl.removeMediaItems(currentIdx + 1, totalCount)
            }
            if (upcomingItems.isNotEmpty()) {
                ctrl.addMediaItems(upcomingItems)
            }
        }
    }

    /**
     * Appends the next batch of ~10 influenced-shuffle songs ahead of the listener.
     */
    fun appendUpcomingBatch(
        queueTitle: String,
        additionalTracks: List<Track>
    ) {
        val ctrl = controller ?: return
        if (additionalTracks.isEmpty()) return

        scope.launch {
            val items = withContext(Dispatchers.IO) {
                additionalTracks.map { buildMediaItem(queueTitle, it) }
            }
            ctrl.addMediaItems(items)
        }
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) {
            ctrl.pause()
        } else {
            if (ctrl.playbackState == Player.STATE_IDLE && ctrl.mediaItemCount > 0) {
                ctrl.prepare()
            }
            ctrl.play()
        }
        publishState()
    }

    fun seekToQueueIndex(index: Int, autoPlay: Boolean = true) {
        val ctrl = controller ?: return
        if (index in 0 until ctrl.mediaItemCount) {
            ctrl.seekToDefaultPosition(index)
            if (autoPlay) ctrl.play()
            publishState()
        }
    }

    fun seekToTrackById(trackId: Long, autoPlay: Boolean = true) {
        val ctrl = controller ?: return
        val targetId = trackId.toString()
        for (i in 0 until ctrl.mediaItemCount) {
            if (ctrl.getMediaItemAt(i).mediaId == targetId) {
                ctrl.seekToDefaultPosition(i)
                if (autoPlay) ctrl.play()
                publishState()
                return
            }
        }
    }

    fun seekToNext(autoPlay: Boolean = true) {
        val ctrl = controller ?: return
        if (ctrl.mediaItemCount <= 1) return
        val nextIndex = (ctrl.currentMediaItemIndex + 1) % ctrl.mediaItemCount
        ctrl.seekToDefaultPosition(nextIndex)
        if (autoPlay) ctrl.play()
        publishState()
    }

    fun seekToPrevious(autoPlay: Boolean = true) {
        val ctrl = controller ?: return
        if (ctrl.mediaItemCount <= 1) return
        val prevIndex = if (ctrl.currentMediaItemIndex - 1 < 0) {
            ctrl.mediaItemCount - 1
        } else {
            ctrl.currentMediaItemIndex - 1
        }
        ctrl.seekToDefaultPosition(prevIndex)
        if (autoPlay) ctrl.play()
        publishState()
    }

    fun seekToPosition(positionMs: Long) {
        val ctrl = controller ?: return
        ctrl.seekTo(positionMs.coerceAtLeast(0L))
        publishState()
    }

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                publishState()
                delay(280L)
            }
        }
    }

    private fun publishState() {
        val ctrl = controller ?: return
        val rawDuration = ctrl.duration
        _snapshot.value = PlaybackSnapshot(
            isConnected = true,
            isPlaying = ctrl.isPlaying,
            currentMediaId = ctrl.currentMediaItem?.mediaId,
            currentMediaIndex = ctrl.currentMediaItemIndex.coerceAtLeast(0),
            positionMs = ctrl.currentPosition.coerceAtLeast(0L),
            durationMs = if (rawDuration > 0L) rawDuration else 0L
        )
    }

    private suspend fun buildMediaItem(queueTitle: String, track: Track): MediaItem {
        val cacheKey = track.artworkUri ?: "fallback_${track.id}"
        val artBytes = artworkBytesCache[cacheKey] ?: SongArtworkLoader.loadNotificationArtworkBytes(
            context = context,
            cachedArtworkUri = track.artworkUri,
            audioUri = track.audioUri,
            trackId = track.id,
            fallbackDrawableRes = track.deterministicFallbackDrawableRes()
        )?.also { artworkBytesCache[cacheKey] = it }

        val metadataBuilder = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setAlbumTitle(queueTitle)
            .setGenre(track.vibe)

        if (artBytes != null) {
            metadataBuilder.setArtworkData(artBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
        }

        return MediaItem.Builder()
            .setMediaId(track.id.toString())
            .setUri(Uri.parse(track.audioUri))
            .setMediaMetadata(metadataBuilder.build())
            .build()
    }

    fun release() {
        progressJob?.cancel()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        controllerFuture = null
    }
}
