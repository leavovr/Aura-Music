package com.example.service.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Real-time Media3 PCM AudioProcessor delivering immersive 8D spatial rotation:
 * - Virtual sound source smoothly orbits the head (1 full 360-degree cycle every ~9 seconds)
 * - Equal-power panning with natural head-shadow ambient floor
 * - Sub-millisecond Interaural Time Delay (ITD, 0..0.6 ms) with linear interpolation
 * - Dynamic far-ear & behind-head low-pass head-shadow filtering
 * - Subtle rear-hemisphere volume attenuation + spacious room reverb
 * - Smooth ~300 ms wet/dry cross-fade so toggling never clicks, pops, or restarts playback
 * - Handles mono (upmixed to stereo) and stereo 16-bit PCM with low CPU usage
 */
@UnstableApi
class EightDAudioProcessor : BaseAudioProcessor() {

    @Volatile
    private var targetEnabled: Boolean = false

    private var currentMix: Float = 0f
    private var rampStepPerSample: Float = 0.0001f

    private var inputChannelCount: Int = 2
    private var sampleRate: Int = 44100

    // Orbit angle in radians (1 full rotation every 9.0 seconds)
    private var angleRad: Double = 0.0
    private var angleIncrement: Double = 0.0

    // Interaural Time Delay (ITD) ring buffers (up to ~0.6 ms)
    private var maxItdSamples: Float = 26f
    private var itdBufL = FloatArray(64)
    private var itdBufR = FloatArray(64)
    private var itdWriteIdx: Int = 0

    // Dynamic head-shadow 1-pole low-pass filter states per ear
    private var shadowLpL: Float = 0f
    private var shadowLpR: Float = 0f

    // Spatial room reverb delay lines (~21ms & ~29ms stereo cross-fed)
    private var revBufL = FloatArray(1)
    private var revBufR = FloatArray(1)
    private var revIdxL: Int = 0
    private var revIdxR: Int = 0
    private var revDampL: Float = 0f
    private var revDampR: Float = 0f

    fun setEnabled(enabled: Boolean) {
        targetEnabled = enabled
    }

    fun setEnabledImmediate(enabled: Boolean) {
        targetEnabled = enabled
        currentMix = if (enabled) 1f else 0f
    }

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT ||
            inputAudioFormat.channelCount !in 1..2
        ) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }

        inputChannelCount = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8000)

        // ~300 ms smooth cross-fade ramp
        rampStepPerSample = 1f / (0.300f * sampleRate)

        // One full 360-degree revolution every 9.0 seconds
        val rotationHz = 1.0 / 9.0
        angleIncrement = (2.0 * PI * rotationHz) / sampleRate

        // 0.6 ms max interaural time delay
        maxItdSamples = 0.0006f * sampleRate
        val itdBufSize = (maxItdSamples.toInt() + 8).coerceAtLeast(16)
        itdBufL = FloatArray(itdBufSize)
        itdBufR = FloatArray(itdBufSize)
        itdWriteIdx = 0

        // Lightweight spacious room reverb buffers
        revBufL = FloatArray((sampleRate * 0.0213f).toInt().coerceAtLeast(32))
        revBufR = FloatArray((sampleRate * 0.0289f).toInt().coerceAtLeast(32))
        clearStates()

        return AudioFormat(sampleRate, 2, C.ENCODING_PCM_16BIT)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining <= 0) return

        val bytesPerInputFrame = inputChannelCount * 2
        val frameCount = remaining / bytesPerInputFrame
        if (frameCount <= 0) return

        val outputBuffer = replaceOutputBuffer(frameCount * 4)
        val enabledNow = targetEnabled

        // Ultra-low CPU bypass path when fully dry
        if (!enabledNow && currentMix <= 0.0001f) {
            currentMix = 0f
            if (inputChannelCount == 2) {
                val limit = inputBuffer.position() + frameCount * 4
                val oldLimit = inputBuffer.limit()
                inputBuffer.limit(limit)
                outputBuffer.put(inputBuffer)
                inputBuffer.limit(oldLimit)
            } else {
                for (i in 0 until frameCount) {
                    val sample = inputBuffer.short
                    outputBuffer.putShort(sample)
                    outputBuffer.putShort(sample)
                }
            }
            outputBuffer.flip()
            return
        }

        val targetMix = if (enabledNow) 1f else 0f
        val twoPi = 2.0 * PI
        val halfPi = PI * 0.5
        val itdLen = itdBufL.size

        for (i in 0 until frameCount) {
            if (currentMix < targetMix) {
                currentMix = (currentMix + rampStepPerSample).coerceAtMost(targetMix)
            } else if (currentMix > targetMix) {
                currentMix = (currentMix - rampStepPerSample).coerceAtLeast(targetMix)
            }

            val dryL: Float
            val dryR: Float
            if (inputChannelCount == 2) {
                dryL = inputBuffer.short / 32768f
                dryR = inputBuffer.short / 32768f
            } else {
                val mono = inputBuffer.short / 32768f
                dryL = mono
                dryR = mono
            }

            // Advance virtual sound source around the listener's head
            angleRad += angleIncrement
            if (angleRad >= twoPi) angleRad -= twoPi

            val pan = sin(angleRad).toFloat()       // -1 (left) .. +1 (right)
            val frontBack = cos(angleRad).toFloat() // +1 (front) .. -1 (behind)

            // Focus stereo image into a coherent orbiting virtual point while keeping subtle width
            val monoCore = (dryL + dryR) * 0.5f
            val srcL = monoCore * 0.65f + dryL * 0.35f
            val srcR = monoCore * 0.65f + dryR * 0.35f

            // Write into ITD ring buffers
            itdBufL[itdWriteIdx] = srcL
            itdBufR[itdWriteIdx] = srcR

            // Interaural Time Delay: far ear arrives up to 0.6 ms later
            val delayL = if (pan > 0f) pan * maxItdSamples else 0f
            val delayR = if (pan < 0f) -pan * maxItdSamples else 0f

            val delayedL = readInterpolated(itdBufL, itdWriteIdx, delayL, itdLen)
            val delayedR = readInterpolated(itdBufR, itdWriteIdx, delayR, itdLen)

            itdWriteIdx++
            if (itdWriteIdx >= itdLen) itdWriteIdx = 0

            // Equal-power panning with natural head-shadow floor (keeps far ear organic)
            val normPan = (pan + 1f) * 0.5f
            val panTheta = normPan * halfPi
            val eqL = cos(panTheta).toFloat()
            val eqR = sin(panTheta).toFloat()
            val gainL = 0.24f + 0.86f * eqL
            val gainR = 0.24f + 0.86f * eqR

            // Rear-hemisphere subtle attenuation (sounds slightly softer behind listener)
            val behindFactor = ((1f - frontBack) * 0.5f).coerceIn(0f, 1f) // 0 in front, 1 behind
            val rearAtten = 1f - behindFactor * 0.16f

            // Head-shadow low-pass on the far ear and when moving behind the listener
            val farEarL = pan.coerceAtLeast(0f)      // 0..1 when source is to the right
            val farEarR = (-pan).coerceAtLeast(0f)   // 0..1 when source is to the left
            val lpCoeffL = (0.96f - farEarL * 0.58f - behindFactor * 0.22f).coerceIn(0.18f, 0.96f)
            val lpCoeffR = (0.96f - farEarR * 0.58f - behindFactor * 0.22f).coerceIn(0.18f, 0.96f)

            shadowLpL += lpCoeffL * (delayedL - shadowLpL)
            shadowLpR += lpCoeffR * (delayedR - shadowLpR)

            val directL = shadowLpL * gainL * rearAtten
            val directR = shadowLpR * gainR * rearAtten

            // Spacious cross-fed room reverb tail so movement feels like an acoustic hall
            val rL = revBufL[revIdxL]
            val rR = revBufR[revIdxR]
            revDampL = rL * 0.72f + revDampL * 0.28f
            revDampR = rR * 0.72f + revDampR * 0.28f
            revBufL[revIdxL] = directL * 0.7f + directR * 0.3f + revDampR * 0.40f
            revBufR[revIdxR] = directR * 0.7f + directL * 0.3f + revDampL * 0.40f
            revIdxL = (revIdxL + 1) % revBufL.size
            revIdxR = (revIdxR + 1) % revBufR.size

            val wetL = directL * 0.84f + rL * 0.24f
            val wetR = directR * 0.84f + rR * 0.24f

            // Smooth 300ms dry <-> wet cross-fade
            val mix = currentMix
            val invMix = 1f - mix
            val outL = (dryL * invMix + wetL * mix).coerceIn(-0.99f, 0.99f)
            val outR = (dryR * invMix + wetR * mix).coerceIn(-0.99f, 0.99f)

            outputBuffer.putShort((outL * 32767f).toInt().toShort())
            outputBuffer.putShort((outR * 32767f).toInt().toShort())
        }

        outputBuffer.flip()
    }

    private fun readInterpolated(
        buffer: FloatArray,
        writeIdx: Int,
        delaySamples: Float,
        len: Int
    ): Float {
        val intDelay = delaySamples.toInt()
        val frac = delaySamples - intDelay
        var idx0 = writeIdx - intDelay
        if (idx0 < 0) idx0 += len
        var idx1 = idx0 - 1
        if (idx1 < 0) idx1 += len
        return buffer[idx0] * (1f - frac) + buffer[idx1] * frac
    }

    override fun onFlush() {
        clearStates()
    }

    override fun onReset() {
        clearStates()
    }

    private fun clearStates() {
        itdBufL.fill(0f)
        itdBufR.fill(0f)
        itdWriteIdx = 0
        shadowLpL = 0f
        shadowLpR = 0f
        revBufL.fill(0f)
        revBufR.fill(0f)
        revIdxL = 0
        revIdxR = 0
        revDampL = 0f
        revDampR = 0f
    }
}
