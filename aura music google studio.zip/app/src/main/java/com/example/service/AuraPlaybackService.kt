package com.example.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.example.MainActivity
import com.example.data.preferences.AuraPreferencesRepository
import com.example.service.audio.EightDAudioProcessor
import com.example.service.audio.LofiAudioProcessor
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Samsung Music-style Media3 foreground playback service with real-time DSP effects.
 * - Holds a local CPU WakeLock so playback continues uninterrupted when the screen turns off.
 * - Permanently hosts LofiAudioProcessor and EightDAudioProcessor in DefaultAudioSink
 *   so toggling effects cross-fades smoothly over ~300 ms with zero playback gap or restart.
 * - Supports soft fade-out skip when the user marks the current song Cool.
 */
@OptIn(UnstableApi::class)
class AuraPlaybackService : MediaSessionService() {

    companion object {
        const val ACTION_SET_LOFI = "com.example.aura.ACTION_SET_LOFI"
        const val ACTION_SET_8D = "com.example.aura.ACTION_SET_8D"
        const val ACTION_SOFT_SKIP_NEXT = "com.example.aura.ACTION_SOFT_SKIP_NEXT"
        const val EXTRA_ENABLED = "extra_enabled"

        val COMMAND_SET_LOFI = SessionCommand(ACTION_SET_LOFI, Bundle.EMPTY)
        val COMMAND_SET_8D = SessionCommand(ACTION_SET_8D, Bundle.EMPTY)
        val COMMAND_SOFT_SKIP_NEXT = SessionCommand(ACTION_SOFT_SKIP_NEXT, Bundle.EMPTY)

        private const val LOFI_SPEED_PITCH = 0.90f
        private const val NORMAL_SPEED_PITCH = 1.00f
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var preferences: AuraPreferencesRepository

    private val lofiProcessor = LofiAudioProcessor()
    private val eightDProcessor = EightDAudioProcessor()

    private var mediaSession: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null
    private var speedRampJob: Job? = null
    private var softSkipJob: Job? = null
    private var currentSpeedPitch: Float = NORMAL_SPEED_PITCH

    override fun onCreate() {
        super.onCreate()
        preferences = AuraPreferencesRepository(applicationContext)

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(lofiProcessor, eightDProcessor))
                    .build()
            }
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val player = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ALL
            }
        exoPlayer = player

        serviceScope.launch {
            val savedLofi = preferences.lofiEnabledFlow.first()
            val savedEightD = preferences.eightDEnabledFlow.first()
            lofiProcessor.setEnabledImmediate(savedLofi)
            eightDProcessor.setEnabledImmediate(savedEightD)
            val targetParam = if (savedLofi) LOFI_SPEED_PITCH else NORMAL_SPEED_PITCH
            currentSpeedPitch = targetParam
            player.playbackParameters = PlaybackParameters(targetParam, targetParam)
        }

        val sessionActivityIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val callback = object : MediaSession.Callback {
            override fun onConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo
            ): MediaSession.ConnectionResult {
                val sessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                    .buildUpon()
                    .add(COMMAND_SET_LOFI)
                    .add(COMMAND_SET_8D)
                    .add(COMMAND_SOFT_SKIP_NEXT)
                    .build()
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(sessionCommands)
                    .build()
            }

            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                customCommand: SessionCommand,
                args: Bundle
            ): ListenableFuture<SessionResult> {
                val enabled = args.getBoolean(EXTRA_ENABLED, false)
                when (customCommand.customAction) {
                    ACTION_SET_LOFI -> {
                        applyLofiSmooth(enabled)
                        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                    }
                    ACTION_SET_8D -> {
                        eightDProcessor.setEnabled(enabled)
                        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                    }
                    ACTION_SOFT_SKIP_NEXT -> {
                        performSoftFadeSkip()
                        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                    }
                }
                return super.onCustomCommand(session, controller, customCommand, args)
            }
        }

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityIntent)
            .setCallback(callback)
            .build()
    }

    private fun applyLofiSmooth(enabled: Boolean) {
        lofiProcessor.setEnabled(enabled)
        val player = exoPlayer ?: return
        val target = if (enabled) LOFI_SPEED_PITCH else NORMAL_SPEED_PITCH
        val start = currentSpeedPitch

        speedRampJob?.cancel()
        speedRampJob = serviceScope.launch {
            val steps = 10
            val stepDelayMs = 30L
            for (step in 1..steps) {
                val frac = step.toFloat() / steps.toFloat()
                val value = start + (target - start) * frac
                currentSpeedPitch = value
                player.playbackParameters = PlaybackParameters(value, value)
                if (step < steps) delay(stepDelayMs)
            }
        }
    }

    /**
     * Softly fades out volume over ~240 ms when the user marks the active track Cool,
     * advances cleanly to the next track, and gently fades volume back in.
     */
    private fun performSoftFadeSkip() {
        val player = exoPlayer ?: return
        if (player.mediaItemCount <= 1) return

        softSkipJob?.cancel()
        softSkipJob = serviceScope.launch {
            val wasPlaying = player.isPlaying || player.playWhenReady
            val startVol = player.volume.coerceIn(0.05f, 1f)
            if (wasPlaying) {
                val fadeOutSteps = 8
                for (step in 1..fadeOutSteps) {
                    val frac = 1f - (step.toFloat() / fadeOutSteps.toFloat())
                    player.volume = (startVol * frac).coerceAtLeast(0.04f)
                    delay(30L)
                }
            }

            val nextIndex = (player.currentMediaItemIndex + 1) % player.mediaItemCount
            player.seekToDefaultPosition(nextIndex)
            if (wasPlaying) {
                player.play()
                val fadeInSteps = 5
                for (step in 1..fadeInSteps) {
                    val frac = step.toFloat() / fadeInSteps.toFloat()
                    player.volume = (0.04f + 0.96f * frac).coerceIn(0f, 1f)
                    delay(28L)
                }
            }
            player.volume = 1f
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        speedRampJob?.cancel()
        softSkipJob?.cancel()
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        exoPlayer = null
        super.onDestroy()
    }
}
