package com.example.service.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.round
import kotlin.math.sin

/**
 * Real-time Media3 PCM AudioProcessor delivering warm, mellow Lo-fi character:
 * - High-pass filter (~80 Hz) to clean sub-bass mud
 * - 2nd-order low-pass filter (~4.4 kHz) for smooth vintage warmth
 * - Soft saturation + slightly narrowed stereo width + gentle bit-depth softness
 * - Subtle quiet vinyl crackle & tape warmth layer
 * - Lightweight short small-room comb reverb
 * - Smooth ~300 ms wet/dry cross-fade so toggling never clicks, pops, or restarts playback
 * - Handles mono (upmixed to stereo) and stereo 16-bit PCM with zero hot-loop allocations
 */
@UnstableApi
class LofiAudioProcessor : BaseAudioProcessor() {

    @Volatile
    private var targetEnabled: Boolean = false

    private var currentMix: Float = 0f
    private var rampStepPerSample: Float = 0.0001f

    private var inputChannelCount: Int = 2
    private var sampleRate: Int = 44100

    // 1-pole HPF (~80 Hz) state per channel
    private var hpfAlpha: Float = 0.99f
    private var hpfPrevInL: Float = 0f
    private var hpfPrevOutL: Float = 0f
    private var hpfPrevInR: Float = 0f
    private var hpfPrevOutR: Float = 0f

    // 2nd-order Butterworth LPF (~4.4 kHz) biquad coefficients & state
    private var b0: Float = 1f
    private var b1: Float = 0f
    private var b2: Float = 0f
    private var a1: Float = 0f
    private var a2: Float = 0f
    private var lpX1L: Float = 0f; private var lpX2L: Float = 0f
    private var lpY1L: Float = 0f; private var lpY2L: Float = 0f
    private var lpX1R: Float = 0f; private var lpX2R: Float = 0f
    private var lpY1R: Float = 0f; private var lpY2R: Float = 0f

    // Lightweight 2-comb-per-channel small-room reverb delay lines (~13ms, 19ms, 15ms, 23ms)
    private var comb1L = FloatArray(1)
    private var comb2L = FloatArray(1)
    private var comb1R = FloatArray(1)
    private var comb2R = FloatArray(1)
    private var idx1L = 0; private var idx2L = 0
    private var idx1R = 0; private var idx2R = 0
    private var damp1L = 0f; private var damp2L = 0f
    private var damp1R = 0f; private var damp2R = 0f

    // Fast xorshift PRNG & soft filter state for quiet vinyl crackle/hiss
    private var rngState: Int = 0x5A17C321
    private var hissLp: Float = 0f

    fun setEnabled(enabled: Boolean) {
        targetEnabled = enabled
    }

    fun setEnabledImmediate(enabled: Boolean) {
        targetEnabled = enabled
        currentMix = if (enabled) 1f else 0f
    }

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT ||
            inputAudioFormat.channelCount !in 1..2
        ) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }

        inputChannelCount = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8000)

        // ~300 ms cross-fade ramp
        rampStepPerSample = 1f / (0.300f * sampleRate)

        // 80 Hz 1-pole high-pass filter coefficient
        val rcHpf = 1.0 / (2.0 * PI * 80.0)
        val dt = 1.0 / sampleRate
        hpfAlpha = (rcHpf / (rcHpf + dt)).toFloat()

        // 4.4 kHz 2nd-order Butterworth low-pass biquad (clamped safely below Nyquist)
        val cutoffHz = 4400.0.coerceAtMost(sampleRate * 0.42)
        val w0 = 2.0 * PI * cutoffHz / sampleRate
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val q = 0.70710678 // Butterworth Q (flat, smooth roll-off)
        val alpha = sinW0 / (2.0 * q)
        val a0 = 1.0 + alpha
        b0 = (((1.0 - cosW0) * 0.5) / a0).toFloat()
        b1 = ((1.0 - cosW0) / a0).toFloat()
        b2 = (((1.0 - cosW0) * 0.5) / a0).toFloat()
        a1 = ((-2.0 * cosW0) / a0).toFloat()
        a2 = ((1.0 - alpha) / a0).toFloat()

        // Allocate short prime-proportioned small-room comb buffers
        comb1L = FloatArray((sampleRate * 0.0131f).toInt().coerceAtLeast(16))
        comb2L = FloatArray((sampleRate * 0.0193f).toInt().coerceAtLeast(16))
        comb1R = FloatArray((sampleRate * 0.0149f).toInt().coerceAtLeast(16))
        comb2R = FloatArray((sampleRate * 0.0227f).toInt().coerceAtLeast(16))
        clearFilterStates()

        // Always output stereo 16-bit PCM (upmixing mono to stereo)
        return AudioFormat(sampleRate, 2, C.ENCODING_PCM_16BIT)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining <= 0) return

        val bytesPerInputFrame = inputChannelCount * 2
        val frameCount = remaining / bytesPerInputFrame
        if (frameCount <= 0) return

        val outputBuffer = replaceOutputBuffer(frameCount * 4) // Stereo 16-bit = 4 bytes/frame
        val enabledNow = targetEnabled

        // Ultra-low CPU bypass path when fully dry
        if (!enabledNow && currentMix <= 0.0001f) {
            currentMix = 0f
            if (inputChannelCount == 2) {
                val limit = inputBuffer.position() + frameCount * 4
                val oldLimit = inputBuffer.limit()
                inputBuffer.limit(limit)
                outputBuffer.put(inputBuffer)
                inputBuffer.limit(oldLimit)
            } else {
                for (i in 0 until frameCount) {
                    val sample = inputBuffer.short
                    outputBuffer.putShort(sample)
                    outputBuffer.putShort(sample)
                }
            }
            outputBuffer.flip()
            return
        }

        val targetMix = if (enabledNow) 1f else 0f

        for (i in 0 until frameCount) {
            // Smooth 300ms parameter ramp
            if (currentMix < targetMix) {
                currentMix = (currentMix + rampStepPerSample).coerceAtMost(targetMix)
            } else if (currentMix > targetMix) {
                currentMix = (currentMix - rampStepPerSample).coerceAtLeast(targetMix)
            }

            val dryL: Float
            val dryR: Float
            if (inputChannelCount == 2) {
                dryL = inputBuffer.short / 32768f
                dryR = inputBuffer.short / 32768f
            } else {
                val mono = inputBuffer.short / 32768f
                dryL = mono
                dryR = mono
            }

            // 1. High-pass (~80 Hz)
            val hpL = hpfAlpha * (hpfPrevOutL + dryL - hpfPrevInL)
            hpfPrevInL = dryL
            hpfPrevOutL = hpL

            val hpR = hpfAlpha * (hpfPrevOutR + dryR - hpfPrevInR)
            hpfPrevInR = dryR
            hpfPrevOutR = hpR

            // 2. Low-pass (~4.4 kHz 2nd-order Butterworth)
            val lpL = b0 * hpL + b1 * lpX1L + b2 * lpX2L - a1 * lpY1L - a2 * lpY2L
            lpX2L = lpX1L; lpX1L = hpL; lpY2L = lpY1L; lpY1L = lpL

            val lpR = b0 * hpR + b1 * lpX1R + b2 * lpX2R - a1 * lpY1R - a2 * lpY2R
            lpX2R = lpX1R; lpX1R = hpR; lpY2R = lpY1R; lpY1R = lpR

            // 3. Soft warm analog saturation (gentle cubic/rational curve)
            val satL = softSaturate(lpL * 1.18f)
            val satR = softSaturate(lpR * 1.18f)

            // 4. Slightly reduced stereo width for cozy vintage intimacy
            val mid = (satL + satR) * 0.5f
            val side = (satL - satR) * 0.5f * 0.74f
            var wetL = mid + side
            var wetR = mid - side

            // 5. Very subtle bit-depth warmth (15% soft 11-bit blend - never harsh)
            val quantStep = 512f
            val qL = round(wetL * quantStep) / quantStep
            val qR = round(wetR * quantStep) / quantStep
            wetL = wetL * 0.85f + qL * 0.15f
            wetR = wetR * 0.85f + qR * 0.15f

            // 6. Very quiet vinyl crackle & warm tape floor
            val vinyl = nextVinylNoiseSample()
            wetL += vinyl
            wetR += vinyl * 0.92f

            // 7. Light short room reverb (dual damped comb filters per channel)
            val revL = processSmallRoomLeft(wetL)
            val revR = processSmallRoomRight(wetR)
            wetL = wetL * 0.86f + revL * 0.18f
            wetR = wetR * 0.86f + revR * 0.18f

            // Smooth cross-fade dry <-> wet
            val mix = currentMix
            val invMix = 1f - mix
            val outL = (dryL * invMix + wetL * mix).coerceIn(-0.99f, 0.99f)
            val outR = (dryR * invMix + wetR * mix).coerceIn(-0.99f, 0.99f)

            outputBuffer.putShort((outL * 32767f).toInt().toShort())
            outputBuffer.putShort((outR * 32767f).toInt().toShort())
        }

        outputBuffer.flip()
    }

    private fun softSaturate(x: Float): Float {
        return x / (1f + abs(x) * 0.42f)
    }

    private fun nextVinylNoiseSample(): Float {
        var x = rngState
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        rngState = x
        val white = (x and 0xFFFF) / 32768f - 1f
        // Warm low-passed tape hiss (ultra subtle)
        hissLp = hissLp * 0.88f + white * 0.12f
        var noise = hissLp * 0.0042f
        // Rare soft dust pop (~1-2 soft clicks per second)
        if ((x ushr 16) and 0x7FFF == 1) {
            noise += white * 0.022f
        }
        return noise
    }

    private fun processSmallRoomLeft(input: Float): Float {
        val d1 = comb1L[idx1L]
        damp1L = d1 * 0.65f + damp1L * 0.35f
        comb1L[idx1L] = input + damp1L * 0.34f
        idx1L = (idx1L + 1) % comb1L.size

        val d2 = comb2L[idx2L]
        damp2L = d2 * 0.65f + damp2L * 0.35f
        comb2L[idx2L] = input + damp2L * 0.32f
        idx2L = (idx2L + 1) % comb2L.size

        return (d1 + d2) * 0.5f
    }

    private fun processSmallRoomRight(input: Float): Float {
        val d1 = comb1R[idx1R]
        damp1R = d1 * 0.65f + damp1R * 0.35f
        comb1R[idx1R] = input + damp1R * 0.34f
        idx1R = (idx1R + 1) % comb1R.size

        val d2 = comb2R[idx2R]
        damp2R = d2 * 0.65f + damp2R * 0.35f
        comb2R[idx2R] = input + damp2R * 0.32f
        idx2R = (idx2R + 1) % comb2R.size

        return (d1 + d2) * 0.5f
    }

    override fun onFlush() {
        clearFilterStates()
    }

    override fun onReset() {
        clearFilterStates()
    }

    private fun clearFilterStates() {
        hpfPrevInL = 0f; hpfPrevOutL = 0f
        hpfPrevInR = 0f; hpfPrevOutR = 0f
        lpX1L = 0f; lpX2L = 0f; lpY1L = 0f; lpY2L = 0f
        lpX1R = 0f; lpX2R = 0f; lpY1R = 0f; lpY2R = 0f
        comb1L.fill(0f); comb2L.fill(0f)
        comb1R.fill(0f); comb2R.fill(0f)
        idx1L = 0; idx2L = 0; idx1R = 0; idx2R = 0
        damp1L = 0f; damp2L = 0f; damp1R = 0f; damp2R = 0f
        hissLp = 0f
    }
}
