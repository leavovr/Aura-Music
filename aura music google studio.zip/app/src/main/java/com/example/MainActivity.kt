package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.ProvideReduceMotion
import com.example.ui.screens.CreatePlaylistScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.theme.AuraMusicTheme
import com.example.ui.viewmodel.AuraPlayerViewModel

private const val ROUTE_NOW_PLAYING = "now_playing"
private const val ROUTE_CREATE_PLAYLIST = "create_playlist?editId={editId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            AuraMusicApp()
        }
    }
}

@Composable
fun AuraMusicApp(
    viewModel: AuraPlayerViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val context = LocalContext.current

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = {}
    )
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val reshuffleMsg = stringResource(R.string.msg_reshuffled)
    val sequentialMsg = stringResource(R.string.msg_shuffle_off)
    val savedMsg = stringResource(R.string.msg_playlist_saved)
    val eightDHintMsg = stringResource(R.string.msg_8d_headphones_hint)
    val likedReshuffledMsg = stringResource(R.string.msg_liked_reshuffled)

    ProvideReduceMotion {
        AuraMusicTheme {
            NavHost(
                navController = navController,
                startDestination = ROUTE_NOW_PLAYING
            ) {
                composable(
                    route = ROUTE_NOW_PLAYING,
                    enterTransition = { fadeIn(tween(240)) },
                    exitTransition = { fadeOut(tween(200)) }
                ) {
                    NowPlayingScreen(
                        uiState = uiState,
                        onTogglePlayPause = viewModel::togglePlayPause,
                        onToggleLofi = viewModel::toggleLofi,
                        onToggleEightD = { viewModel.toggleEightD(eightDHintMsg) },
                        onSwipeNext = viewModel::swipeNext,
                        onSwipePrevious = viewModel::swipePrevious,
                        onSeekTo = viewModel::seekTo,
                        onToggleHot = viewModel::toggleHot,
                        onToggleCool = viewModel::toggleCool,
                        onToggleShuffle = {
                            viewModel.toggleSmartShuffle(
                                reshuffleMessage = reshuffleMsg,
                                sequentialMessage = sequentialMsg
                            )
                        },
                        onSelectTrack = viewModel::selectTrackFromQueue,
                        onSwitchPlaylist = viewModel::switchPlaylist,
                        onNavigateToCreatePlaylist = { editId ->
                            val target = if (editId != null) {
                                "create_playlist?editId=$editId"
                            } else {
                                "create_playlist?editId=-1"
                            }
                            navController.navigate(target)
                        },
                        onPlayLiked = { viewModel.playLikedQueue(reshuffleMessage = null) },
                        onShuffleLiked = { viewModel.playLikedQueue(reshuffleMessage = likedReshuffledMsg) },
                        onSelectLikedTrack = viewModel::selectTrackFromLiked,
                        onRemoveFromLiked = viewModel::removeFromLiked,
                        onUndoRemoveLiked = viewModel::undoRemoveFromLiked
                    )
                }

            composable(
                route = ROUTE_CREATE_PLAYLIST,
                arguments = listOf(
                    navArgument("editId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                ),
                enterTransition = {
                    slideInVertically(tween(300)) { it / 3 } + fadeIn(tween(260))
                },
                exitTransition = {
                    slideOutVertically(tween(240)) { it / 3 } + fadeOut(tween(200))
                }
            ) { backStackEntry ->
                val editId = backStackEntry.arguments?.getLong("editId") ?: -1L
                val editingPlaylist = if (editId > 0L) {
                    uiState.allPlaylists.firstOrNull { it.playlist.id == editId }
                } else null

                CreatePlaylistScreen(
                    editingPlaylist = editingPlaylist,
                    allTracks = uiState.allTracks,
                    onBack = { navController.popBackStack() },
                    onImportAudioUris = viewModel::importLocalAudio,
                    onSavePlaylist = { existingId, name, trackIds ->
                        viewModel.saveAndLaunchPlaylist(
                            existingPlaylistId = existingId,
                            name = name,
                            trackIds = trackIds,
                            savedMessage = savedMsg,
                            onComplete = { navController.popBackStack() }
                        )
                    }
                )
            }
            }
        }
    }
}
