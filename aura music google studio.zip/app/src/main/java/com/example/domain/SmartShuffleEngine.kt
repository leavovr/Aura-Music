package com.example.domain

import com.example.data.model.SongStats
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Aura Influenced Smart Shuffle Engine (Pure Kotlin):
 *
 * Weight formula per track:
 *   weight = base(1.0)
 *          * hotBoost        (Hot: x3.0)
 *          * coolDamp        (Cool: x0.15 — rarely played, never removed)
 *          * completionBoost (tracks listened to the end: up to x1.3)
 *          * skipPenalty     (tracks skipped within first 10s: down to x0.6)
 *          * freshness       (longer since lastPlayedAt -> higher; just-played -> strong penalty)
 *          * affinity        (metadata similarity to Hot songs: artist, album, genre, year range,
 *                             similar duration; x1.0 to x1.8)
 *
 * Queue generation rules:
 * - Efraimidis-Spirakis weighted random sampling without replacement (key = u^(1/weight)).
 * - Generated in batches of ~10 songs ahead (not the whole playlist at once).
 * - Fresh random seed per session so order is never identical across sessions.
 * - Anti-repetition: no song repeats within the last N plays, N = min(20, playlistSize / 2).
 * - Artist cap: the same artist never plays 3 times in a row.
 * - "Same line" flow: after a Hot song, 60% probability picks the next song from the
 *   highest-affinity group similar to that Hot song; 40% stays general weighted random.
 * - Exploration: ~12.5% of picks come from rarely/never-played songs so playback stays fresh.
 */
object SmartShuffleEngine {

    const val DEFAULT_BATCH_SIZE = 10

    private const val BASE_WEIGHT = 1.0
    private const val HOT_BOOST = 3.0
    private const val COOL_DAMP = 0.15
    private const val MAX_COMPLETION_BOOST = 1.3
    private const val MIN_SKIP_PENALTY = 0.6
    private const val MAX_AFFINITY = 1.8

    private const val SAME_LINE_HOT_PROBABILITY = 0.60
    private const val EXPLORATION_PROBABILITY = 0.125 // 10–15% exploration band
    private const val ONE_HOUR_MS = 3_600_000L
    private const val ONE_DAY_MS = 86_400_000L

    fun computeTrackWeight(
        track: Track,
        stats: SongStats?,
        hotTracks: List<Track>,
        nowMs: Long = System.currentTimeMillis()
    ): Double {
        val isHot = stats?.isHot ?: (track.preference == TrackPreference.HOT)
        val isCool = stats?.isCool ?: (track.preference == TrackPreference.COOL)

        val hotBoost = if (isHot) {
            // x3.0 baseline for Hot tracks
            HOT_BOOST + ((stats?.hotScore ?: 1f).coerceIn(0f, 3f) - 1f).coerceAtLeast(0f) * 0.12
        } else {
            1.0
        }

        val coolDamp = if (isCool) COOL_DAMP else 1.0

        val plays = (stats?.playCount ?: 0).coerceAtLeast(0)
        val completions = (stats?.completedCount ?: 0).coerceAtLeast(0)
        val skips = (stats?.skipCount ?: 0).coerceAtLeast(0)

        // Completion boost: up to x1.3 for consistently finished songs
        val completionBoost = if (plays > 0) {
            val ratio = (completions.toDouble() / plays.toDouble()).coerceIn(0.0, 1.0)
            1.0 + ratio * (MAX_COMPLETION_BOOST - 1.0)
        } else {
            1.0
        }

        // Skip penalty: down to x0.6 for songs often skipped within first 10s
        val skipPenalty = if (plays > 0 && skips > 0) {
            val ratio = (skips.toDouble() / plays.toDouble()).coerceIn(0.0, 1.0)
            (1.0 - ratio * (1.0 - MIN_SKIP_PENALTY)).coerceIn(MIN_SKIP_PENALTY, 1.0)
        } else {
            1.0
        }

        // Freshness: just-played gets a strong penalty; unplayed/older gets a gentle lift
        val lastPlayed = stats?.lastPlayedAt ?: 0L
        val freshness = when {
            lastPlayed <= 0L -> 1.15
            else -> {
                val elapsed = (nowMs - lastPlayed).coerceAtLeast(0L)
                when {
                    elapsed < 5 * 60_000L -> 0.22         // played in last 5 min
                    elapsed < 30 * 60_000L -> 0.50        // played in last 30 min
                    elapsed < 2 * ONE_HOUR_MS -> 0.80     // played in last 2 hours
                    elapsed < ONE_DAY_MS -> 1.02          // played today
                    else -> {
                        val days = (elapsed / ONE_DAY_MS).coerceAtMost(14L)
                        1.05 + (days.toDouble() / 14.0) * 0.20 // up to 1.25
                    }
                }
            }
        }

        // Affinity to Hot songs using artist, album, genre/vibe, year range, and duration
        val affinity = if (isCool || hotTracks.isEmpty()) {
            1.0
        } else {
            computeMaxAffinityToGroup(track, hotTracks)
        }

        val weight = BASE_WEIGHT * hotBoost * coolDamp * completionBoost * skipPenalty * freshness * affinity
        return weight.coerceAtLeast(0.02)
    }

    /**
     * Computes similarity affinity (1.0 .. 1.8) between [candidate] and a single [anchor] track
     * based on artist, album, genre/vibe, year range, and similar duration.
     */
    fun computePairAffinity(candidate: Track, anchor: Track): Double {
        if (candidate.id == anchor.id) return 1.0
        var bonus = 0.0

        val candArtist = candidate.artist.trim().lowercase()
        val ancArtist = anchor.artist.trim().lowercase()
        if (candArtist.isNotEmpty() && candArtist != "unknown artist" && candArtist == ancArtist) {
            bonus += 0.36
        }

        val candAlbum = candidate.album.trim().lowercase()
        val ancAlbum = anchor.album.trim().lowercase()
        if (candAlbum.isNotEmpty() && candAlbum == ancAlbum) {
            bonus += 0.22
        }

        val candVibe = candidate.vibe.trim().lowercase()
        val ancVibe = anchor.vibe.trim().lowercase()
        if (candVibe.isNotEmpty() && candVibe != "audio" && candVibe == ancVibe) {
            bonus += 0.20
        }

        if (candidate.year > 1900 && anchor.year > 1900) {
            val yearDiff = abs(candidate.year - anchor.year)
            when {
                yearDiff <= 2 -> bonus += 0.12
                yearDiff <= 6 -> bonus += 0.07
            }
        }

        if (candidate.durationMs > 0L && anchor.durationMs > 0L) {
            val diffRatio = abs(candidate.durationMs - anchor.durationMs).toDouble() /
                maxOf(candidate.durationMs, anchor.durationMs).toDouble()
            if (diffRatio <= 0.18) {
                bonus += 0.10
            }
        }

        return (1.0 + bonus).coerceIn(1.0, MAX_AFFINITY)
    }

    private fun computeMaxAffinityToGroup(candidate: Track, hotTracks: List<Track>): Double {
        var best = 1.0
        for (hot in hotTracks) {
            if (hot.id == candidate.id) continue
            val pair = computePairAffinity(candidate, hot)
            if (pair > best) best = pair
        }
        return best
    }

    /**
     * Generates the next batch (default ~10 tracks) of influenced-shuffle picks.
     *
     * @param pool Full playlist/library tracks available to draw from.
     * @param statsBySongId Global Room per-song stats keyed by songId.
     * @param recentTrackIds Chronological list of recently played/queued song IDs.
     * @param recentArtists Chronological list of recently played/queued artist names.
     * @param lastTrack The immediately preceding track (used for 60% Hot "same-line" flow).
     * @param excludeIds Song IDs already waiting ahead or currently playing in this batch.
     * @param batchSize Number of upcoming songs to generate (default 10).
     * @param nowMs Current wall clock timestamp in ms.
     * @param seed Fresh random seed per session.
     */
    fun generateNextBatch(
        pool: List<Track>,
        statsBySongId: Map<Long, SongStats>,
        recentTrackIds: List<Long> = emptyList(),
        recentArtists: List<String> = emptyList(),
        lastTrack: Track? = null,
        excludeIds: Set<Long> = emptySet(),
        batchSize: Int = DEFAULT_BATCH_SIZE,
        nowMs: Long = System.currentTimeMillis(),
        seed: Long = System.nanoTime()
    ): List<Track> {
        if (pool.isEmpty()) return emptyList()
        val effectiveBatchSize = batchSize.coerceAtLeast(1).coerceAtMost(pool.size)
        if (pool.size == 1) return pool

        val random = Random(seed)
        val antiRepeatWindow = min(20, pool.size / 2)

        val hotTracks = pool.filter { track ->
            val st = statsBySongId[track.id]
            st?.isHot ?: (track.preference == TrackPreference.HOT)
        }

        // Precompute base influenced weights for every track in pool
        val baseWeights = pool.associate { track ->
            track.id to computeTrackWeight(track, statsBySongId[track.id], hotTracks, nowMs)
        }

        // Track rarely/never-played subset for 10–15% exploration
        val minPlayCount = pool.minOf { statsBySongId[it.id]?.playCount ?: 0 }
        val explorationThreshold = minPlayCount + 1

        val picked = ArrayList<Track>(effectiveBatchSize)
        val pickedIds = HashSet<Long>(excludeIds)
        val rollingRecentIds = ArrayDeque<Long>(recentTrackIds.takeLast(antiRepeatWindow + 4))
        val rollingArtists = ArrayDeque<String>(recentArtists.takeLast(4))
        var prevTrack = lastTrack

        repeat(effectiveBatchSize) {
            val blockedByAntiRepeat = rollingRecentIds.takeLast(antiRepeatWindow).toSet()

            // Primary candidate set: not yet in this batch and not in anti-repetition window
            var candidates = pool.filter { it.id !in pickedIds && it.id !in blockedByAntiRepeat }
            if (candidates.isEmpty()) {
                // Fallback if playlist is smaller than batch + antiRepeat window
                candidates = pool.filter { it.id !in pickedIds }
            }
            if (candidates.isEmpty()) return@repeat

            // Enforce artist cap: same artist cannot play 3 times in a row
            val forbiddenArtist = if (rollingArtists.size >= 2) {
                val last1 = rollingArtists[rollingArtists.size - 1]
                val last2 = rollingArtists[rollingArtists.size - 2]
                if (last1.isNotEmpty() && last1 == last2) last1 else null
            } else null

            if (forbiddenArtist != null) {
                val filteredByArtist = candidates.filter {
                    it.artist.trim().lowercase() != forbiddenArtist
                }
                if (filteredByArtist.isNotEmpty()) {
                    candidates = filteredByArtist
                }
            }

            // Decide pick mode:
            // 1. "Same line" flow: after a Hot song, 60% probability picks from highest-affinity neighbors
            val prevIsHot = prevTrack != null &&
                (statsBySongId[prevTrack.id]?.isHot ?: (prevTrack.preference == TrackPreference.HOT))

            val chosen: Track = if (prevIsHot && prevTrack != null && random.nextDouble() < SAME_LINE_HOT_PROBABILITY) {
                val anchor = prevTrack
                val scoredAffinity = candidates.map { cand ->
                    val pairAff = computePairAffinity(cand, anchor)
                    cand to pairAff
                }
                val bestAff = scoredAffinity.maxOf { it.second }
                val highAffinityPool = if (bestAff > 1.05) {
                    scoredAffinity.filter { it.second >= (bestAff - 0.15).coerceAtLeast(1.05) }
                        .map { it.first }
                } else {
                    candidates
                }
                sampleOneWeighted(highAffinityPool, random) { cand ->
                    val base = baseWeights[cand.id] ?: 1.0
                    val pairAff = computePairAffinity(cand, anchor)
                    base * pairAff
                }
            } else if (random.nextDouble() < EXPLORATION_PROBABILITY) {
                // 2. Exploration (10–15%): draw from rarely or never played songs
                val explorationPool = candidates.filter { track ->
                    val st = statsBySongId[track.id]
                    val isCool = st?.isCool ?: (track.preference == TrackPreference.COOL)
                    !isCool && (st?.playCount ?: 0) <= explorationThreshold
                }
                val targetPool = explorationPool.ifEmpty { candidates }
                sampleOneWeighted(targetPool, random) { cand ->
                    val plays = statsBySongId[cand.id]?.playCount ?: 0
                    val rarityBoost = 1.0 / (1.0 + plays)
                    (baseWeights[cand.id] ?: 1.0) * (1.0 + rarityBoost)
                }
            } else {
                // 3. Standard influenced weighted sampling without replacement (Efraimidis-Spirakis)
                sampleOneWeighted(candidates, random) { cand ->
                    baseWeights[cand.id] ?: 1.0
                }
            }

            picked.add(chosen)
            pickedIds.add(chosen.id)
            rollingRecentIds.addLast(chosen.id)
            if (rollingRecentIds.size > antiRepeatWindow + 8) {
                rollingRecentIds.removeFirst()
            }
            rollingArtists.addLast(chosen.artist.trim().lowercase())
            if (rollingArtists.size > 4) {
                rollingArtists.removeFirst()
            }
            prevTrack = chosen
        }

        // Guarantee a fresh session doesn't accidentally mirror static list order on small playlists
        if (lastTrack == null && picked.size > 2 && picked.map { it.id } == pool.take(picked.size).map { it.id }) {
            val first = picked.removeAt(0)
            picked.add(first)
        }

        return picked
    }

    /**
     * Efraimidis-Spirakis weighted sampling without replacement for a single pick:
     * key_i = u_i ^ (1 / weight_i), select maximum key.
     */
    private fun sampleOneWeighted(
        candidates: List<Track>,
        random: Random,
        weightProvider: (Track) -> Double
    ): Track {
        var bestTrack = candidates.first()
        var bestKey = -1.0
        for (track in candidates) {
            val w = weightProvider(track).coerceAtLeast(0.02)
            val u = random.nextDouble().coerceIn(1e-7, 1.0 - 1e-7)
            val key = u.pow(1.0 / w)
            if (key > bestKey) {
                bestKey = key
                bestTrack = track
            }
        }
        return bestTrack
    }

    /**
     * Convenience wrapper to generate a session queue starting with an optional [anchorTrackId]
     * followed by the next influenced batch of ~10 tracks.
     */
    fun generateSessionQueue(
        tracks: List<Track>,
        statsBySongId: Map<Long, SongStats> = emptyMap(),
        anchorTrackId: Long? = null,
        recentTrackIds: List<Long> = emptyList(),
        recentArtists: List<String> = emptyList(),
        batchSize: Int = DEFAULT_BATCH_SIZE,
        nowMs: Long = System.currentTimeMillis(),
        seed: Long = System.nanoTime()
    ): List<Track> {
        if (tracks.size <= 1) return tracks

        val anchor = anchorTrackId?.let { id -> tracks.firstOrNull { it.id == id } }
        return if (anchor != null) {
            val upcoming = generateNextBatch(
                pool = tracks,
                statsBySongId = statsBySongId,
                recentTrackIds = (recentTrackIds + anchor.id).distinct(),
                recentArtists = recentArtists + anchor.artist.trim().lowercase(),
                lastTrack = anchor,
                excludeIds = setOf(anchor.id),
                batchSize = batchSize,
                nowMs = nowMs,
                seed = seed
            )
            listOf(anchor) + upcoming
        } else {
            generateNextBatch(
                pool = tracks,
                statsBySongId = statsBySongId,
                recentTrackIds = recentTrackIds,
                recentArtists = recentArtists,
                lastTrack = null,
                excludeIds = emptySet(),
                batchSize = batchSize,
                nowMs = nowMs,
                seed = seed
            )
        }
    }
}
