package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import com.example.domain.SmartShuffleEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Aura Music`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aura Music", appName)
    }

    @Test
    fun `smart shuffle preserves cool tracks while prioritizing hot and similar tracks`() {
        val tracks = listOf(
            sampleTrack(1L, "Golden Hour", "Julian", "Ambient Jazz", TrackPreference.HOT),
            sampleTrack(2L, "Indigo Solitude", "Elysian", "Nocturne", TrackPreference.COOL),
            sampleTrack(3L, "Amber Afterglow", "Julian", "Ambient Jazz", TrackPreference.NEUTRAL),
            sampleTrack(4L, "Emerald Dawn", "Soren", "Ethereal", TrackPreference.NEUTRAL)
        )

        val shuffled = SmartShuffleEngine.generateSessionQueue(tracks, seed = 42L)
        assertEquals(tracks.size, shuffled.size)
        // Cool tracks are dampened but never removed
        assertTrue(shuffled.any { it.id == 2L })

        val hotTracks = listOf(tracks[0])
        val hotWeight = SmartShuffleEngine.computeTrackWeight(
            track = tracks[0],
            stats = null,
            hotTracks = hotTracks
        )
        val affinityWeight = SmartShuffleEngine.computeTrackWeight(
            track = tracks[2],
            stats = null,
            hotTracks = hotTracks
        )
        val neutralWeight = SmartShuffleEngine.computeTrackWeight(
            track = tracks[3],
            stats = null,
            hotTracks = hotTracks
        )
        val coolWeight = SmartShuffleEngine.computeTrackWeight(
            track = tracks[1],
            stats = null,
            hotTracks = hotTracks
        )

        assertTrue(hotWeight > affinityWeight)
        assertTrue(affinityWeight > neutralWeight)
        assertTrue(neutralWeight > coolWeight)
        assertTrue(coolWeight > 0.0)
    }

    private fun sampleTrack(
        id: Long,
        title: String,
        artist: String,
        vibe: String,
        pref: TrackPreference
    ) = Track(
        id = id,
        title = title,
        artist = artist,
        vibe = vibe,
        durationMs = 18_000L,
        artworkKey = "golden_hour",
        audioUri = "file:///tmp/$id.wav",
        dominantColorLong = 0xFFF59E0BL,
        secondaryColorLong = 0xFF78350FL,
        preference = pref
    )
}
