package com.example

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.util.UnstableApi
import com.example.data.model.SongStats
import com.example.data.model.Track
import com.example.data.model.TrackPreference
import com.example.domain.SmartShuffleEngine
import com.example.service.audio.EightDAudioProcessor
import com.example.service.audio.LofiAudioProcessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

class ExampleUnitTest {

    @Test
    fun influencedShuffle_hotSongsAppearInFirstThirdNoticeablyMoreOftenOver1000Shuffles() {
        val nowMs = 1_750_000_000_000L
        val pool = (1L..30L).map { id ->
            val pref = when {
                id <= 4L -> TrackPreference.HOT
                id in 5L..7L -> TrackPreference.COOL
                else -> TrackPreference.NEUTRAL
            }
            sampleTrack(
                id = id,
                title = "Track $id",
                artist = "Artist ${(id % 10L) + 1L}",
                album = "Album ${(id % 6L) + 1L}",
                vibe = if (id % 3L == 0L) "Ambient Jazz" else "Nocturne",
                year = 2020 + (id % 5L).toInt(),
                durationMs = 180_000L + (id % 4L) * 10_000L,
                pref = pref
            )
        }

        val statsMap = pool.associate { track ->
            track.id to SongStats(
                songId = track.id,
                isHot = track.preference == TrackPreference.HOT,
                hotScore = if (track.preference == TrackPreference.HOT) 1f else 0f,
                isCool = track.preference == TrackPreference.COOL,
                coolScore = if (track.preference == TrackPreference.COOL) 1f else 0f,
                playCount = 3,
                completedCount = 2,
                skipCount = 0,
                lastPlayedAt = nowMs - 86_400_000L
            )
        }

        val hotIds = (1L..4L).toSet()
        val coolIds = (5L..7L).toSet()
        val neutralIds = (8L..30L).toSet()

        var hotInFirstThird = 0
        var neutralInFirstThird = 0
        var coolInFirstThird = 0
        var coolEverAppeared = false

        val simulations = 1000
        for (sim in 0 until simulations) {
            // Generate a full 30-track queue in batches of 10, mirroring production batching
            val batch1 = SmartShuffleEngine.generateNextBatch(
                pool = pool,
                statsBySongId = statsMap,
                batchSize = 10,
                nowMs = nowMs,
                seed = 10_000L + sim * 31L
            )
            assertEquals(10, batch1.size)

            // Verify artist cap: same artist never plays 3 times in a row
            for (i in 2 until batch1.size) {
                val a0 = batch1[i - 2].artist.lowercase()
                val a1 = batch1[i - 1].artist.lowercase()
                val a2 = batch1[i].artist.lowercase()
                assertFalse(
                    "Artist $a2 played 3 times in a row at index $i (sim $sim)",
                    a0 == a1 && a1 == a2
                )
            }

            // First third of the 30-song playlist is the first batch of 10 songs
            for (track in batch1) {
                when (track.id) {
                    in hotIds -> hotInFirstThird++
                    in coolIds -> {
                        coolInFirstThird++
                        coolEverAppeared = true
                    }
                    in neutralIds -> neutralInFirstThird++
                }
            }
        }

        val hotRatePerTrack = hotInFirstThird.toDouble() / (simulations * hotIds.size)
        val neutralRatePerTrack = neutralInFirstThird.toDouble() / (simulations * neutralIds.size)
        val coolRatePerTrack = coolInFirstThird.toDouble() / (simulations * coolIds.size)

        // Hot songs (3.0x boost) should appear in the first third noticeably more often than neutral
        assertTrue(
            "Expected Hot first-third rate ($hotRatePerTrack) to be substantially higher than Neutral ($neutralRatePerTrack)",
            hotRatePerTrack > neutralRatePerTrack * 1.75
        )
        // Cool songs (0.15x damp) should appear far less often than neutral, yet never be removed
        assertTrue(
            "Expected Cool first-third rate ($coolRatePerTrack) to be much lower than Neutral ($neutralRatePerTrack)",
            coolRatePerTrack < neutralRatePerTrack * 0.45
        )
        assertTrue("Expected Cool songs to still appear occasionally over 1000 shuffles", coolEverAppeared)
    }

    @Test
    fun smartShuffleWeights_reflectAllSixFactors() {
        val nowMs = 1_750_000_000_000L
        val hotAnchor = sampleTrack(
            id = 1L,
            title = "Golden Hour",
            artist = "Julian S.",
            album = "Warm Light",
            vibe = "Ambient Jazz",
            year = 2023,
            durationMs = 210_000L,
            pref = TrackPreference.HOT
        )
        val highAffinity = sampleTrack(
            id = 2L,
            title = "Amber Echo",
            artist = "Julian S.",
            album = "Warm Light",
            vibe = "Ambient Jazz",
            year = 2024,
            durationMs = 215_000L,
            pref = TrackPreference.NEUTRAL
        )
        val neutral = sampleTrack(
            id = 3L,
            title = "Cold Horizon",
            artist = "Soren K.",
            album = "North",
            vibe = "Minimal",
            year = 2012,
            durationMs = 340_000L,
            pref = TrackPreference.NEUTRAL
        )
        val cool = sampleTrack(
            id = 4L,
            title = "Static Drift",
            artist = "Other Artist",
            album = "Other",
            vibe = "Minimal",
            year = 2015,
            durationMs = 190_000L,
            pref = TrackPreference.COOL
        )

        val hotList = listOf(hotAnchor)
        val completedStats = SongStats(songId = 3L, playCount = 5, completedCount = 5, skipCount = 0, lastPlayedAt = nowMs - 2 * 86_400_000L)
        val skippedStats = SongStats(songId = 3L, playCount = 5, completedCount = 0, skipCount = 5, lastPlayedAt = nowMs - 2 * 86_400_000L)
        val justPlayedStats = SongStats(songId = 3L, playCount = 5, completedCount = 5, skipCount = 0, lastPlayedAt = nowMs - 30_000L)

        val wHot = SmartShuffleEngine.computeTrackWeight(hotAnchor, null, hotList, nowMs)
        val wAff = SmartShuffleEngine.computeTrackWeight(highAffinity, null, hotList, nowMs)
        val wNeutral = SmartShuffleEngine.computeTrackWeight(neutral, null, hotList, nowMs)
        val wCool = SmartShuffleEngine.computeTrackWeight(cool, null, hotList, nowMs)
        val wCompleted = SmartShuffleEngine.computeTrackWeight(neutral, completedStats, hotList, nowMs)
        val wSkipped = SmartShuffleEngine.computeTrackWeight(neutral, skippedStats, hotList, nowMs)
        val wJustPlayed = SmartShuffleEngine.computeTrackWeight(neutral, justPlayedStats, hotList, nowMs)

        assertTrue(wHot > wAff)
        assertTrue(wAff > wNeutral)
        assertTrue(wNeutral > wCool)
        assertTrue(wCool > 0.0)
        assertTrue(wCompleted > wSkipped)
        assertTrue(wCompleted > wJustPlayed)
    }

    @OptIn(UnstableApi::class)
    @Test
    fun lofiAndEightDProcessors_upmixMonoAndProcessStereoCleanly() {
        val lofi = LofiAudioProcessor()
        val eightD = EightDAudioProcessor()

        val monoFormat = AudioFormat(44100, 1, C.ENCODING_PCM_16BIT)
        val lofiOutFmt = lofi.configure(monoFormat)
        assertEquals(2, lofiOutFmt.channelCount)
        assertEquals(C.ENCODING_PCM_16BIT, lofiOutFmt.encoding)

        val eightDOutFmt = eightD.configure(lofiOutFmt)
        assertEquals(2, eightDOutFmt.channelCount)
        assertEquals(C.ENCODING_PCM_16BIT, eightDOutFmt.encoding)

        lofi.flush()
        eightD.flush()
        lofi.setEnabledImmediate(true)
        eightD.setEnabledImmediate(true)

        val frames = 1024
        val input = ByteBuffer.allocateDirect(frames * 2).order(ByteOrder.nativeOrder())
        for (i in 0 until frames) {
            val s = (sin(2.0 * PI * 440.0 * i / 44100.0) * 16000.0).toInt().toShort()
            input.putShort(s)
        }
        input.flip()

        lofi.queueInput(input)
        val lofiOut = lofi.output
        assertEquals(frames * 4, lofiOut.remaining())

        eightD.queueInput(lofiOut)
        val finalOut = eightD.output
        assertEquals(frames * 4, finalOut.remaining())
    }

    private fun sampleTrack(
        id: Long,
        title: String,
        artist: String,
        album: String = "",
        vibe: String,
        year: Int = 0,
        durationMs: Long = 18_000L,
        pref: TrackPreference
    ) = Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        vibe = vibe,
        year = year,
        durationMs = durationMs,
        artworkKey = "golden_hour",
        audioUri = "file:///tmp/$id.wav",
        dominantColorLong = 0xFFF59E0BL,
        secondaryColorLong = 0xFF78350FL,
        preference = pref
    )
}
